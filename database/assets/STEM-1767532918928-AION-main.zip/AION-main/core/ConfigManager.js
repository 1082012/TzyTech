import fs from 'fs';
import path from 'path';
import config from '../config.js'; // Import config yang sedang berjalan

class ConfigManager {
    constructor() {
        this.configPath = path.join(process.cwd(), 'config.js');
    }

    /**
     * UPDATE CREDENTIALS INSTAGRAM
     */
    async updateInstagram(username, password) {
        try {
            // 1. Update di MEMORY (Agar langsung efek tanpa restart)
            config.social.instagram.username = username;
            config.social.instagram.password = password;

            // 2. Update di FILE (Hard Disk)
            let rawConfig = fs.readFileSync(this.configPath, 'utf8');

            // Gunakan Regex aman untuk mencari field spesifik di dalam objek
            // Pola: username: "..." atau username: '...'
            const userRegex = /(instagram:\s*{[\s\S]*?username:\s*)(['"`])(.*?)(['"`])/;
            const passRegex = /(instagram:\s*{[\s\S]*?password:\s*)(['"`])(.*?)(['"`])/;

            // Replace Username
            if (userRegex.test(rawConfig)) {
                rawConfig = rawConfig.replace(userRegex, `$1$2${username}$4`);
            }

            // Replace Password
            if (passRegex.test(rawConfig)) {
                rawConfig = rawConfig.replace(passRegex, `$1$2${password}$4`);
            }

            // Tulis ulang file
            fs.writeFileSync(this.configPath, rawConfig, 'utf8');

            return true;
        } catch (error) {
            console.error("[CONFIG UPDATE FAIL]", error);
            return false;
        }
    }
}

export default new ConfigManager();