// MODUL INI BERTUGAS MEMECAH KALIMAT MENJADI ATOM KONSEP
// TANPA AI GENERATIF, MURNI LOGIKA BAHASA.

export default class SemanticProcessor {
    constructor() {
        // Kata hubung yang mendefinisikan RELASI
        this.relationalMap = {
            'adalah': 'IS_A',
            'merupakan': 'IS_A',
            'yaitu': 'IS_A',
            'seperti': 'LIKE',
            'mirip': 'LIKE',
            'berisi': 'CONTAINS',
            'mengandung': 'CONTAINS',
            'punya': 'HAS',
            'memiliki': 'HAS',
            'karena': 'CAUSED_BY',
            'sebab': 'CAUSED_BY',
            'mengakibatkan': 'CAUSES',
            'menghasilkan': 'PRODUCES',
            'terkait': 'RELATED_TO',
            'hubungan': 'RELATED_TO'
        };

        // Kata sampah (Stopwords) yang tidak boleh jadi Node
        this.stopwords = new Set([
            'yang', 'di', 'ke', 'dari', 'pada', 'dalam', 'untuk', 'dengan', 
            'atau', 'dan', 'ini', 'itu', 'juga', 'akan', 'sudah', 'telah'
        ]);
    }

    /**
     * DEKOMPOSISI: Kalimat -> Array of Triples
     * Input: "Energi adalah kemampuan melakukan usaha"
     * Output: [{ subject: "energi", relation: "IS_A", object: "kemampuan" }, ...]
     */
    decompose(text) {
        const cleanText = text.toLowerCase().replace(/[^\w\s]/g, '');
        const words = cleanText.split(/\s+/);
        const triples = [];

        // Algoritma Sliding Window sederhana untuk mencari Pola S-P-O
        let subject = null;
        let relation = 'RELATED_TO'; // Default relation

        for (let i = 0; i < words.length; i++) {
            const word = words[i];

            // Skip stopword
            if (this.stopwords.has(word)) continue;

            // Cek apakah kata ini adalah RELASI?
            if (this.relationalMap[word]) {
                relation = this.relationalMap[word];
                continue; // Lanjut cari object
            }

            // Jika belum ada subject, jadikan ini subject
            if (!subject) {
                subject = word;
            } 
            // Jika sudah ada subject & relation, jadikan ini object lalu simpan
            else {
                const object = word;
                triples.push({ subject, relation, object });
                
                // Konsep Chaining: Object kalimat ini bisa jadi Subject berikutnya
                // Contoh: A sebab B, B sebab C.
                subject = object; 
                relation = 'RELATED_TO'; // Reset relasi
            }
        }

        // AUTO-EXPANSION: Tambahkan konteks implisit
        // Jika input membahas "fisika", semua node ditandai domain fisika
        return triples;
    }

    /**
     * EKSTRAKSI KEYWORD QUERY
     */
    extractConcepts(query) {
        return query.toLowerCase()
            .replace(/[^\w\s]/g, '')
            .split(/\s+/)
            .filter(w => !this.stopwords.has(w));
    }
}