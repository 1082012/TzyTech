import { ClassicLevel } from 'classic-level';
import path from 'path';
import chalk from 'chalk';
import fs from 'fs';

// KONFIGURASI ENGINE
const DB_PATH = path.join(process.cwd(), 'database', 'neural_vault_v1');
const NGRAM_SIZE = 3; // Ukuran pecahan saraf (Tri-gram)

class NeuralVault {
    constructor() {
        // Inisialisasi LevelDB (RocksDB Engine)
        // ValueEncoding 'json' memudahkan penyimpanan objek kompleks
        this.db = new ClassicLevel(DB_PATH, { valueEncoding: 'json' });
        
        // State Cache untuk performa
        this.status = 'OFFLINE';
        this.init();
    }

    async init() {
        try {
            // Pastikan folder ada
            if (!fs.existsSync(DB_PATH)) fs.mkdirSync(DB_PATH, { recursive: true });
            
            await this.db.open();
            this.status = 'ONLINE';
            console.log(chalk.cyan(`[NEURAL VAULT] 🧠 Synaptic Storage Active. Engine: RocksDB`));
        } catch (e) {
            console.error(chalk.red(`[NEURAL VAULT] CRITICAL FAILURE: ${e.message}`));
            this.status = 'CORRUPTED';
        }
    }

    /**
     * DEEP LEARNING (MANUAL TRAINING)
     * Menyimpan pola Input -> Output dengan bobot saraf.
     */
    async train(input, output, weight = 1.0) {
        if (this.status !== 'ONLINE') throw new Error("Neural Vault is Offline");

        const normalizedInput = this.normalize(input);
        const id = Buffer.from(normalizedInput).toString('base64'); // Hash Key

        const synapseData = {
            input: normalizedInput,
            output: output,
            weight: weight,
            created: Date.now(),
            hits: 0
        };

        // 1. Simpan Data Utama
        await this.db.put(`DATA:${id}`, synapseData);

        // 2. Buat Index N-Gram (Untuk pencarian fuzzy/mirip manusia)
        const tokens = this.tokenize(normalizedInput);
        const batch = this.db.batch();

        for (const token of tokens) {
            // Simpan referensi token ke ID data utama
            // Key: "IDX:hallo:ID123" -> Value: true
            batch.put(`IDX:${token}:${id}`, true);
        }

        await batch.write();
        return id;
    }

    /**
     * SYNAPTIC RECALL (PENCARIAN CERDAS TANPA OLLAMA)
     * Menggunakan algoritma scoring berdasarkan kecocokan token.
     */
    async recall(query) {
        if (this.status !== 'ONLINE') return null;

        const normalizedQuery = this.normalize(query);
        const tokens = this.tokenize(normalizedQuery);
        const candidates = new Map(); // Map<ID, Score>

        // A. SCANNING INDEX (Parallel Async Iterator)
        for (const token of tokens) {
            // Cari semua data yang mengandung token ini
            // Menggunakan iterator leveldb yang sangat cepat
            for await (const [key] of this.db.iterator({ 
                gt: `IDX:${token}:`, 
                lt: `IDX:${token}:\xff` 
            })) {
                // Key format: IDX:token:ID
                const parts = key.split(':');
                const id = parts[2];

                // Scoring System
                const currentScore = candidates.get(id) || 0;
                candidates.set(id, currentScore + 1);
            }
        }

        // B. FILTER & SORTING
        if (candidates.size === 0) return null;

        // Urutkan berdasarkan skor tertinggi (Paling relevan)
        const sortedIds = [...candidates.entries()]
            .sort((a, b) => b[1] - a[1]) // Sort desc by score
            .slice(0, 3); // Ambil Top 3 kandidat

        // C. FETCH DATA ASLI
        const results = [];
        for (const [id, score] of sortedIds) {
            try {
                const data = await this.db.get(`DATA:${id}`);
                
                // Hitung Confidence Level (Persentase kecocokan)
                const confidence = score / Math.max(tokens.length, this.tokenize(data.input).length);
                
                if (confidence > 0.3) { // Threshold minimal 30% mirip
                    results.push({ ...data, confidence });
                }
            } catch (e) {
                // Ignore missing keys (corruption self-healing)
            }
        }

        return results.length > 0 ? results[0] : null; // Return yang terbaik
    }

    /**
     * UTILITAS: Normalisasi Teks
     */
    normalize(text) {
        // [SAFETY] Jika text kosong/bukan string, kembalikan string kosong
        if (!text || typeof text !== 'string') return "";
        
        return text.toLowerCase()
            .replace(/[^\w\s]/gi, '') 
            .trim()
            .replace(/\s+/g, ' '); 
    }

    /**
     * UTILITAS: Tokenizer N-Gram
     * Memecah "hello" menjadi "hel", "ell", "llo" untuk fuzzy match
     */
    tokenize(text) {
        const words = text.split(' ');
        let tokens = [...words]; // Kata utuh

        // Tambahkan N-Grams untuk akurasi tinggi
        if (text.length > NGRAM_SIZE) {
            for (let i = 0; i < text.length - NGRAM_SIZE + 1; i++) {
                tokens.push(text.substring(i, i + NGRAM_SIZE));
            }
        }
        return [...new Set(tokens)]; // Hapus duplikat
    }

    async getStats() {
        let count = 0;
        for await (const _ of this.db.iterator({ gt: 'DATA:', lt: 'DATA:\xff' })) {
            count++;
        }
        return { totalNeurons: count, status: this.status };
    }
}

// Singleton Instance
export default new NeuralVault();