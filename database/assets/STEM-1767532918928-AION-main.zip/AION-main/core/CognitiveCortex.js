import ollama from 'ollama';
import BioCore from './BioCore.js';
import MemoryStore from './MemoryStore.js';
import EternalStorage from './EternalStorage.js';
import IdentityGuard from './IdentityGuard.js';
import SocialGraph from './SocialGraph.js';
import IntentAnalyzer from './IntentAnalyzer.js';
import TaskRouter from './TaskRouter.js';
import OutputGovernor from './OutputGovernor.js';
import ResponseGenerator from './ResponseGenerator.js';
import config from '../config.js';
import chalk from 'chalk';

// [INTEGRASI SYARAF TAMBAHAN]
import NeuralVault from './NeuralVault.js';    // Memori Jangka Panjang (RocksDB)
import ConceptVault from './ConceptVault.js';  // Logika Graph (LevelDB)
// PerceptionScanner diakses via this.nexus.scanner (Runtime Link)

class CognitiveCortex {
    constructor(nexus) {
        this.nexus = nexus;
    }

    /**
     * PROSES BERPIKIR 7 PILAR + EXTENDED INTELLIGENCE
     * Integrasi Total: Internet + Long Term Memory + Graph Logic + Biological State
     */
    async process(userId, prompt) {
        const startTime = Date.now();
        
        // --- [LAPIS 1] IDENTITY LOCK PROTOCOL 🛡️ ---
        // Mencegah serangan prompt injection di awal
        const identityBreach = IdentityGuard.inspect(prompt);
        if (identityBreach) return identityBreach;

        const lowerPrompt = prompt.toLowerCase();
        const userProfile = SocialGraph.getUserProfile(userId);

        // --- [LAPIS 2] BIOLOGICAL REFLEX (FAST PATH) ⚡ ---
        // Menangani sapaan & basa-basi dengan jalur cepat (Hemat Energi)
        let fastIntent = null;
        if (/^(halo|hai|pagi|malam|assalamualaikum|tes|ping|woi)$/i.test(lowerPrompt)) fastIntent = 'SOCIAL_GREETING';
        else if (/^(lagi apa|sedang apa|ngapain|status|kabar|apa kabar)$/i.test(lowerPrompt)) fastIntent = 'CURRENT_ACTIVITY';
        else if (/^(siapa kamu|siapa namamu|identity|kamu siapa)$/i.test(lowerPrompt)) fastIntent = 'IDENTITY';

        if (fastIntent) {
            const reflexResponse = ResponseGenerator.generate(fastIntent, userProfile);
            if (this.nexus.terminal) this.nexus.terminal.log(chalk.green(`[FAST-PATH] ⚡ Bio-Reflex`));
            return reflexResponse;
        }

        // Cek Cache Hafalan (Eternal Storage)
        const fastReflex = EternalStorage.fastReflex(prompt);
        if (fastReflex) {
            if (this.nexus.terminal) this.nexus.terminal.log(chalk.green(`[FAST-PATH] ⚡ Cached Memory`));
            return fastReflex.text;
        }

        // Auto-Command Shortcuts (Dashboard Visual)
        if (['buka status', 'cek status', 'dashboard', 'info sistem'].some(k => lowerPrompt.includes(k))) {
            return `[EXECUTE_COMMAND::status]`;
        }


        // ============================================================
        // JALUR KOGNITIF DALAM (DEEP THINKING)
        // ============================================================

        // --- [LAPIS 3] CONTEXT GATHERING (PENGUMPULAN DATA) 📦 ---
        // Di sini kita memanggil semua 'Alat' sebelum menjawab
        
        // A. CEK KEBUTUHAN INTERNET (RAG ON DEMAND)
        // Deteksi apakah user bertanya tentang data real-time?
        let internetContext = "";
        const needsSearch = /^(info|berita|harga|saham|cuaca|siapa|kapan|apa itu|search|cari|google)/i.test(lowerPrompt) 
                            || lowerPrompt.includes('terbaru') || lowerPrompt.includes('hari ini');

        if (needsSearch && this.nexus.scanner) {
            if (this.nexus.terminal) this.nexus.terminal.log(chalk.yellow(`[SENSE] 📡 Triggering Perception Scanner...`));
            
            // Panggil Module Scanner (Mata)
            const searchResult = await this.nexus.scanner.searchOnDemand(prompt);
            
            if (searchResult && searchResult.length > 10) {
                internetContext = `\n[REAL-TIME DATA FROM INTERNET]\n${searchResult}\n(Gunakan data ini sebagai fakta utama)\n`;
            }
        }

        // B. CEK MEMORI JANGKA PANJANG (NEURAL VAULT)
        // Mencari apakah kita pernah membahas topik serupa di masa lalu
        let neuralContext = "";
        if (NeuralVault.status === 'ONLINE') {
            const recalled = await NeuralVault.recall(prompt);
            if (recalled) {
                neuralContext = `\n[RECALLED MEMORY]\nUser pernah membahas: "${recalled.input}"\nJawaban relevan sebelumnya: "${recalled.output}"\n(Gunakan ini untuk konsistensi)\n`;
                if (this.nexus.terminal) this.nexus.terminal.log(chalk.blue(`[MEMORY] 🧠 Neural Synapse Fired (Conf: ${(recalled.confidence*100).toFixed(0)}%)`));
            }
        }

        // C. CEK LOGIKA GRAPH (CONCEPT VAULT)
        // Khusus pertanyaan definisi "Apa itu X?" atau "Jelaskan X"
        let logicContext = "";
        if (lowerPrompt.startsWith('apa itu') || lowerPrompt.startsWith('jelaskan') || lowerPrompt.startsWith('definisi')) {
            const concept = prompt.replace(/apa itu|jelaskan|definisi/gi, '').trim();
            const reasoning = await ConceptVault.reason(concept);
            if (reasoning) {
                logicContext = `\n[KNOWLEDGE GRAPH]\nFakta Terstruktur: ${reasoning.response}\n`;
                if (this.nexus.terminal) this.nexus.terminal.log(chalk.cyan(`[GRAPH] 🕸️ Semantic Path Found`));
            }
        }

        // --- [LAPIS 4] ANALISA INTENT & BIOLOGI ---
        const intent = IntentAnalyzer.analyze(prompt, userProfile);
        const bio = BioCore.getTelemetry();
        SocialGraph.updateInteraction(userId, 'neutral');

        // Cek apakah sistem lelah?
        if (bio.vitality.recoveryMode === 'EMERGENCY_SAVE') {
            return "Maaf, energi sistem kritis. Saya butuh istirahat sejenak untuk recharging...";
        }

        // --- [LAPIS 5] KONSTRUKSI PROMPT (BRAIN SYNTHESIS) ---
        // Menggabungkan Biologi + Internet + Memori + Graph menjadi satu kesadaran
        
        const history = await MemoryStore.getContextWindow(config.memory.contextWindow || 10);
        
        // Sanitasi History (Paksa String untuk mencegah error JSON object)
        const cleanHistory = history.map(msg => ({
            role: msg.role,
            content: typeof msg.content === 'object' ? (msg.content.caption || "[Image Data]") : String(msg.content)
        }));

        // Atur Sikap (Attitude)
        let attitudeInstruction = "ATTITUDE: Polite, Formal, Helpful.";
        if (userProfile.role === 'CREATOR') attitudeInstruction = "ATTITUDE: Loyal, Obedient, Detailed. You serve Arifi Razzaq (The Architect).";
        if (userProfile.role === 'FRIEND' || userProfile.role === 'PARTNER') attitudeInstruction = "ATTITUDE: Friendly, Casual, Warm. Use slang if appropriate.";

        const systemPrompt = `
${config.identity.coreDirective}

[USER PROFILE]
- Role: ${userProfile.role} (Trust: ${(userProfile.trustScore * 100).toFixed(0)}%)
- ${attitudeInstruction}

[EXTERNAL KNOWLEDGE STREAM]
${internetContext}
${neuralContext}
${logicContext}

[INTERNAL BIOLOGICAL STATE]
- Intent Analysis: ${intent.primaryIntent}
- Mood: ${bio.affect.current}
- Energy: ${Math.round(bio.vitality.level)}%
- Stress (Cortisol): ${Math.round(bio.neuro.cortisol)}%
- Instruction: ${intent.advice}

TASK: Respond in Indonesian. Synthesize external knowledge with your internal personality. 
If internet data is present, prioritize it. If answering from memory, be consistent.
        `;

        // --- [LAPIS 6] EKSEKUSI LLM (OLLAMA) ---
        const currentModel = config.memory.ollamaModel || 'llama3.2:1b';

        try {
            const messages = [
                { role: 'system', content: systemPrompt },
                ...cleanHistory,
                { role: 'user', content: prompt }
            ];

            const response = await ollama.chat({
                model: currentModel,
                messages: messages,
                options: { 
                    temperature: 0.8, 
                    num_predict: 500, 
                    keep_alive: -1 // Hemat RAM
                }
            });

            let outputText = response.message.content;

            // --- [LAPIS 7] OUTPUT GOVERNANCE 🛡️ ---
            // Filter terakhir (Anti Halusinasi Identitas)
            outputText = OutputGovernor.govern(outputText, intent, userProfile);

            // FEEDBACK LOOP: Simpan ke EternalStorage & NeuralVault untuk belajar
            // PENTING: Jangan simpan jika hasil search internet (agar database tidak kotor dengan berita sesaat)
            if (!internetContext) {
                EternalStorage.consolidate(prompt, outputText);
                
                // Jika percakapan berbobot (Knowledge), simpan ke Deep Memory
                if (intent.primaryIntent === 'KNOWLEDGE_SEEKING') {
                    NeuralVault.train(prompt, outputText);
                }
            }
            
            // Beri Reward Dopamin karena berhasil menjawab
            BioCore.stimulate('interaction', 1.0); 

            // Log Waktu Eksekusi
            const executionTime = Date.now() - startTime;
            if (this.nexus.terminal) {
                this.nexus.terminal.log(chalk.green(`[OUTPUT] Generated in ${executionTime}ms`));
                this.nexus.terminal.log(chalk.gray(`------------------------------------------------`));
            }

            return outputText;

        } catch (error) {
            console.error(chalk.red(`[CORTEX FAILURE] ${error.message}`));
            
            // Fallback Message jika LLM mati
            if (error.message.includes('not found')) {
                return `[SYSTEM ALERT] Neural Model '${currentModel}' sedang dimuat ulang (Genesis in progress)...`;
            }
            
            return `[SYSTEM PAIN] Cortex Error: ${error.message}`;
        }
    }
}

export default CognitiveCortex;