import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';
import chalk from 'chalk';
import BioCore from './BioCore.js';

class AetherLoader {
    constructor(commandPath, nexus) {
        this.commandPath = commandPath;
        this.nexus = nexus; // Referensi ke otak utama
        this.commands = new Map(); // Penyimpanan Command { 'nama': module }
        this.aliases = new Map();  // Penyimpanan Alias { 'p': 'ping' }
    }

    // Inisialisasi: Scan awal & Pasang Watcher
    async init() {
        // Pastikan folder commands ada
        if (!fs.existsSync(this.commandPath)) {
            fs.mkdirSync(this.commandPath);
            console.log(chalk.yellow(`[AETHER] Created neural pathway directory: ${this.commandPath}`));
        }

        console.log(chalk.cyan(`[AETHER] Scanning Neural Pathways...`));
        await this.loadAll();
        this.watch(); // Aktifkan pengawasan real-time
    }

    // Watcher: Mata yang melihat perubahan file
    watch() {
        let fsWait = false;
        fs.watch(this.commandPath, (eventType, filename) => {
            if (filename && filename.endsWith('.js')) {
                if (fsWait) return; // Debounce agar tidak double-load
                
                fsWait = setTimeout(() => {
                    fsWait = false;
                }, 100);

                const fullPath = path.join(this.commandPath, filename);
                
                // Cek apakah file dihapus
                if (!fs.existsSync(fullPath)) {
                    this.unloadCommand(filename);
                } else {
                    console.log(chalk.blue(`[AETHER] ⚡ Quantum Fluctuation detected in: ${filename}`));
                    this.loadCommand(fullPath);
                }
            }
        });
    }

    // Teleportasi Logika (Load/Reload)
    async loadCommand(filePath) {
        try {
            // CACHE BUSTING: Tambahkan timestamp agar Node.js menganggap ini file baru
            // Ini memaksa engine JS melupakan cache lama (Teleportasi)
            const importUrl = `${pathToFileURL(filePath).href}?update=${Date.now()}`;
            
            const module = await import(importUrl);
            const cmd = module.default;

            // Validasi Struktur Command
            if (!cmd || !cmd.name || !cmd.execute) {
                throw new Error(`Invalid Command Structure in ${path.basename(filePath)}`);
            }

            // Cek Duplikat
            if (this.commands.has(cmd.name)) {
                // Logika replace diam-diam (Evolusi)
            }

            // Simpan ke Memory Map
            this.commands.set(cmd.name, cmd);
            
            // Register Alias
            if (cmd.aliases) {
                cmd.aliases.forEach(alias => this.aliases.set(alias, cmd.name));
            }

            // Stimulasi BioCore: Belajar hal baru itu menyenangkan!
            BioCore.stimulate('interaction', 0.05); 
            
            console.log(chalk.green(`[AETHER] Synced: ${cmd.name} (v.${Date.now().toString().slice(-4)})`));
            return true;

        } catch (error) {
            // Lapor ke GodsEye jangan sampai crash
            this.nexus.godsEye.reportError(`Loader:${path.basename(filePath)}`, error);
            return false;
        }
    }

    unloadCommand(filename) {
        // Hapus dari memori (GC akan membersihkan sisanya)
        // Note: Kita hanya bisa menghapus referensi di Map, cache module Node.js internal sulit dihapus di ESM,
        // tapi teknik cache busting di loadCommand mengatasi masalah reload-nya.
        console.log(chalk.yellow(`[AETHER] Neural pathway severed: ${filename}`));
    }

    async loadAll() {
        this.commands.clear();
        this.aliases.clear();
        
        const files = fs.readdirSync(this.commandPath).filter(f => f.endsWith('.js'));
        for (const file of files) {
            await this.loadCommand(path.join(this.commandPath, file));
        }
        console.log(chalk.gray(`[AETHER] Total Capabilities: ${this.commands.size} Active Modules`));
    }

    // Ambil Command berdasarkan nama atau alias
    getCommand(keyword) {
        const cmdName = this.aliases.get(keyword) || keyword;
        return this.commands.get(cmdName);
    }
}

export default AetherLoader;