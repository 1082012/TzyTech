import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { execSync } from 'child_process';
import { createRequire } from 'module'; // [FIX] Import pembuat Require

// [FIX] Buat fungsi require manual agar kompatibel dengan ES Module
const require = createRequire(import.meta.url);

class ResourceManager {
    constructor() {
        this.baseDir = process.cwd();
        
        // 1. DNA STRUKTUR FOLDER (Tulang)
        this.directories = [
            'assets/icons',
            'assets/fonts',
            'database',
            'database/social',
            'logs',
            'temp'
        ];

        // 2. DNA ASET VISUAL (Daging/Organ)
        this.assets = {
            'assets/icons/heart.svg': `<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><path d="M32 58C32 58 58 42 58 24C58 12 48 4 38 4C30 4 32 12 32 12C32 12 34 4 26 4C16 4 6 12 6 24C6 42 32 58 32 58Z" fill="#ff003c"/></svg>`,
            'assets/icons/bolt.svg': `<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><path d="M36 2L20 34H32L28 62L44 30H32L36 2Z" fill="#ffd300"/></svg>`,
            'assets/icons/brain.svg': `<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="28" fill="#bc13fe" opacity="0.5"/><path d="M32 12C20 12 12 20 12 32C12 44 20 52 32 52C44 52 52 44 52 32C52 20 44 12 32 12Z" fill="#bc13fe"/></svg>`,
            'assets/icons/chip.svg': `<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><rect x="12" y="12" width="40" height="40" rx="4" fill="#00f3ff" opacity="0.2"/><path d="M20 20H44V44H20V20Z" fill="#00f3ff"/></svg>`,
            'assets/icons/activity.svg': `<svg width="64" height="64" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><path d="M4 32H16L24 8L40 56L48 32H60" stroke="#0aff68" stroke-width="4" fill="none"/></svg>`
        };
    }

    async checkAndEnforce() {
        console.log(chalk.cyan("🔍 [SYSTEM] Verifying Neural Architecture..."));

        // A. Cek Struktur Folder
        this.directories.forEach(dir => {
            const fullPath = path.join(this.baseDir, dir);
            if (!fs.existsSync(fullPath)) {
                fs.mkdirSync(fullPath, { recursive: true });
                console.log(chalk.green(`    ✅ Created Node: ${dir}`));
            }
        });

        // B. Cek Aset Vital
        Object.entries(this.assets).forEach(([filePath, content]) => {
            const fullPath = path.join(this.baseDir, filePath);
            if (!fs.existsSync(fullPath)) {
                console.log(chalk.yellow(`    ⚠️ Asset missing: ${filePath}`));
                fs.writeFileSync(fullPath, content);
                console.log(chalk.green(`    ✅ Regenerated: ${filePath}`));
            }
        });

        // C. Cek Dependensi Kritis (Auto Install NPM)
        // Kita gunakan list paket penting saja agar tidak terlalu lama
        const criticalPackages = [
            'skia-canvas', 
            'sharp', 
            'ollama', 
            'chalk', 
            'pino',
            '@whiskeysockets/baileys'
        ];

        let missingCount = 0;
        
        for (const pkg of criticalPackages) {
            if (!this.verifyPackage(pkg)) {
                missingCount++;
            }
        }

        if (missingCount === 0) {
            console.log(chalk.blue("🛡️ [SYSTEM] Integrity Verified. All systems nominal.\n"));
        } else {
            console.log(chalk.yellow("⚠️ [SYSTEM] Some modules were re-installed. Please restart if needed.\n"));
        }
    }

    /**
     * Cek apakah paket NPM terinstall dengan benar.
     * Menggunakan 'createRequire' agar kompatibel dengan ESM.
     */
    verifyPackage(packageName) {
        try {
            // [FIX] Menggunakan require yang sudah kita buat di atas
            require.resolve(packageName);
            return true;
        } catch (e) {
            // Hanya install jika errornya benar-benar "MODULE_NOT_FOUND"
            if (e.code === 'MODULE_NOT_FOUND') {
                console.log(chalk.red.bold(`🚨 [CRITICAL] Module '${packageName}' missing!`));
                console.log(chalk.yellow(`⚙️ [AUTO-FIX] Installing ${packageName}... (Please wait)`));
                try {
                    execSync(`npm install ${packageName}`, { stdio: 'inherit' });
                    console.log(chalk.green(`✅ [AUTO-FIX] ${packageName} installed successfully.`));
                    return true;
                } catch (installErr) {
                    console.error(chalk.red(`❌ [FATAL] Failed to install ${packageName}. Manual intervention required.`));
                    process.exit(1);
                }
            } else {
                // Jika error lain (misal syntax error di dalam modul), jangan install ulang, tapi lapor.
                console.error(chalk.red(`[MODULE ERROR] Issue with '${packageName}': ${e.message}`));
                return false;
            }
        }
    }
    
    /**
     * CADANGAN DATABASE (Safety Net)
     * Menyalin semua file .json ke folder backup/timestamp
     */
    backupDatabase() {
        const dbDir = path.join(this.baseDir, 'database');
        const backupRoot = path.join(this.baseDir, 'backups');
        
        if (!fs.existsSync(backupRoot)) fs.mkdirSync(backupRoot);

        const dateStr = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
        const todayBackup = path.join(backupRoot, dateStr);
        
        if (!fs.existsSync(todayBackup)) fs.mkdirSync(todayBackup);

        if (fs.existsSync(dbDir)) {
            const files = fs.readdirSync(dbDir).filter(f => f.endsWith('.json'));
            let count = 0;
            files.forEach(file => {
                const src = path.join(dbDir, file);
                const dest = path.join(todayBackup, file);
                fs.copyFileSync(src, dest);
                count++;
            });
            // Tidak perlu log spam jika sukses, silent backup
        }
    }
}

export default new ResourceManager();