import fs from 'fs';
import path from 'path';
import chalk from 'chalk';

const dbPath = path.join(process.cwd(), 'database', 'eternal_cortex.json');

class EternalStorage {
    constructor() {
        this.patterns = [];
        
        // [OPTIMIZATION] DUPLIKASI DIHAPUS
        // Bagian 'preWarmed' (sapaan statis) telah dipindahkan ke ResponsePool.js
        // agar tidak terjadi konflik logika (Schizophrenic Reflex).
        // Modul ini sekarang murni untuk "Hafalan Jangka Panjang" yang dipelajari.

        this.init();
    }

    init() {
        // Pastikan folder database ada
        const dir = path.dirname(dbPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        // Load database jika ada
        if (fs.existsSync(dbPath)) {
            try {
                this.patterns = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            } catch (e) {
                // Jika corrupt, mulai dari kosong
                console.error(chalk.red("[ETERNAL] Database corrupted. Resetting memory patterns."));
                this.patterns = [];
            }
        }
    }

    /**
     * REFLEKS CEPAT (Hanya cek Database Hafalan)
     * Digunakan untuk bypass LLM jika pertanyaan sudah pernah dijawab sebelumnya.
     */
    fastReflex(input) {
        if (!input) return null;
        
        // Bersihkan input
        const lower = input.toLowerCase().trim().replace(/[?!.]/g, '');

        // Langsung cari di database pola yang sudah dipelajari
        return this.searchDatabase(lower);
    }

    /**
     * ALIAS FUNGSI (Untuk kompatibilitas)
     */
    reflex(input) {
        return this.fastReflex(input);
    }

    /**
     * ENGINE PENCARIAN POLA (Fuzzy Logic Sederhana)
     */
    searchDatabase(input) {
        let bestMatch = null;
        let highestScore = 0;

        for (const p of this.patterns) {
            let score = 0;
            
            // Cek setiap kata kunci (trigger)
            p.triggers.forEach(t => {
                // Gunakan Word Boundary (\b) agar akurat
                // Contoh: "bat" tidak akan match dengan "batu"
                const regex = new RegExp(`\\b${t}\\b`, 'i');
                if (regex.test(input)) score++;
            });

            // Threshold dinamis: Minimal cocok 50% dari trigger yang ada
            const threshold = Math.max(1, Math.floor(p.triggers.length * 0.5));
            
            if (score >= threshold && score > highestScore) {
                highestScore = score;
                bestMatch = p;
            }
        }

        if (bestMatch) {
            return { 
                text: bestMatch.response, 
                confidence: bestMatch.confidence || 1.0, 
                source: 'DB_PATTERN' 
            };
        }
        return null;
    }

    /**
     * MEKANISME BELAJAR (CONSOLIDATION)
     * Menyimpan pasangan Pertanyaan -> Jawaban ke Database
     */
    consolidate(input, output) {
        if (!input || !output) return;
        
        // 1. FILTER SAMPAH (Jangan simpan jawaban error/standar AI)
        const badPatterns = ["I cannot", "As an AI", "openai", "google", "language model", "maaf", "error"];
        if (badPatterns.some(p => output.toLowerCase().includes(p.toLowerCase()))) return;
        
        // Jangan simpan jawaban terlalu pendek (kurang informatif)
        if (output.length < 10) return;

        // 2. EKSTRAKSI KATA KUNCI (TRIGGERS)
        // Hanya ambil kata unik panjang (>3 huruf) sebagai pemicu ingatan
        const ignoredWords = ['kamu', 'saya', 'aku', 'dan', 'yang', 'ini', 'itu', 'adalah', 'lagi', 'apa', 'kenapa', 'bagaimana'];
        
        const triggers = input.toLowerCase()
            .replace(/[^\w\s]/g, '') // Hapus simbol aneh
            .split(/\s+/)
            .filter(w => w.length > 3 && !ignoredWords.includes(w))
            .slice(0, 5); // Ambil maks 5 kata kunci utama

        // Jika tidak ada kata kunci unik (misal cuma "lagi apa"), JANGAN SIMPAN.
        if (triggers.length === 0) return;

        // 3. CEK DUPLIKASI (Jangan simpan jawaban yang sama persis)
        const exists = this.patterns.find(p => p.response === output);
        if (exists) {
            exists.usage++; // Naikkan counter penggunaan
            this.save();
            return;
        }

        // 4. SIMPAN POLA BARU
        const newGene = {
            id: Date.now().toString(36),
            triggers: triggers,
            response: output,
            confidence: 0.5, // Confidence awal standar
            usage: 1,
            timestamp: Date.now()
        };

        this.patterns.push(newGene);
        this.save();
    }

    /**
     * PERSISTENCE (Tulis ke Hard Disk)
     */
    save() {
        try { 
            fs.writeFileSync(dbPath, JSON.stringify(this.patterns, null, 2)); 
        } catch (e) {
            console.error(chalk.red(`[ETERNAL] Save failed: ${e.message}`));
        }
    }
}

export default new EternalStorage();