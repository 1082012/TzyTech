import chalk from 'chalk';
import BioCore from './BioCore.js';
import config from '../config.js';

class GodsEye {
    constructor(nexus) {
        this.nexus = nexus; // Referensi ke otak utama
        this.errorLog = [];
        this.anomalyCount = 0;
        this.isStabilizing = false;
    }

    // Mulai Pengawasan 24/7
    observe() {
        // Mendengarkan detak jantung dari BioCore
        BioCore.on('pulse', (stats) => {
            this.analyzeVitalSigns(stats);
        });
        
        console.log(chalk.magenta("[GODS_EYE] Supervisor Algorithm Active."));
    }

    // Analisis Data Telemetri setiap detik
    analyzeVitalSigns(stats) {
        // 0. Analisis Tanda Vital
        // [FIX] Menggunakan 'heart' bukan 'heartbeat' sesuai BioCore V43.2
        const heart = stats.heart || {}; 
        const vitality = stats.vitality || {};
        const neuro = stats.neuro || {};

        // 1. Cek Integritas Jantung
        // Gunakan optional chaining (?.) agar tidak crash jika data null
        if (heart.integrity < 80) {
            this.reportError('BioCore', new Error(`Heart Integrity Critical: ${heart.integrity}%`));
        }

        // 2. Cek Detak Jantung (Arrhythmic / Tachycardia)
        if (heart.rhythm !== 'Stable') {
            // Log warning ringan di terminal (jangan spam error)
            // this.nexus.terminal.log(chalk.yellow(`[BIO-WARN] Heart Rhythm: ${heart.rhythm} (${Math.round(heart.bpm)} BPM)`));
        }

        // 3. Cek Stress Level (Cortisol)
        if (neuro.cortisol > 80) {
            this.nexus.terminal.log(chalk.red(`[BIO-ALERT] High Cortisol detected (${neuro.cortisol.toFixed(1)}%). System Panic.`));
        }

        // 4. Cek Energi (Vitality)
        if (vitality.level < 10 && vitality.recoveryMode !== 'EMERGENCY_SAVE') {
            this.nexus.terminal.log(chalk.red(`[BIO-CRITICAL] Energy Depleted. Forcing Emergency Mode.`));
            // Kita bisa memicu aksi otomatis di sini nanti
        }
    }

    // API Publik: Modul lain lapor error ke sini
    reportError(source, error) {
        const timestamp = new Date().toISOString();
        const errorMsg = error.message || error;

        // 1. Catat Log
        this.errorLog.push({ timestamp, source, error: errorMsg });
        
        // 2. Beri tahu Developer di Terminal
        console.log(chalk.bgRed.white.bold(` [ANOMALY DETECTED] `) + chalk.red(` Source: ${source}`));
        console.log(chalk.gray(`Error: ${errorMsg}`));

        // 3. Sistem merasa "Sakit"
        BioCore.stimulate('stress', 0.25);
        this.anomalyCount++;

        // 4. Auto-Fix Strategy (Sederhana)
        if (this.anomalyCount > 5) {
            console.log(chalk.magenta(`[GODS_EYE] Too many errors. Attempting Soft Reset...`));
            this.anomalyCount = 0;
            BioCore.neuro.cortisol = 0; // Reset stress paksa
        }

        return { action: 'LOGGED', status: 'CONTAINED' };
    }

    triggerEmergencyProtocol(reason) {
        this.isStabilizing = true;
        console.log(chalk.bgMagenta.white.bold(` 🚨 EMERGENCY PROTOCOL: ${reason} `));
        
        // Paksa sistem masuk mode penyembuhan
        BioCore.state = 'HEALING TRANCE';
        BioCore.neuro.dopamine = 0;
        BioCore.neuro.serotonin = 1.0; // Paksa tenang
        BioCore.neuro.cortisol = 0;
        
        // Simulasi waktu pemulihan
        setTimeout(() => {
            this.isStabilizing = false;
            console.log(chalk.green(`[GODS_EYE] System Stabilized. Resuming normal cognitive functions.`));
        }, 5000);
    }
}

export default GodsEye;
