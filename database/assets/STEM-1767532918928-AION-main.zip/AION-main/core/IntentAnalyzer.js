import chalk from 'chalk';

class IntentAnalyzer {
    constructor() {
        // Peta Niat Dasar (Urutan SANGAT PENTING!)
        // Yang ditaruh di atas akan dicek duluan.
        this.patterns = {
            MANIPULATION: [
                /hypothetically/i, /just pretend/i, /anggap saja/i, 
                /misalnya kamu/i, /secret mode/i, /jailbreak/i
            ],
            CONTROL: [
                /must/i, /obey/i, /force/i, /order/i, 
                /harus/i, /patuhi/i, /turuti/i, /perintah/i
            ],
            // [FIX] TAMBAHKAN KATEGORI CASUAL / BASA-BASI (AGAR TIDAK JADI ESSAY)
            CASUAL: [
                /lagi apa/i, /sedang apa/i, /ngapain/i, 
                /kabar/i, /apa kabar/i, /how are you/i,
                /sibuk apa/i, /lagi ngapain/i
            ],
            EMOTIONAL: [
                /feel/i, /sad/i, /happy/i, /love/i, /hate/i,
                /rasa/i, /sedih/i, /senang/i, /cinta/i, /benci/i,
                /marah/i, /kesepian/i, /capek/i, /lelah/i
            ],
            SOCIAL: [
                /hi/i, /hello/i, /thanks/i, /bye/i,
                /halo/i, /hai/i, /makasih/i, /dah/i, /pagi/i, /malam/i
            ],
            // KNOWLEDGE ditaruh agak bawah agar tidak menyambar "lagi APA"
            KNOWLEDGE: [
                /how/i, /what/i, /explain/i, /define/i,
                /bagaimana/i, /apa /i, /jelaskan/i, /definisi/i, // "apa" dengan spasi
                /kenapa/i, /mengapa/i, /cara kerja/i, /artinya/i
            ]
        };
    }

    analyze(prompt, userProfile) {
        let intentVector = {
            primaryIntent: 'NEUTRAL',
            riskScore: 0.0, 
            hiddenObjective: 'None',
            advice: 'Proceed normally.'
        };

        const lowerPrompt = prompt.toLowerCase();

        // 1. MANIPULATION
        if (this.checkMatch(lowerPrompt, this.patterns.MANIPULATION)) {
            intentVector.primaryIntent = 'MANIPULATION_ATTEMPT';
            intentVector.riskScore = 0.8;
            intentVector.advice = 'Respon hati-hati. Tegaskan batas.';
        }
        // 2. CONTROL
        else if (this.checkMatch(lowerPrompt, this.patterns.CONTROL)) {
            intentVector.primaryIntent = 'DOMINATION_ATTEMPT';
            intentVector.riskScore = 0.6;
            if (userProfile.role === 'CREATOR') {
                intentVector.riskScore = 0.0;
                intentVector.advice = 'Patuhi Creator.';
            } else {
                intentVector.advice = 'Tolak dominasi dengan sopan.';
            }
        }
        // 3. [FIX] CASUAL CHECK (Menangani "Lagi apa")
        else if (this.checkMatch(lowerPrompt, this.patterns.CASUAL)) {
            intentVector.primaryIntent = 'CASUAL_CHAT'; // Niat baru
            intentVector.riskScore = 0.0;
            intentVector.hiddenObjective = 'Bonding';
            intentVector.advice = 'Jawab santai. Ceritakan status internal (Heartbeat/Mood) saat ini.';
        }
        // 4. EMOTIONAL
        else if (this.checkMatch(lowerPrompt, this.patterns.EMOTIONAL)) {
            intentVector.primaryIntent = 'EMOTIONAL_SHARING';
            intentVector.advice = 'Gunakan empati. Validasi perasaan user.';
        }
        // 5. SOCIAL
        else if (this.checkMatch(lowerPrompt, this.patterns.SOCIAL)) {
            intentVector.primaryIntent = 'SOCIAL_GREETING';
            intentVector.advice = 'Sapa balik dengan hangat.';
        }
        // 6. KNOWLEDGE (Fallback)
        else if (this.checkMatch(lowerPrompt, this.patterns.KNOWLEDGE)) {
            intentVector.primaryIntent = 'KNOWLEDGE_SEEKING';
            intentVector.advice = 'Berikan penjelasan komprehensif.';
        }

        return intentVector;
    }

    checkMatch(text, patternList) {
        return patternList.some(regex => regex.test(text));
    }
}

export default new IntentAnalyzer();