import fs from 'fs';
import path from 'path';
import config from '../config.js'; // Load default config

const dbPath = path.join(process.cwd(), 'database', 'settings.json');

class SettingsManager {
    constructor() {
        this.data = {};
        this.init();
    }

    init() {
        // 1. Pastikan folder database ada
        const dir = path.dirname(dbPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        // 2. Jika file settings.json belum ada, buat dari default config.js
        if (!fs.existsSync(dbPath)) {
            this.data = {
                system: {
                    prefixMode: config.system.prefixMode,
                    prefixes: config.system.prefixes,
                    ownerNumber: config.system.ownerNumber
                }
                // Tambah settingan lain di sini jika perlu
            };
            this.save();
        } else {
            // 3. Jika ada, load isinya ke memori
            try {
                this.data = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            } catch (e) {
                console.error("[SETTINGS] Corrupt JSON, resetting to default.");
                this.data = {};
            }
        }
    }

    get(key) {
        // Ambil data dari JSON, kalau gak ada ambil dari config.js (Fallback)
        return this.data.system?.[key] || config.system[key];
    }

    set(key, value) {
        if (!this.data.system) this.data.system = {};
        
        // Update memori
        this.data.system[key] = value;
        
        // Simpan ke file (Persisten)
        this.save();
    }

    save() {
        fs.writeFileSync(dbPath, JSON.stringify(this.data, null, 2));
    }
}

// Export sebagai Singleton (Satu instance untuk seluruh aplikasi)
export default new SettingsManager();