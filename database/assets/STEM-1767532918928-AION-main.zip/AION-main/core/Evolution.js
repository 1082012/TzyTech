import BioCore from './BioCore.js';
import Settings from './Settings.js';
import chalk from 'chalk';

class EvolutionarySystem {
    constructor() {
        // Load data evolusi dari BioCore
        this.data = BioCore.state.evolution;
    }

    // Menambah XP berdasarkan kualitas interaksi
    gainXP(amount, reason = "") {
        const oldLevel = this.data.level;
        
        // Bonus XP jika Mood sedang FLOW STATE
        if (BioCore.state.affect.current === 'FLOW_STATE') {
            amount *= 1.5; // Bonus 50%
        }

        this.data.xp += amount;

        // Cek Level Up (Tiap 100 XP)
        if (this.data.xp >= 100) {
            this.levelUp();
        }

        BioCore.save(); // Simpan progress
    }

    levelUp() {
        this.data.xp = this.data.xp % 100; // Reset XP sisa
        this.data.level++;
        
        // REWARD EVOLUSI (STAT BOOST)
        // Setiap naik level, otak makin efisien (Energy Burn berkurang sedikit)
        BioCore.state.vitality.burnRate = Math.max(0.005, BioCore.state.vitality.burnRate - 0.0001);
        
        // Kapasitas Hormon Stabil membaik
        BioCore.state.neuro.learningDelta += 0.001;

        console.log(chalk.magenta(`
🌟 [EVOLUTION] LEVEL UP!
━━━━━━━━━━━━━━━━━━━━━━━━
Current Level : ${this.data.level}
Efficiency    : +0.01%
Intelligence  : ${BioCore.state.neuro.learningDelta.toFixed(3)}
Trajectory    : ${this.data.trajectory}
        `));
    }

    // Skill Crystallization (Menyimpan pencapaian)
    crystallizeSkill(skillName) {
        // Nanti bisa dihubungkan ke EternalStorage untuk buka fitur baru
        console.log(chalk.blue(`[EVO] Skill Crystallized: ${skillName}`));
    }
}

export default new EvolutionarySystem();