import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import chalk from 'chalk';

class SystemDoctor {
    constructor(nexus) {
        this.nexus = nexus;
        this.isRepairing = false;
    }

    /**
     * MENDIAGNOSA DAN MEMPERBAIKI ERROR
     * @param {Error} errorObj - Objek error asli
     * @param {String} filePath - Lokasi file yang error
     */
    async heal(errorObj, filePath) {
        if (this.isRepairing) return; // Jangan tumpuk perbaikan
        if (!this.nexus.cognitive) {
            console.error(chalk.red("[DOCTOR] Cannot heal: Cognitive Cortex not found/ready."));
            return;
        }
        
        this.isRepairing = true;

        console.log(chalk.red.bold(`[DOCTOR] 🚑 CRITICAL DAMAGE DETECTED AT: ${filePath}`));
        console.log(chalk.red(`[DOCTOR] Error: ${errorObj.message}`));

        try {
            // 1. BACA KODE RUSAK
            const originalCode = fs.readFileSync(filePath, 'utf8');

            // 2. KONSULTASI KE CORTEX (LLM)
            const prompt = `
            [SYSTEM REPAIR REQUEST]
            FILE: ${filePath}
            ERROR: ${errorObj.message}
            STACK: ${errorObj.stack}

            SOURCE CODE:
            \`\`\`javascript
            ${originalCode}
            \`\`\`

            TUGAS: Perbaiki kode di atas agar error hilang. 
            JANGAN ubah logika inti. HANYA perbaiki bugnya.
            Kirimkan HANYA kode Javascript lengkap yang sudah diperbaiki di dalam block code.
            `;

            // Kita pakai mode khusus 'SYSTEM_REPAIR' agar LLM serius
            const response = await this.nexus.cognitive.process('SYSTEM_DOCTOR', prompt);
            
            // Ekstrak kode dari markdown ```javascript ... ```
            const fixedCode = this.extractCode(response);
            if (!fixedCode) throw new Error("LLM gagal memberikan kode valid.");

            // 3. SANDBOX TESTING (UJI COBA)
            // Tulis ke file bayangan
            const tempFile = filePath.replace('.js', '.temp.js');
            fs.writeFileSync(tempFile, fixedCode);

            console.log(chalk.yellow(`[DOCTOR] 🧪 Testing fix in Sandbox: ${tempFile}...`));
            
            // Cek Syntax Error dengan node -c (Check)
            await this.syntaxCheck(tempFile);

            // 4. DEPLOYMENT (OPERASI BEDAH)
            // Backup file asli dulu
            fs.copyFileSync(filePath, filePath + '.bak');
            // Timpa file asli dengan yang baru
            fs.renameSync(tempFile, filePath);

            console.log(chalk.green.bold(`[DOCTOR] ✅ REPAIR SUCCESSFUL. System patched.`));
            console.log(chalk.gray(`[DOCTOR] Original file backed up to .bak`));

        } catch (e) {
            console.error(chalk.red(`[DOCTOR] 💀 Repair Failed: ${e.message}`));
            // Hapus file temp jika ada
        } finally {
            this.isRepairing = false;
        }
    }

    extractCode(text) {
        const match = text.match(/```javascript([\s\S]*?)```/) || text.match(/```js([\s\S]*?)```/);
        return match ? match[1].trim() : null;
    }

    syntaxCheck(file) {
        return new Promise((resolve, reject) => {
            exec(`node -c ${file}`, (error, stdout, stderr) => {
                if (error) reject(error);
                else resolve();
            });
        });
    }
}

export default SystemDoctor;