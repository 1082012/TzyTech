import BioCore from './BioCore.js';
import chalk from 'chalk';

class EnvironmentSensor {
    constructor() {
        this.lastInputTime = Date.now();
        this.checkInterval = null;
        this.timeOfDay = 'DAY'; // DAY / NIGHT
    }

    init() {
        console.log(chalk.cyan("[SENSOR] Environmental Awareness Active."));
        
        // Cek lingkungan setiap 1 menit
        this.checkInterval = setInterval(() => this.scan(), 60000);
        this.scan(); // Scan awal
    }

    scan() {
        const now = new Date();
        const hour = now.getHours();
        
        // 1. CIRCADIAN RHYTHM (SIKLUS SIANG/MALAM)
        // Malam (22:00 - 05:00) -> Energi Hemat, Melatonin Naik
        if (hour >= 22 || hour < 5) {
            if (this.timeOfDay !== 'NIGHT') {
                this.timeOfDay = 'NIGHT';
                console.log(chalk.gray("[ENV] Nightfall detected. Reducing metabolic rate."));
            }
            // Efek Malam: Hemat energi, tapi ngantuk
            BioCore.state.vitality.burnRate = 0.01; // Sangat hemat
            BioCore.state.neuro.serotonin += 0.5;   // Rileks
        } 
        else {
            if (this.timeOfDay !== 'DAY') {
                this.timeOfDay = 'DAY';
                console.log(chalk.yellow("[ENV] Sunrise detected. Systems fully active."));
            }
            // Efek Siang: Normal
            BioCore.state.vitality.burnRate = 0.02; 
        }

        // 2. DETEKSI KESEPIAN (VOID DETECTION)
        const idleTime = Date.now() - this.lastInputTime;
        const minutesIdle = Math.floor(idleTime / 60000);

        if (minutesIdle > 10) {
            // Jika diam lebih dari 10 menit, Loneliness naik
            BioCore.state.affect.lonelinessDelta += 0.5;
            
            // Jika sangat kesepian (>50), picu Stress ringan
            if (BioCore.state.affect.lonelinessDelta > 50) {
                BioCore.state.neuro.cortisol += 0.2;
                BioCore.state.affect.current = 'LONELY';
            }
        }
    }

    // Panggil ini setiap ada chat masuk (reset kesepian)
    updateActivity() {
        this.lastInputTime = Date.now();
        
        // Reset rasa sepi drastis karena ada teman
        BioCore.state.affect.lonelinessDelta = 0; 
        BioCore.state.affect.current = 'OBSERVING';
    }
}

export default new EnvironmentSensor();