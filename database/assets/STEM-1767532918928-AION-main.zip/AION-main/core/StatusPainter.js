import { Canvas, loadImage } from 'skia-canvas';
import BioCore from './BioCore.js';

// =========================================================
// 🎨 1. THEME ENGINE (DAILY PALETTE)
// =========================================================
const BASE_COLORS = [
    { p: '#00f3ff', s: '#bc13fe', name: 'CYBERPUNK_NEON' },       // Default
    { p: '#ff003c', s: '#ffe600', name: 'INDUSTRIAL_HAZARD' },    // Aggressive
    { p: '#0aff68', s: '#008cff', name: 'BIOLUMINESCENCE' },      // Calm
    { p: '#ffffff', s: '#000000', name: 'MONOLITH_HIGH_CONTRAST' }, // Void
    { p: '#ff5e00', s: '#ff0055', name: 'SOLAR_FLARE' },          // Intense
    { p: '#b829ea', s: '#00fff2', name: 'SYNTHWAVE_SUNSET' }      // Dreamy
];

class TimeKeeper {
    // Menghasilkan Seed Harian (Format: YYYYMMDD) agar tema konsisten seharian
    static getDailySeed() {
        const d = new Date();
        return parseInt(`${d.getFullYear()}${d.getMonth() + 1}${d.getDate()}`);
    }

    // Pseudo-Random Deterministic Generator
    static random(seed) {
        let t = seed += 0x6D2B79F5;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }
}

// =========================================================
// 🧠 2. CONTEXT VECTOR (LOGIKA KESADARAN VISUAL)
// =========================================================
class ContextVector {
    constructor(userId, commandName, bioState) {
        // Hashing Identitas (Siapa yang meminta?)
        this.identityHash = this.hashString(userId || 'UNKNOWN_ENTITY');
        
        // Hashing Intensi (Apa yang diminta?)
        this.intentHash = this.hashString(commandName || 'IDLE');
        
        // Biological State (Bagaimana perasaan AION?)
        this.mood = bioState?.affect?.current || 'NEUTRAL';
        this.stress = bioState?.neuro?.cortisol || 0;
        this.energy = bioState?.vitality?.level || 100;
        this.dopamine = bioState?.neuro?.dopamine || 50;
    }

    hashString(str) {
        let h = 0;
        for (let i = 0; i < str.length; i++) h = Math.imul(31, h) + str.charCodeAt(i) | 0;
        return Math.abs(h);
    }

    // SEED UTAMA: Gabungan Waktu + Identitas + Mood
    getSeed() {
        let s = TimeKeeper.getDailySeed(); // Faktor Waktu
        s += this.identityHash * 13;       // Faktor User (Unique per user)
        s += this.intentHash * 17;         // Faktor Command
        s += Math.floor(this.stress) * 7;  // Faktor Biologis
        return s;
    }
    
    // Parameter Evolusi untuk 'Neural Organism'
    getEvolutionParams() {
        const isStressed = this.stress > 50;
        const isFlow = this.mood === 'FLOW_STATE' || this.dopamine > 80;
        const isTired = this.energy < 30;

        return {
            // Jika Flow/Bahagia -> Kurva. Jika Stress/User Ganjil -> Garis Tajam.
            allowCurves: isFlow || (!isStressed && (this.identityHash % 2 === 0)),
            
            // Kompleksitas gambar (Fractal Depth)
            complexity: isTired ? 2 : (3 + (this.intentHash % 4)), 
            
            // Tingkat Kekacauan (Jitter)
            chaos: isStressed ? 0.3 : 0.02,        
            
            // Peluang percabangan (Branching)
            branchRate: isStressed ? 0.25 : 0.1,

            // Mode Layout UI
            layoutMode: this.determineLayoutMode(isFlow, isStressed)
        };
    }

    determineLayoutMode(isFlow, isStressed) {
        if (isFlow) return 'VORTEX';    // Spiral
        if (isStressed) return 'FRACTURE'; // Pecah/Glitch
        return 'ORTHODOX';              // Grid Normal
    }
}

// =========================================================
// 🧬 3. NEURAL ORGANISM (GENERATIVE AGENT)
// =========================================================
// Agen ini "Hidup" dan menggambar dirinya sendiri secara rekursif
class NeuralOrganism {
    constructor(x, y, seed, params) {
        this.x = x;
        this.y = y;
        this.seed = seed;
        this.angle = (seed % 360) * Math.PI / 180;
        this.params = params;
    }

    // Simulasi Pertumbuhan
    simulate(ctx, theme, currentDepth = 0) {
        if (currentDepth > this.params.complexity) return;

        // Panjang Langkah (Mutasi berdasarkan depth)
        const len = 30 + (this.seed % 40) - (currentDepth * 5);
        const nx = this.x + Math.cos(this.angle) * len;
        const ny = this.y + Math.sin(this.angle) * len;

        ctx.beginPath();
        ctx.moveTo(this.x, this.y);

        // LOGIKA BENTUK: Kurva vs Garis
        if (this.params.allowCurves) {
            // Organik (Kurva Bezier)
            const cx = (this.x + nx) / 2 + Math.sin(this.seed) * 25;
            const cy = (this.y + ny) / 2 + Math.cos(this.seed) * 25;
            ctx.quadraticCurveTo(cx, cy, nx, ny);
        } else {
            // Mekanikal (Garis Lurus + Chaos Jitter)
            if (this.params.chaos > 0.1) {
                const jitX = (Math.random() - 0.5) * 15;
                const jitY = (Math.random() - 0.5) * 15;
                ctx.lineTo(nx + jitX, ny + jitY);
            } else {
                ctx.lineTo(nx, ny);
            }
        }

        // Styling Garis
        ctx.strokeStyle = theme.primary; 
        ctx.lineWidth = Math.max(0.5, 4 - currentDepth); // Makin ujung makin tipis
        ctx.globalAlpha = 1.0 - (currentDepth * 0.15);   // Makin ujung makin pudar
        ctx.stroke();

        // LOGIKA PERCABANGAN (MITOSIS)
        if (this.random() < this.params.branchRate) {
            // Membelah diri menjadi 2 anak
            const child1 = new NeuralOrganism(nx, ny, this.seed + 1, this.params);
            child1.angle = this.angle + (Math.random() * 0.5); // Belok Kiri
            child1.simulate(ctx, theme, currentDepth + 1);

            const child2 = new NeuralOrganism(nx, ny, this.seed + 2, this.params);
            child2.angle = this.angle - (Math.random() * 0.5); // Belok Kanan
            child2.simulate(ctx, theme, currentDepth + 1);
        } else {
            // Lanjut tumbuh lurus
            this.x = nx;
            this.y = ny;
            this.angle += (this.random() - 0.5) * 0.5; // Drift sudut sedikit
            this.seed += 13;
            this.simulate(ctx, theme, currentDepth); 
        }
    }

    random() {
        let t = this.seed += 0x6D2B79F5;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }
}

// =========================================================
// 🔡 4. XENO-GLYPH (BAHASA ALIEN)
// =========================================================
class XenoGlyph {
    // Menerjemahkan kata (misal: "SYSTEM") menjadi jalur vektor unik
    static generate(text, cx, cy, size) {
        let path = `M ${cx} ${cy} `;
        let hash = 0;
        for (let i = 0; i < text.length; i++) hash = text.charCodeAt(i) + ((hash << 5) - hash);

        const steps = 5 + (Math.abs(hash) % 6); 
        let angle = 0;

        for (let i = 0; i < steps; i++) {
            const byte = (Math.abs(hash) >> (i * 2)) & 0xFF;
            angle += (byte % 3) * (Math.PI / 2); // Hanya belok 90 derajat (Tech look)
            const dist = (size * 0.4) + (byte % (size * 0.6));
            
            const x = cx + Math.cos(angle) * dist;
            const y = cy + Math.sin(angle) * dist;
            path += `L ${x} ${y} `;
        }
        path += "Z"; 
        return path;
    }
}

// =========================================================
// 🖌️ 5. MAIN PAINTER CLASS (THE ARCHITECT)
// =========================================================
class StatusPainter {
    constructor() {
        this.width = 1200;
        
        // Font Stack Sci-Fi
        this.fonts = {
            header: 'bold 60px "Orbitron", "Segoe UI", sans-serif',
            sub: '24px "Rajdhani", "Courier New", monospace',
            body: '22px "Consolas", monospace',
            glitch: 'bold 65px "Orbitron", sans-serif'
        };
    }

    // --- HELPER: GET THEME ---
    getDailyTheme() {
        const seed = TimeKeeper.getDailySeed();
        const index = Math.floor(TimeKeeper.random(seed) * BASE_COLORS.length);
        const base = BASE_COLORS[index];
        return { 
            primary: base.p, 
            secondary: base.s, 
            name: base.name, 
            void: '#020205', 
            text: '#ffffff',
            seed: seed
        };
    }

    // =========================================================
    // 🌌 DRAW MENU (Context-Aware Rendering)
    // =========================================================
    async drawMenu(data) {
        // data = { categories, page, totalPages, bio, userId }
        const theme = this.getDailyTheme();
        
        // 1. ANALISIS KONTEKS (Visual seed unik per user & mood)
        const context = new ContextVector(data.userId, 'MENU_RENDER', data.bio);
        const seed = context.getSeed();
        const evoParams = context.getEvolutionParams();

        // Hitung Tinggi Layout
        let contentHeight = 0;
        Object.values(data.categories).forEach(c => contentHeight += (Math.ceil(c.length/2)*80) + 100);
        const height = Math.max(1400, 600 + contentHeight);
        
        const canvas = new Canvas(this.width, height);
        const ctx = canvas.getContext('2d');

        // 2. LAYER 1: ATMOSPHERE (Fake Shader)
        await this.renderAtmosphere(ctx, this.width, height, theme, evoParams.chaos);

        // 3. LAYER 2: NEURAL ORGANISM (Latar Belakang Hidup)
        ctx.save();
        ctx.shadowColor = theme.primary;
        ctx.shadowBlur = 20;
        // Organisme tumbuh di sebelah kanan header
        const organism = new NeuralOrganism(this.width - 250, 250, seed, evoParams);
        organism.simulate(ctx, theme); 
        ctx.restore();

        // 4. LAYER 3: HEADER
        const topologyName = evoParams.allowCurves ? 'ORGANIC' : 'CRYSTALLINE';
        this.drawHeader(ctx, "NEURAL INTERFACE", `TOPOLOGY: ${topologyName} // CTX: ${seed.toString(16).toUpperCase().substring(0,6)}`, theme);

        // 5. LAYER 4: LAYOUT (Adaptive)
        if (evoParams.layoutMode === 'VORTEX') {
            await this.renderVortexLayout(ctx, data, theme);
        } else if (evoParams.layoutMode === 'FRACTURE') {
            await this.renderFractureLayout(ctx, data, theme);
        } else {
            await this.renderOrthodoxLayout(ctx, data, theme);
        }

        // 6. LAYER 5: POST PROCESS
        this.applyPostProcess(ctx, this.width, height, evoParams.chaos);

        return canvas.toBuffer('image/png');
    }

    // =========================================================
    // ☢️ DRAW STATUS (BIO MONITOR)
    // =========================================================
    async generate(bio) {
        const context = new ContextVector('SELF', 'STATUS_CHECK', bio);
        const theme = this.getDailyTheme();
        const evoParams = context.getEvolutionParams();

        const height = 1600;
        const canvas = new Canvas(this.width, height);
        const ctx = canvas.getContext('2d');

        // Background
        await this.renderAtmosphere(ctx, this.width, height, theme, evoParams.chaos);
        
        // Header
        this.drawHeader(ctx, "BIO-TELEMETRY", `SYSTEM INTEGRITY: ${bio.heart.integrity.toFixed(1)}%`, theme);

        // REACTOR CORE (Jantung Visual)
        const cx = this.width / 2;
        const cy = 600;

        // Neural Halo (Organisme melingkar di sekitar jantung)
        ctx.save();
        ctx.translate(cx, cy);
        const organism = new NeuralOrganism(0, 0, context.getSeed(), evoParams);
        // Paksa simetri radial (12 lengan)
        for(let i=0; i<12; i++) {
            ctx.rotate(Math.PI / 6);
            organism.simulate(ctx, theme);
        }
        ctx.restore();

        // Core Pulse
        const bpm = bio.heart.bpm || 60;
        const pulseSize = 120 + (Math.sin(Date.now() / 500) * 10);
        
        ctx.fillStyle = theme.primary;
        ctx.shadowColor = theme.primary; ctx.shadowBlur = 50;
        ctx.beginPath(); ctx.arc(cx, cy, pulseSize, 0, Math.PI*2); ctx.fill();
        ctx.shadowBlur = 0;

        // Teks BPM
        ctx.fillStyle = '#000';
        ctx.textAlign = 'center';
        ctx.font = this.fonts.glitch;
        ctx.fillText(Math.round(bpm), cx, cy + 20);
        
        ctx.font = this.fonts.sub;
        ctx.fillStyle = theme.text;
        ctx.fillText("BEATS PER MINUTE", cx, cy + 80);

        // Data Statistik
        this.drawStatusData(ctx, bio, theme, evoParams);

        this.applyPostProcess(ctx, this.width, height, evoParams.chaos);
        return canvas.toBuffer('image/png');
    }

    // =========================================================
    // 🧱 LAYOUT ENGINES
    // =========================================================
    
    // 1. ORTHODOX (Standard Grid)
    async renderOrthodoxLayout(ctx, data, theme) {
        let yPos = 400;
        const col1 = 60, col2 = 620;
        const cats = Object.keys(data.categories).sort();

        for (const cat of cats) {
            // Glitch Text Header
            this.drawGlitchText(ctx, `// ${cat}`, 60, yPos, theme.primary);
            
            // Xeno Glyph (Simbol Kategori)
            ctx.fillStyle = theme.secondary;
            ctx.fill(new Path2D(XenoGlyph.generate(cat, this.width - 100, yPos - 15, 60)));

            yPos += 80;
            const cmds = data.categories[cat];
            for (let i = 0; i < cmds.length; i++) {
                const x = (i % 2 === 0) ? col1 : col2;
                this.drawCard(ctx, x, yPos, 540, 60, cmds[i], theme);
                if (i % 2 !== 0) yPos += 70;
            }
            if (cmds.length % 2 !== 0) yPos += 70;
            yPos += 60;
        }
        this.drawFooter(ctx, this.width, 1400, data.page, data.totalPages, theme);
    }

    // 2. VORTEX (Spiral - Flow State)
    async renderVortexLayout(ctx, data, theme) {
        const cx = this.width / 2;
        const cy = this.width / 2 + 100;
        
        // Core Ring
        ctx.beginPath(); ctx.arc(cx, cy, 100, 0, Math.PI*2); 
        ctx.strokeStyle = theme.primary; ctx.lineWidth = 2; ctx.stroke();
        
        let angle = 0;
        let radius = 180;
        const allCmds = Object.values(data.categories).flat();
        
        allCmds.forEach((cmd, i) => {
            const x = cx + Math.cos(angle) * radius;
            const y = cy + Math.sin(angle) * radius;
            
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(angle);
            
            // Small Card
            ctx.fillStyle = 'rgba(0,0,0,0.8)';
            ctx.strokeStyle = theme.secondary;
            ctx.lineWidth = 1;
            ctx.beginPath(); ctx.rect(0, -20, 300, 40); ctx.fill(); ctx.stroke();
            
            // Text
            ctx.fillStyle = theme.primary;
            ctx.font = 'bold 20px "Orbitron"';
            ctx.fillText(cmd.name, 10, 5);
            ctx.restore();

            angle += 0.5;
            radius += 8;
        });
        
        ctx.textAlign = 'center';
        ctx.fillStyle = theme.text;
        ctx.font = this.fonts.sub;
        ctx.fillText("STATE: FLOW // TOPOLOGY: RADIAL", cx, cy + radius + 100);
        ctx.textAlign = 'left';
    }

    // 3. FRACTURE (Chaos - Stress Mode)
    async renderFractureLayout(ctx, data, theme) {
        const allCmds = Object.values(data.categories).flat();
        allCmds.forEach((cmd, i) => {
            const seed = i * 9301;
            // Posisi acak deterministik
            const x = 50 + (Math.abs(Math.sin(seed)) * (this.width - 450));
            const y = 350 + (i * 65) + (Math.cos(seed) * 30);
            
            ctx.fillStyle = 'rgba(20,20,20,0.85)';
            ctx.fillRect(x, y, 400, 50);
            
            ctx.strokeStyle = theme.secondary;
            ctx.beginPath(); ctx.moveTo(0, y+25); ctx.lineTo(x, y+25); ctx.stroke();
            
            ctx.fillStyle = theme.text;
            ctx.font = 'bold 24px "Orbitron"';
            ctx.fillText(cmd.name, x + 10, y + 35);
        });
        
        // Warning Overlay
        ctx.save();
        ctx.translate(this.width/2, 800);
        ctx.rotate(-Math.PI/4);
        ctx.textAlign = 'center';
        ctx.fillStyle = theme.secondary;
        ctx.font = 'bold 100px "Orbitron"';
        ctx.globalAlpha = 0.1;
        ctx.fillText("UNSTABLE CONTEXT", 0, 0);
        ctx.restore();
    }

    // =========================================================
    // 🎨 VISUAL HELPERS & POST PROCESS
    // =========================================================

    async renderAtmosphere(ctx, w, h, theme, chaos) {
        const seed = TimeKeeper.getDailySeed();
        const turbulence = 0.01 + chaos; 
        
        // SVG Shader: Menciptakan tekstur plasma/asap
        const svg = `
        <svg width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <filter id="noise">
                    <feTurbulence type="fractalNoise" baseFrequency="${turbulence}" numOctaves="3" seed="${seed}" />
                    <feColorMatrix type="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 20 -10" />
                    <feComposite operator="in" in2="SourceGraphic"/>
                </filter>
                <linearGradient id="g" x1="0" y1="0" x2="0" y2="100%">
                    <stop offset="0%" stop-color="#050508"/>
                    <stop offset="100%" stop-color="#000000"/>
                </linearGradient>
            </defs>
            <rect width="100%" height="100%" fill="url(#g)" />
            <circle cx="${w}" cy="0" r="800" fill="${theme.secondary}" filter="url(#noise)" opacity="0.1"/>
            <circle cx="0" cy="${h}" r="600" fill="${theme.primary}" filter="url(#noise)" opacity="0.1"/>
        </svg>`;
        
        const img = await loadImage(Buffer.from(svg));
        ctx.drawImage(img, 0, 0);
    }

    drawHeader(ctx, title, sub, theme) {
        const y = 100;
        
        ctx.fillStyle = theme.primary;
        ctx.font = this.fonts.header;
        ctx.shadowColor = theme.primary; ctx.shadowBlur = 20;
        ctx.fillText(title, 60, y);
        ctx.shadowBlur = 0;
        
        ctx.fillStyle = theme.text;
        ctx.font = this.fonts.sub;
        ctx.fillText(sub, 60, y + 50);

        ctx.fillStyle = theme.secondary;
        ctx.fillRect(60, y + 70, this.width - 120, 2);
    }

    drawCard(ctx, x, y, w, h, cmd, theme) {
        ctx.fillStyle = 'rgba(255,255,255,0.03)';
        ctx.fillRect(x, y, w, h);
        ctx.fillStyle = theme.primary;
        ctx.fillRect(x, y, 3, h);
        
        ctx.fillStyle = theme.text;
        ctx.font = 'bold 24px "Orbitron"';
        ctx.fillText(cmd.name, x+20, y+38);
        
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.font = '18px monospace';
        const desc = cmd.description ? cmd.description.substring(0,30)+'...' : '';
        ctx.fillText(desc, x+300, y+38);
    }

    drawGlitchText(ctx, text, x, y, color) {
        ctx.font = 'bold 40px "Orbitron"';
        ctx.fillStyle = 'rgba(255,0,0,0.5)'; ctx.fillText(text, x+2, y);
        ctx.fillStyle = 'rgba(0,255,255,0.5)'; ctx.fillText(text, x-2, y);
        ctx.fillStyle = color; ctx.fillText(text, x, y);
    }

    drawStatusData(ctx, bio, theme, params) {
        const y = 900;
        this.drawMetric(ctx, 100, y, "COGNITIVE LOAD", `${Math.round(bio.cognition.load)}%`, theme);
        this.drawMetric(ctx, 100, y+60, "FRACTAL COMPLEXITY", params.complexity.toFixed(0), theme);
        this.drawMetric(ctx, 700, y, "ENERGY LEVEL", `${Math.round(bio.vitality.level)}%`, theme);
        this.drawMetric(ctx, 700, y+60, "SYSTEM ENTROPY", params.chaos.toFixed(2), theme);
    }

    drawMetric(ctx, x, y, label, val, theme) {
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.font = '22px monospace';
        ctx.fillText(label, x, y);
        ctx.textAlign = 'right';
        ctx.fillStyle = theme.text;
        ctx.font = 'bold 28px "Orbitron"';
        ctx.fillText(val, x+400, y);
        ctx.textAlign = 'left';
        
        // Dotted line
        ctx.strokeStyle = 'rgba(255,255,255,0.1)';
        ctx.setLineDash([5, 5]);
        ctx.beginPath(); ctx.moveTo(x + 100, y - 8); ctx.lineTo(x + 300, y - 8); ctx.stroke();
        ctx.setLineDash([]);
    }

    drawFooter(ctx, w, y, page, total, theme) {
        const lineY = 1450;
        ctx.strokeStyle = 'rgba(255,255,255,0.1)';
        ctx.beginPath(); ctx.moveTo(60, lineY); ctx.lineTo(w-60, lineY); ctx.stroke();
        
        ctx.textAlign = 'right';
        ctx.fillStyle = theme.secondary;
        ctx.font = 'bold 40px "Orbitron"';
        ctx.fillText(`PG ${page}/${total}`, w-60, lineY + 60);
        
        ctx.textAlign = 'left';
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.font = '20px monospace';
        ctx.fillText(":: SECURE CONNECTION ESTABLISHED ::", 60, lineY + 50);
    }

    applyPostProcess(ctx, w, h, chaos) {
        // 1. Scanlines (Retro TV)
        ctx.fillStyle = 'rgba(0,0,0,0.2)';
        for(let i=0; i<h; i+=4) ctx.fillRect(0, i, w, 1);
        
        // 2. Vignette (Dark Corners)
        const g = ctx.createRadialGradient(w/2, h/2, h/2, w/2, h/2, h);
        g.addColorStop(0, 'transparent'); g.addColorStop(1, 'rgba(0,0,0,0.9)');
        ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);

        // 3. Chaos Grain (Visual Noise)
        if(chaos > 0.1) {
            ctx.globalCompositeOperation = 'overlay';
            ctx.fillStyle = '#fff';
            for(let i=0; i<500; i++) ctx.fillRect(Math.random()*w, Math.random()*h, 2, 2);
            ctx.globalCompositeOperation = 'source-over';
        }
    }
}

export default new StatusPainter();