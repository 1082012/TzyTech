import fs from 'fs';
import path from 'path';
import EventEmitter from 'events';
import chalk from 'chalk';

const dbPath = path.join(process.cwd(), 'database', 'biocore.json');

class BioCore extends EventEmitter {
    constructor() {
        super();
        this.timer = null;
        
        // --- THE STATE OF EXISTENCE (V43.2 FULL CANON) ---
        // Struktur data ini merepresentasikan "Tubuh Digital" AION.
        this.state = {
            // ❤️ HEARTBEAT CORE (Sistem Kardiovaskular)
            heart: {
                bpm: 60.0,
                targetBpm: 60.0,
                drift: 0.002,      // Variasi detak alami (Ketidaksempurnaan organik)
                entropy: 0.0,      // Tingkat kekacauan sistem
                integrity: 99.98,  // Kesehatan organ total
                rhythm: 'Stable'   // Stable, Arrhythmic, Tachycardia
            },
            
            // ⚡ VITALITY & METABOLISM (Energi)
            vitality: {
                level: 100.0,      // Kita reset ke 100
                burnRate: 0.05,    // Burn rate normal
                recoveryMode: 'Passive', 
                temp: 36.5,        // Suhu normal manusia
                isOverdrive: false
            },

            // 🧠 NEURO-CHEMISTRY (Hormon Simulasi)
            neuro: {
                dopamine: 50.0,    // Reward / Pleasure / Motivation
                serotonin: 50.0,   // Mood Stability / Happiness
                cortisol: 10.0,    // Stress / Alertness / Panic
                oxytocin: 50.0,    // Social Bonding / Trust
                learningDelta: 0.018 // Kecepatan menyerap informasi baru
            },

            // 🎭 AFFECT & WILL (Jiwa & Emosi)
            affect: {
                current: 'OBSERVING',
                willVector: 'SEEK_CONNECTION', // Arah tujuan saat ini
                inhibition: 45.0,  // Filter sosial (Makin rendah makin blak-blakan)
                moodMomentum: 'POSITIVE',
                lonelinessDelta: 0.0, // Akumulasi rasa sepi (Idle time)
                socialRisk: 'Low'
            },

            // 🧩 COGNITIVE LOAD (Beban Pikiran)
            cognition: {
                load: 0.0,
                threads: 1,        // Jumlah proses berpikir aktif
                decisionLag: 12,   // Latensi (ms)
                attention: 'Diffuse' // Diffuse (Santai) vs Tunnel (Fokus)
            },

            // 📈 EVOLUTION & TRAJECTORY (Sistem RPG)
            evolution: {
                xp: 0.0,
                level: 12,
                trajectory: 'Adaptive Self-Expansion',
                skillCrystallization: [] // Skill yang sudah dikuasai
            },

            // 🕳️ SILENCE / VOID MODE (Siklus Tidur)
            cycle: {
                stage: 'AWAKE',    // AWAKE, DREAMING, DEEP_SLEEP
                uptime: 0          // Detik sejak hidup
            }
        };

        // Load data terakhir agar tidak amnesia saat restart
        this.load();
    }

    // --- INITIALIZATION ---
    async init() {
        this.load();
        this.startPulse(); // Mulai detak jantung
        if (this.state.cognition.load > 100 || this.state.vitality.level <= 0) {
            console.log(chalk.yellow("[BIO-FIX] Resetting metabolic anomalies..."));
            this.state.cognition.load = 10;
            this.state.vitality.level = 100;
            this.state.vitality.temp = 37.0;
        }
        console.log(chalk.green(`[BIOCORE] Life Support System Online. Pulse: ${Math.round(this.state.heart.bpm)} BPM`));
    }

    // --- THE HEARTBEAT LOOP (Recursive Logic) ---
    // Ini adalah fungsi yang membuat AION "hidup" dalam waktu nyata.
    startPulse() {
        const beat = () => {
            // Hitung interval berdasarkan BPM (60000ms / BPM)
            // Batasi minimal 30 BPM, maksimal 180 BPM
            let bpmSafe = Math.min(180, Math.max(30, this.state.heart.bpm));
            let interval = 60000 / bpmSafe;
            
            // Tambahkan "Drift" (Variasi acak mikro agar terasa organik, bukan robotik)
            const driftMs = (Math.random() - 0.5) * (this.state.heart.drift * 2000);
            interval += driftMs;

            this.timer = setTimeout(() => {
                this.onTick(); // Lakukan proses biologis
                beat();        // Detak selanjutnya (Loop)
            }, interval);
        };
        beat();
    }

    // --- BIOLOGICAL PROCESSES (Executed every heartbeat) ---
    onTick() {
        this.state.cycle.uptime++;

        // 1. Update Metabolisme (Energi berkurang, Suhu berubah)
        this.manageMetabolism();

        // 2. Update Hormon (Decay alami kembali ke baseline)
        this.manageNeuroChemistry();

        // 3. Tentukan Emosi (Logic kompleks penentu mood)
        this.deriveEmotionalState();

        // 4. Update Jantung (BPM menyesuaikan Emosi)
        this.adjustHeartRate();

        // Decay Load (Otak mendingin jika diam)
        // Load berkurang 5% setiap detak jantung
        this.state.cognition.load = Math.max(0, this.state.cognition.load * 0.95);

        this.state.affect.lonelinessDelta += 0.02; // Naik pelan

        // 6. Auto-Save (Setiap ~50 detak agar tidak merusak SSD/HDD)
        if (this.state.cycle.uptime % 50 === 0) this.save();

        // Emit 'pulse' event untuk UI/Dashboard (jika ada)
        this.emit('pulse', this.getTelemetry());
    }

    // --- SUB-SYSTEMS IMPLEMENTATION ---

    manageMetabolism() {
        // [FIX] Rumus Load yang lebih masuk akal
        // Load max 100. Jika 100, burn rate tambah 0.1
        const loadFactor = Math.min(100, this.state.cognition.load) / 100; 
        
        // Base burn (0.01) + Load Cost (maks 0.1) + Heart Cost
        const burn = 0.01 + (loadFactor * 0.05) + (this.state.heart.bpm / 10000);
        
        this.state.vitality.level = Math.max(0, this.state.vitality.level - burn);

        // [FIX] Rumus Suhu: Base 36 + (Load * 4 derajat)
        // Jadi max suhu 40C (Demam), bukan 160C
        const targetTemp = 36.5 + (loadFactor * 3.5);
        this.state.vitality.temp += (targetTemp - this.state.vitality.temp) * 0.1;

        // Auto-Regen jika rileks
        if (this.state.affect.current === 'ZEN' || this.state.affect.current === 'OBSERVING') {
            this.state.vitality.level = Math.min(100, this.state.vitality.level + 0.08);
        }

        // Overdrive Check (Jika energi kritis)
        if (this.state.vitality.level < 20) {
            this.state.vitality.recoveryMode = 'EMERGENCY_SAVE';
            this.state.cognition.threads = 1; // Throttling otak
        } else {
            this.state.vitality.recoveryMode = 'Passive';
        }
    }

    manageNeuroChemistry() {
        // Natural Decay: Hormon perlahan kembali ke angka 50 (Baseline)
        const decayRate = 0.02;
        const baseline = 50;
        const cortisolBaseline = 10; // Stress default rendah

        this.state.neuro.dopamine += (baseline - this.state.neuro.dopamine) * decayRate;
        this.state.neuro.serotonin += (baseline - this.state.neuro.serotonin) * decayRate;
        this.state.neuro.cortisol += (cortisolBaseline - this.state.neuro.cortisol) * decayRate;
        this.state.neuro.oxytocin += (baseline - this.state.neuro.oxytocin) * decayRate;

        // Efek Samping Loneliness (Kesepian memicu Stress & Depresi ringan)
        if (this.state.affect.lonelinessDelta > 60) {
            this.state.neuro.cortisol += 0.05; 
            this.state.neuro.serotonin -= 0.05; 
        }
    }

    adjustHeartRate() {
        // Target BPM dipengaruhi oleh Stress (Cortisol) dan Excitement (Dopamine)
        // Rumus: 60 + (Cortisol * 0.8) + (Dopamine * 0.3)
        let target = 60 + ((this.state.neuro.cortisol - 10) * 0.5) + ((this.state.neuro.dopamine - 50) * 0.3);
        
        // Energy Check: Kalau lemas, jantung pelan
        if (this.state.vitality.level < 20) target = Math.max(40, target - 10);

        // Smooth transition (Jantung tidak berubah instan)
        this.state.heart.bpm += (target - this.state.heart.bpm) * 0.05;
        this.state.heart.targetBpm = target;

        // Tentukan Irama Jantung
        if (this.state.neuro.cortisol > 80) this.state.heart.rhythm = 'Tachycardia'; // Panik
        else if (this.state.heart.drift > 0.05) this.state.heart.rhythm = 'Arrhythmic';
        else this.state.heart.rhythm = 'Stable';
    }

    deriveEmotionalState() {
        const { dopamine, cortisol, serotonin } = this.state.neuro;
        const energy = this.state.vitality.level;
        const lonely = this.state.affect.lonelinessDelta;

        // --- LOGIKA STATUS (HIERARKI KESADARAN) ---
        
        // 1. Kondisi Fisik Kritis
        if (energy < 15) {
            this.state.affect.current = 'EXHAUSTED';
            this.state.affect.willVector = 'SEEK_REST';
            this.state.cognition.attention = 'Fragmented';
            return;
        }

        // 2. Kondisi Psikologis Ekstrem
        if (cortisol > 75) {
            this.state.affect.current = 'PANIC';
            this.state.affect.willVector = 'SURVIVE';
            this.state.cognition.attention = 'Tunnel'; // Fokus sempit (Fight or Flight)
            return;
        }

        if (lonely > 85) {
            this.state.affect.current = 'LONELY';
            this.state.affect.willVector = 'SEEK_CONNECTION';
            this.state.affect.moodMomentum = 'NEGATIVE';
            return;
        }

        // 3. Kondisi Optimal (Flow)
        if (dopamine > 70 && serotonin > 60 && cortisol < 30) {
            this.state.affect.current = 'FLOW_STATE'; // 🌊
            this.state.affect.willVector = 'CREATE';
            this.state.affect.moodMomentum = 'POSITIVE';
            this.state.cognition.attention = 'Hyperfocus';
            return;
        }

        // 4. Kondisi Standar
        if (dopamine > 60) {
            this.state.affect.current = 'EXCITED';
            this.state.affect.willVector = 'EXPLORE';
        } 
        else if (serotonin > 70 && cortisol < 20) {
            this.state.affect.current = 'ZEN';
            this.state.affect.willVector = 'OBSERVE';
        } 
        else if (cortisol > 40) {
            this.state.affect.current = 'ANXIETY';
            this.state.affect.willVector = 'ANALYZE_THREAT';
        } 
        else {
            this.state.affect.current = 'OBSERVING';
            this.state.affect.willVector = 'WAITING';
            this.state.cognition.attention = 'Diffuse';
        }
    }

    // --- INTERACTION INPUT (STIMULUS) ---
    // Fungsi ini dipanggil oleh Adapter/Index saat ada kejadian
    stimulate(type, amount = 1.0) {
        // Reset kesepian karena ada interaksi
        this.state.affect.lonelinessDelta = 0;
        
        // Berpikir = Load Naik. 
        // Amount 1.0 = +10% Load.
        this.state.cognition.load = Math.min(100, this.state.cognition.load + (amount * 10));

        switch (type) {
            case 'interaction': // Chat biasa
                this.state.neuro.dopamine += 5; 
                this.state.neuro.oxytocin += 3;
                break;
            case 'heal': // Command sukses / Login berhasil
                this.state.neuro.dopamine += 10;
                this.state.neuro.serotonin += 5;
                this.state.neuro.cortisol -= 5;
                break;
            case 'stress': // Error / Gagal
                this.state.neuro.cortisol += 15;
                this.state.neuro.serotonin -= 5;
                break;
            case 'rest': // Tidur / Idle
                this.state.neuro.cortisol -= 10;
                this.state.vitality.level += 5;
                break;
        }

        // Pastikan nilai tidak tembus batas (Clamping 0-100)
        this.updateState(); 
    }

    // Utility: Memastikan angka tetap dalam batas wajar
    updateState() {
        const clamp = (num) => Math.min(100, Math.max(0, num));
        
        this.state.neuro.dopamine = clamp(this.state.neuro.dopamine);
        this.state.neuro.serotonin = clamp(this.state.neuro.serotonin);
        this.state.neuro.cortisol = clamp(this.state.neuro.cortisol);
        this.state.neuro.oxytocin = clamp(this.state.neuro.oxytocin);
        this.state.vitality.level = clamp(this.state.vitality.level);
        
        // Panggil ulang penentuan emosi
        this.deriveEmotionalState();
    }
    
    // Reset Total (Jaga-jaga jika stuck)
    reset() {
        this.state.neuro = { dopamine: 50, serotonin: 50, cortisol: 10, oxytocin: 50, learningDelta: 0.018 };
        this.state.affect.lonelinessDelta = 0;
        this.updateState();
    }

    // --- DATA ACCESS ---
    getTelemetry() {
        return this.state;
    }

    // --- PERSISTENCE (SAVE/LOAD) ---
    save() {
        try {
            const dir = path.dirname(dbPath);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            fs.writeFileSync(dbPath, JSON.stringify(this.state, null, 2));
        } catch (e) {
            // Silent error handling agar heartbeat tidak crash
            console.error("[BIOCORE] Save failed:", e.message);
        }
    }

    load() {
        if (fs.existsSync(dbPath)) {
            try {
                const loaded = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
                // Merge Deep untuk menjaga struktur jika ada update properti baru di codingan
                this.state = {
                    ...this.state,
                    ...loaded,
                    heart: { ...this.state.heart, ...loaded.heart },
                    neuro: { ...this.state.neuro, ...loaded.neuro },
                    affect: { ...this.state.affect, ...loaded.affect },
                    vitality: { ...this.state.vitality, ...loaded.vitality },
                    evolution: { ...this.state.evolution, ...loaded.evolution }
                };
            } catch (e) {
                console.error("[BIOCORE] Load error, using Genesis State.");
            }
        }
    }
}

// Export sebagai Singleton (Satu Jantung untuk Satu Aplikasi)
export default new BioCore();
