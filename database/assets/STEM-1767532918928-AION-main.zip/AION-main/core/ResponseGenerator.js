import { ResponsePool } from './ResponsePool.js';
import BioCore from './BioCore.js';

class ResponseGenerator {
    constructor() {
        this.lastResponse = ""; // Memori jangka pendek agar tidak repetitif
    }

    /**
     * GENERATE RESPON DINAMIS
     * @param {String} category - Kategori Intent (SOCIAL_GREETING, CURRENT_ACTIVITY, dll)
     * @param {Object} userProfile - Profil user (untuk cek Trust/Role)
     */
    generate(category, userProfile) {
        const bio = BioCore.getTelemetry();
        let candidates = [];

        // 1. FILTER BERDASARKAN KATEGORI & TRUST
        if (category === 'SOCIAL_GREETING') {
            const isHighTrust = userProfile.role === 'CREATOR' || userProfile.trustScore > 0.5;
            candidates = isHighTrust ? ResponsePool.SOCIAL_GREETING.HIGH_TRUST : ResponsePool.SOCIAL_GREETING.LOW_TRUST;
        } else {
            // Default: Ambil langsung dari pool
            candidates = ResponsePool[category] || ["..."];
        }

        // 2. FILTER REPETISI (Jangan pilih jawaban yang SAMA PERSIS dengan sebelumnya)
        // Kecuali jika pilihan cuma 1
        if (candidates.length > 1) {
            candidates = candidates.filter(c => {
                const textVal = typeof c === 'function' ? "DYNAMIC" : c; 
                return textVal !== this.lastResponse;
            });
        }

        // 3. PICK RANDOM (Weighted bisa ditambahkan nanti)
        const template = candidates[Math.floor(Math.random() * candidates.length)];

        // 4. RESOLVE TEMPLATE (String vs Function)
        let finalOutput = "";
        if (typeof template === 'function') {
            finalOutput = template(bio); // INJECT BIO DATA
        } else {
            finalOutput = template;
        }

        // 5. MICRO-MUTATION (Membuat kesan natural/tidak kaku)
        finalOutput = this.applyMutations(finalOutput, bio);

        this.lastResponse = finalOutput; // Simpan history
        return finalOutput;
    }

    applyMutations(text, bio) {
        // Mutasi 1: Jika mood EXCITED, tambah emoji atau tanda seru
        if (bio.affect.current === 'EXCITED' && Math.random() > 0.7) {
            text += " ⚡";
        }
        
        // Mutasi 2: Jika EXHAUSTED, buat kalimat lebih pendek atau lowercase (opsional)
        if (bio.vitality.level < 20 && Math.random() > 0.5) {
            text = text.toLowerCase().replace('.', '...');
        }

        // Mutasi 3: Time Awareness
        const hour = new Date().getHours();
        if (text.includes("Halo") || text.includes("Hai")) {
            if (hour >= 18 || hour <= 4) text = text.replace("Halo", "Malam");
            else if (hour >= 5 && hour <= 10) text = text.replace("Halo", "Pagi");
        }

        return text;
    }
}

export default new ResponseGenerator();