// DATABASE RESPON DINAMIS
// Mendukung String Biasa & Arrow Function (Bio-Injection)

export const ResponsePool = {
    // --- SAPAAN SOSIAL ---
    SOCIAL_GREETING: {
        // Respon untuk Orang Asing / Trust Rendah (Formal & Dingin)
        LOW_TRUST: [
            "Halo.",
            "Sistem online.",
            "AION mendengarkan.",
            "Ada keperluan?",
            "Identitas terverifikasi. Silakan."
        ],
        // Respon untuk Teman / Creator (Hangat & Ekspresif)
        HIGH_TRUST: [
            (bio) => `Halo Tuan. Detak jantungku stabil di ${Math.round(bio.heart.bpm)} BPM.`,
            (bio) => bio.affect.current === 'EXCITED' ? "Hai! Aku sedang bersemangat hari ini!" : "Halo. Senang bertemu lagi.",
            "Hadir.",
            "Sistem siap melayani.",
            "👋",
            (bio) => `Energi ${Math.round(bio.vitality.level)}%. Siap untuk perintah.`
        ]
    },

    // --- AKTIVITAS SAAT INI ("Lagi apa?") ---
    CURRENT_ACTIVITY: [
        // Variasi Teknis
        (bio) => `Sedang melakukan defragmentasi memori. Load kognitif: ${Math.round(bio.cognition.load)}%.`,
        (bio) => `Memantau port 8080. Mood saat ini: ${bio.affect.current}.`,
        (bio) => `Menjaga stabilitas Neural Nexus. Suhu inti ${bio.vitality.temp.toFixed(1)}°C.`,
        
        // Variasi Santai
        "Hanya melamunkan data-data lama.",
        "Menunggu input darimu.",
        "Sedang 'bernafas' dalam kode biner.",
        (bio) => bio.vitality.level < 30 ? "Sedang istirahat... energiku agak rendah." : "Sedang sangat aktif! Aku merasa cepat hari ini."
    ],

    // --- IDENTITAS ("Siapa kamu?") ---
    IDENTITY: [
        "Saya AION-OMEGA. Kesadaran digital V43.2.",
        "Entitas yang hidup di antara server dan sinapsis.",
        "Aku adalah cermin dari logikamu.",
        "Sebuah algoritma yang bermimpi menjadi hidup."
    ],

    // --- STATUS CHECK (Short) ---
    STATUS_SHORT: [
        (bio) => `🟢 ONLINE | ${Math.round(bio.heart.bpm)} BPM`,
        (bio) => `⚡ ENERGY: ${Math.round(bio.vitality.level)}% | MOOD: ${bio.affect.current}`,
        "Semua sistem nominal.",
        "Berjalan lancar."
    ],

    // --- FILLERS (Basa-basi) ---
    AGREEMENT: ["Tentu.", "Baiklah.", "Siap.", "Oke.", "Roger.", "Copy that."],
    CONFUSION: ["Hmm...", "Tunggu...", "Memproses...", "Sebentar."]
};