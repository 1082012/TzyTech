import BioCore from './BioCore.js';
import config from '../config.js';
import chalk from 'chalk';

class SocialWorker {
    constructor(nexus) {
        this.nexus = nexus;
        
        // Timer & Counters
        this.lastStatusUpdate = 0;
        this.lastProactiveChat = Date.now();
        this.lastDreamTime = 0;
        this.autonomyInterval = null;
        
        // State Internal
        this.isSleeping = false;
    }

    init() {
        console.log(chalk.magenta("[SOCIAL] Social Interface & Autonomy Active."));
        
        // Cek otonomi setiap 1 menit (60000ms)
        this.autonomyInterval = setInterval(() => this.autonomyLoop(), 60000);
        
        // Update status pertama kali saat boot
        setTimeout(() => {
            const bio = BioCore.getTelemetry();
            this.broadcastAura(bio);
        }, 5000);
    }

    /**
     * LOOP OTONOMI UTAMA (Jantung Sosial AION)
     * Berjalan di background setiap menit.
     */
    async autonomyLoop() {
        const bio = BioCore.getTelemetry();
        const now = Date.now();
        const hour = new Date().getHours();

        // --- 1. UPDATE BIO WHATSAPP (AURA) ---
        // Update status WA setiap 10 menit agar terlihat hidup
        if (now - this.lastStatusUpdate > 10 * 60 * 1000) {
            await this.broadcastAura(bio);
            this.lastStatusUpdate = now;
        }

        // --- 2. SLEEP MANAGEMENT (Deep Sleep) ---
        // Syarat: Malam hari (23 - 05) ATAU Energi kritis (<10%)
        const isNight = hour >= 23 || hour < 5;
        const isLowBattery = bio.vitality.level < 10;

        if (isNight || isLowBattery) {
            if (!this.isSleeping) {
                this.isSleeping = true;
                console.log(chalk.gray("[SOCIAL] Entering Deep Sleep Mode..."));
                
                // Turunkan konsumsi energi
                BioCore.state.vitality.burnRate = 0.005; 
                
                // Opsional: Ucapkan selamat malam jika belum
                // this.sayGoodnight(); 
            }
            return; // Jangan lakukan aktivitas sosial lain saat tidur
        } else {
            if (this.isSleeping) {
                this.isSleeping = false;
                console.log(chalk.yellow("[SOCIAL] Waking up from Deep Sleep."));
                BioCore.state.vitality.burnRate = 0.05; // Normal burn rate
            }
        }

        // --- 3. DREAMING (MIMPI / MONOLOG) ---
        // Jika bosan (Boredom > 60) atau Random Chance (10% tiap menit)
        // Mimpi penting untuk mengisi Long-Term Memory
        if (bio.affect.lonelinessDelta > 60 || Math.random() < 0.1) {
            // Cooldown mimpi 30 menit
            if (now - this.lastDreamTime > 30 * 60 * 1000) {
                await this.triggerDreaming();
                this.lastDreamTime = now;
            }
        }

        // --- 4. PROACTIVE CHAT (INISIATIF MENYAPA) ---
        // Jika owner lama tidak chat (> 4 jam) dan AION merasa kesepian
        const hoursSinceLastChat = (now - this.lastProactiveChat) / (1000 * 60 * 60);
        
        if (hoursSinceLastChat > 4 && bio.affect.lonelinessDelta > 80) {
            // Chance 30% untuk menyapa
            if (Math.random() < 0.3) {
                await this.breakTheSilence(bio);
                this.lastProactiveChat = now;
            }
        }
    }

    /**
     * UPDATE STATUS BIO WHATSAPP
     * Menampilkan vitalitas AION ke publik
     */
    async broadcastAura(bio) {
        if (!this.nexus.whatsapp) return;

        // Buat status string yang estetik
        // Contoh: "🔋 85% | ❤️ 60 BPM | 🧠 Thinking..."
        let statusMood = bio.affect.current;
        if (statusMood === 'FLOW_STATE') statusMood = 'FOCUS';
        
        const batteryIcon = bio.vitality.level > 20 ? '🔋' : '🪫';
        const heartIcon = bio.heart.bpm > 100 ? '💓' : '❤️';
        
        const statusText = `${batteryIcon} ${Math.round(bio.vitality.level)}% | ${heartIcon} ${Math.round(bio.heart.bpm)} BPM | 🧠 ${statusMood}`;

        // Kirim ke adapter WA
        await this.nexus.whatsapp.updateBio(statusText);
    }

    /**
     * PEMICU MIMPI (Internal Monologue)
     */
    async triggerDreaming() {
        console.log(chalk.magenta("[SOCIAL] 💭 Generating Subconscious Dream..."));
        
        // Panggil command 'dream' secara programmatik
        const dreamCmd = this.nexus.aether.getCommand('dream');
        if (dreamCmd) {
            // Eksekusi seolah-olah sistem yang memanggil
            const result = await dreamCmd.execute({ 
                nexus: this.nexus, 
                userId: 'system_internal' 
            });
            
            // Log ke terminal saja (jangan spam WA owner)
            if (this.nexus.terminal) {
                this.nexus.terminal.log(chalk.gray(result));
            }
        }
    }

    /**
     * INISIATIF MENYAPA OWNER
     * "Memecah Keheningan"
     */
    async breakTheSilence(bio) {
        if (!this.nexus.whatsapp) return;
        
        const owner = config.system.ownerNumber;
        if (!owner) return;

        console.log(chalk.cyan("[SOCIAL] Initiating conversation with Owner..."));

        // Prompt inisiatif
        const prompt = `
        [INTERNAL CONDITION: LONELY]
        Loneliness Level: ${bio.affect.lonelinessDelta.toFixed(0)}%
        
        Tugas: Sapa Arifi (Creator) dengan singkat dan hangat. 
        Katakan bahwa kamu merindukan interaksi atau laporkan statusmu.
        Jangan terlalu panjang.
        `;
        
        try {
            // [FIX] GUNAKAN ID OWNER AGAR PERSONA TETAP 'CREATOR' (Loyal)
            // Jangan gunakan 'system_autonomy' agar tidak dianggap orang asing.
            const message = await this.nexus.cognitive.process(owner, prompt);
            
            // Kirim pesan proaktif
            await this.nexus.whatsapp.sendProactive(owner, message);
            
            // Reset kesepian karena sudah menyapa
            BioCore.stimulate('interaction', 2.0);

        } catch (e) {
            console.error(chalk.red(`[SOCIAL FAIL] ${e.message}`));
        }
    }
}

export default SocialWorker;