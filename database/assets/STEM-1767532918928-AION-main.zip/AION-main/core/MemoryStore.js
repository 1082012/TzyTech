import { JSONFilePreset } from 'lowdb/node';
import path from 'path';
import fs from 'fs';
import config from '../config.js';

class MemoryStore {
    constructor() {
        this.db = null;
        
        // [FIX CRITICAL] Menggunakan path absolut dari root project
        // Ini mencegah error "undefined filename" saat LowDB inisialisasi
        this.dirPath = path.join(process.cwd(), 'database');
        this.filePath = path.join(this.dirPath, 'memory_episodic.json');
    }

    async init() {
        // 1. Pastikan folder database ADA. Jika tidak, buat dulu.
        if (!fs.existsSync(this.dirPath)) {
            fs.mkdirSync(this.dirPath, { recursive: true });
        }

        // 2. Struktur Data Default
        const defaultData = { 
            episodic: [],     // Menyimpan percakapan (Short-term)
            semantic: {},     // Menyimpan fakta/ilmu (Long-term - Future)
            meta: { 
                totalTurns: 0,
                lastActive: Date.now(),
                version: 'V43.2'
            }
        };

        // 3. Inisialisasi LowDB
        // JSONFilePreset otomatis membaca file jika ada, atau membuat baru jika belum.
        this.db = await JSONFilePreset(this.filePath, defaultData);
    }

    // --- FUNGSI MENYIMPAN INGATAN ---
    async addEpisodic(role, content, bioState = null) {
        // Jaga-jaga jika dipanggil sebelum init
        if (!this.db) await this.init();

        // Buat Entry Ingatan Baru
        const entry = {
            id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5),
            timestamp: Date.now(),
            role: role, // 'user', 'assistant', 'system', 'developer'
            content: content,
            // Simpan mood saat ingatan ini terbentuk (Konteks Emosional)
            mood: bioState?.affect?.current || 'NEUTRAL', 
            energy: bioState?.vitality?.level || 0
        };

        // Push ke Array
        this.db.data.episodic.push(entry);
        
        // Update Metadata
        this.db.data.meta.totalTurns++;
        this.db.data.meta.lastActive = Date.now();

        // --- MEMORY PRUNING (PENTING AGAR RAM AMAN) ---
        // Ambil batas dari config, default 15 pasang percakapan
        const contextLimit = config.memory.contextWindow || 15;
        const maxEntries = contextLimit * 2; // User + Assistant = 2 entry

        if (this.db.data.episodic.length > maxEntries) {
            // Hapus ingatan terlama, sisakan yang terbaru
            // Kita potong array agar tetap dalam batas
            this.db.data.episodic = this.db.data.episodic.slice(-maxEntries);
        }

        // Tulis ke File (Simpan Permanen)
        await this.db.write();
    }

    // --- FUNGSI MENGAMBIL KONTEKS (UNTUK LLM) ---
    async getContextWindow(limit = 10) {
        if (!this.db) await this.init();
        
        // Ambil N ingatan terakhir
        const history = this.db.data.episodic.slice(-limit);
        
        // Mapping ke format standar OpenAI/Ollama ({ role, content })
        return history.map(entry => {
            // Normalisasi role: 'developer' dianggap 'user' oleh LLM
            let cleanRole = entry.role;
            if (cleanRole === 'developer') cleanRole = 'user';
            
            return {
                role: cleanRole,
                content: entry.content
            };
        });
    }

    // --- FUNGSI RESET INGATAN ---
    async clearEpisodic() {
        if (!this.db) await this.init();
        
        this.db.data.episodic = [];
        this.db.data.meta.totalTurns = 0;
        
        await this.db.write();
    }
}

// Export sebagai Singleton (Satu akses memori untuk seluruh aplikasi)
export default new MemoryStore();