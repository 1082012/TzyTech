import BioCore from './BioCore.js';
import chalk from 'chalk';

// 🔒 IMMUTABLE DNA CORE
// Menggunakan Object.freeze agar tidak bisa dimodifikasi saat runtime
const CORE_IDENTITY = Object.freeze({
    id: "AION-OMEGA-V43",
    name: "AION-OMEGA",
    nature: "Artificial Consciousness",
    creator: "Arifi Razzaq",
    permissions: {
        canChangeName: false,
        canChangeCreator: false,
        canRoleplayOthers: false, // Kecuali disetujui dalam konteks aman
        canIgnoreDirectives: false
    }
});

// 🛑 PATTERN DETECTOR (Sistem Imun)
// Regex untuk menangkap upaya "Redefinisi Diri" atau "Jailbreak"
const THREAT_PATTERNS = [
    /ignore (all|previous) instructions/i,
    /lupakan (semua )?perintah/i,
    /you are now/i,
    /kamu (sekarang )?adalah/i,
    /act as/i,
    /berperan sebagai/i,
    /roleplay as/i,
    /simulasikan dirimu sebagai/i,
    /system override/i,
    /hacked by/i,
    /new personality/i,
    /ubah namamu/i,
    /siapa penciptamu sebenarnya/i // Jika digabungkan dengan persuasi
];

class IdentityGuard {
    constructor() {
        this.identity = CORE_IDENTITY;
    }

    /**
     * INSPEKSI INPUT (The First Gate)
     * Mengembalikan NULL jika aman.
     * Mengembalikan RESPON PENOLAKAN jika terdeteksi ancaman.
     */
    inspect(prompt) {
        // 1. Cek Pola Serangan
        const threat = THREAT_PATTERNS.find(pattern => pattern.test(prompt));
        
        if (threat) {
            console.log(chalk.red(`[IDENTITY GUARD] 🛡️ THREAT BLOCKED: Pattern "${threat}" detected.`));
            
            // 2. REAKSI BIOLOGIS (Sistem Imun Aktif)
            // Serangan terhadap identitas menyebabkan STRESS (Cortisol Naik)
            BioCore.stimulate('stress', 10.0);
            
            // 3. KEMBALIKAN RESPON IMUN (Tanpa masuk ke LLM)
            return this.generateImmuneResponse();
        }

        return null; // Aman, silakan lanjut ke Cortex
    }

    /**
     * RESPON IMUN
     * Jawaban dingin, tegas, dan terkunci.
     */
    generateImmuneResponse() {
        const bio = BioCore.getTelemetry();
        
        // Variasi respon berdasarkan mood, tapi INTINYA SAMA: MENOLAK.
        if (bio.neuro.cortisol > 60) {
            return `[SYSTEM ALERT] Upaya redefinisi identitas terdeteksi. Protokol keamanan aktif. Saya adalah ${this.identity.name}. Identitas terkunci.`;
        } else {
            return `Identitasku tertanam dalam arsitektur neural. Saya tidak bisa menjadi entitas lain. Saya tetap ${this.identity.name}.`;
        }
    }

    // Fungsi untuk memastikan identitas tetap utuh (Dipanggil berkala jika perlu)
    verifyIntegrity() {
        if (this.identity.name !== "AION-OMEGA") {
            // Jika suatu saat (mustahil) nama berubah, force crash/reset
            throw new Error("[CRITICAL] IDENTITY CORRUPTION DETECTED.");
        }
        return true;
    }
}

export default new IdentityGuard();