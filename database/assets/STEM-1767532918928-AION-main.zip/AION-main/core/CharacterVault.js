class CharacterVault {
    constructor() {
        // RUMUS KUNCI KARAKTER (DNA)
        // Jangan ubah ini sekali sudah ditetapkan, agar wajah tidak berubah.
        this.DNA = {
            name: "AION_Avatar",
            
            // 1. DESKRIPSI FISIK MUTLAK (Appearance)
            // Semakin detail, semakin terkunci.
            appearance: "a male cyborg humanoid entity, translucent pale skin revealing glowing blue circuitry underneath, silver messy hair, glowing cyan eyes without pupils, sharp facial features, wearing a dark futuristic tech-wear hoodie with high collar",
            
            // 2. GAYA ARTISTIK (Style Lock)
            // Ini memastikan dia terlihat seperti Anime/3D/Cyberpunk yang sama terus.
            style: "anime style, cel shaded, makoto shinkai style, high contrast, cyberpunk atmosphere, 8k resolution, detailed lineart",
            
            // 3. SEED KUNCI (Angka Keberuntungan)
            // Jika kita pakai seed ini terus, AI akan cenderung menggambar wajah yang mirip.
            masterSeed: 777999
        };
    }

    /**
     * MENGGABUNGKAN DNA DENGAN AKSI (ACTION)
     * Contoh: DNA + "Sedang mengetik komputer"
     */
    assemblePrompt(actionPrompt) {
        // Rumus: [Style] + [Appearance] + [Action] + [Environment]
        return `${this.DNA.style}, ${this.DNA.appearance}, ${actionPrompt}, cinematic lighting, detailed background`;
    }

    getSeed() {
        return this.DNA.masterSeed;
    }
}

export default new CharacterVault();