import { ClassicLevel } from 'classic-level';
import path from 'path';
import chalk from 'chalk';
import fs from 'fs';
import SemanticProcessor from './SemanticProcessor.js';

// KONFIGURASI ENGINE
const DB_PATH = path.join(process.cwd(), 'database', 'concept_graph_v1');

class ConceptVault {
    constructor() {
        this.db = new ClassicLevel(DB_PATH, { valueEncoding: 'json' });
        this.processor = new SemanticProcessor();
        this.status = 'OFFLINE';
        this.init();
    }

    async init() {
        if (!fs.existsSync(DB_PATH)) fs.mkdirSync(DB_PATH, { recursive: true });
        await this.db.open();
        this.status = 'ONLINE';
        console.log(chalk.cyan(`[CONCEPT VAULT] 🕸️ Semantic Graph Active.`));
    }

    /**
     * LEARNING: Menyerap Kalimat menjadi Jaringan Konsep
     */
    async assimilate(input) {
        if (this.status !== 'ONLINE') return;

        // 1. DEKOMPOSISI
        const triples = this.processor.decompose(input);
        const batch = this.db.batch();

        let learnedNodes = 0;

        for (const t of triples) {
            // Struktur Key Node: "NODE:kata"
            // Struktur Key Edge: "EDGE:kata1:kata2"

            // 2. BUAT/UPDATE NODES (Concepts)
            const subKey = `NODE:${t.subject}`;
            const objKey = `NODE:${t.object}`;

            // Kita pakai teknik 'Upsert' ringan (blind write untuk kecepatan)
            // Weight +1 setiap kali konsep disebut (Structural Learning)
            batch.put(subKey, { label: t.subject, type: 'ENTITY', last_seen: Date.now() });
            batch.put(objKey, { label: t.object, type: 'ENTITY', last_seen: Date.now() });

            // 3. BUAT EDGES (Relations)
            // Edge bersifat searah (Directed), tapi kita simpan bolak balik untuk traversal
            const edgeKey = `EDGE:${t.subject}:${t.object}`;
            batch.put(edgeKey, { type: t.relation, weight: 1.0 });

            learnedNodes += 2;
        }

        await batch.write();
        return { triples: triples.length, nodes: learnedNodes };
    }

    /**
     * REASONING: Menelusuri Graph untuk menjawab
     * Bukan pencarian teks, tapi penelusuran jalur (Pathfinding)
     */
    async reason(query) {
        if (this.status !== 'ONLINE') return null;

        // 1. Identifikasi Konsep Awal
        const concepts = this.processor.extractConcepts(query);
        if (concepts.length === 0) return null;

        const startNode = concepts[0]; // Ambil konsep utama
        const pathTrace = [];
        
        // 2. GRAPH TRAVERSAL (Depth-Limited Search - Depth 1)
        // Cari semua tetangga dari konsep utama
        const iterator = this.db.iterator({ 
            gt: `EDGE:${startNode}:`, 
            lt: `EDGE:${startNode}:\xff` 
        });

        for await (const [key, edgeData] of iterator) {
            // Key format: EDGE:source:target
            const targetNode = key.split(':')[2];
            
            // Format output logika: "A berhubungan dengan B"
            pathTrace.push({
                source: startNode,
                relation: edgeData.type,
                target: targetNode,
                weight: edgeData.weight
            });
        }

        // 3. SYNTHESIS (BOUNDED GENERATION)
        // Rakit jawaban hanya dari fakta yang ditemukan
        if (pathTrace.length === 0) return null;

        // Urutkan berdasarkan weight atau relevansi
        const facts = pathTrace.map(f => {
            const relText = this.translateRelation(f.relation);
            return `${f.source} ${relText} ${f.target}`;
        });

        // Gabungkan menjadi paragraf naratif
        return {
            logicPath: pathTrace,
            response: `Berdasarkan struktur pengetahuanku: ${facts.join('. ')}.`
        };
    }

    translateRelation(rel) {
        const map = {
            'IS_A': 'adalah',
            'HAS': 'memiliki',
            'CAUSES': 'menyebabkan',
            'PRODUCES': 'menghasilkan',
            'RELATED_TO': 'berhubungan dengan',
            'LIKE': 'seperti'
        };
        return map[rel] || 'terkait';
    }

    async getStats() {
        let nodes = 0;
        let edges = 0;
        for await (const [key] of this.db.iterator()) {
            if (key.startsWith('NODE:')) nodes++;
            if (key.startsWith('EDGE:')) edges++;
        }
        return { nodes, edges };
    }
    
    getDB() {
        return this.db;
    }
}

export default new ConceptVault();
