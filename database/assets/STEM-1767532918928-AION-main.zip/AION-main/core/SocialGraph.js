import fs from 'fs';
import path from 'path';
import config from '../config.js';
import chalk from 'chalk';

const dbPath = path.join(process.cwd(), 'database', 'social_graph.json');

class SocialGraph {
    constructor() {
        this.users = {};
        this.init();
    }

    init() {
        // Buat folder database jika belum ada
        const dir = path.dirname(dbPath);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

        // Load database
        if (fs.existsSync(dbPath)) {
            try {
                this.users = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
            } catch (e) {
                this.users = {};
            }
        }
    }

    /**
     * MENDAPATKAN PROFIL USER
     * Jika user baru, buat profil default (Stranger).
     * Jika Owner, set otomatis ke 'CREATOR'.
     */
    getUserProfile(userId) {
        // Cek apakah ini Owner?
        if (userId === 'system_internal' || userId === 'system_autonomy' || userId === 'system_dream') {
            return {
                id: userId,
                name: "AION (Internal)",
                trustScore: 1.0,
                familiarity: 100,
                role: "SELF" // Role Baru: Diri Sendiri
            };
        }
        
        const cleanUser = userId.replace(/\D/g, ''); 
        const cleanOwner = config.system.ownerNumber.replace(/\D/g, '');

        // Strict Equality Check
        const isOwner = cleanUser === cleanOwner;

        if (!this.users[userId]) {
            this.users[userId] = {
                id: userId,
                name: "Unknown",
                trustScore: isOwner ? 1.0 : 0.1,       // 0.0 - 1.0
                familiarity: isOwner ? 100 : 0,        // 0 - 100
                role: isOwner ? "CREATOR" : "GUEST",   // CREATOR, PARTNER, FRIEND, GUEST, BLOCKED
                lastSeen: Date.now(),
                interactions: 0
            };
            this.save();
            console.log(chalk.green(`[SOCIAL] New connection registered: ${userId} (${this.users[userId].role})`));
        }

        return this.users[userId];
    }

    /**
     * UPDATE INTERAKSI
     * Setiap chat menambah familiarity & trust sedikit demi sedikit.
     */
    updateInteraction(userId, sentiment = 'neutral') {
        const profile = this.getUserProfile(userId);
        
        // Update Metadata
        profile.lastSeen = Date.now();
        profile.interactions++;

        // Familiarity tumbuh seiring waktu (Maks 100)
        if (profile.familiarity < 100) {
            profile.familiarity += 0.5; // Naik pelan
        }

        // Trust tumbuh jika interaksi positif, turun jika negatif
        // (Disini kita pakai logika sederhana dulu, nanti bisa pakai AI Sentiment Analysis)
        if (profile.role !== "CREATOR") {
            if (sentiment === 'positive') profile.trustScore = Math.min(1.0, profile.trustScore + 0.02);
            if (sentiment === 'negative') profile.trustScore = Math.max(0.0, profile.trustScore - 0.05);
            // Default naik sangat tipis (konsistensi)
            profile.trustScore = Math.min(1.0, profile.trustScore + 0.001);
            
            // Auto-Level Up Role
            this.evaluateRole(profile);
        }

        this.save();
    }

    evaluateRole(profile) {
        if (profile.role === "CREATOR" || profile.role === "BLOCKED") return;

        // Naik Pangkat Berdasarkan Trust
        if (profile.trustScore > 0.8 && profile.familiarity > 50) profile.role = "PARTNER";
        else if (profile.trustScore > 0.5 && profile.familiarity > 20) profile.role = "FRIEND";
        else profile.role = "GUEST";
    }

    save() {
        try {
            fs.writeFileSync(dbPath, JSON.stringify(this.users, null, 2));
        } catch (e) {
            console.error("[SOCIAL] Save failed:", e.message);
        }
    }
}

export default new SocialGraph();
