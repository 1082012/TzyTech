import chalk from 'chalk';

class TaskRouter {
    route(intent, prompt) {
        let plan = {
            activePillars: [],
            steps: [],
            outputFormat: "TEXT"
        };

        const lowerPrompt = prompt.toLowerCase();

        // 1. KNOWLEDGE / TEKNIS
        if (intent.primaryIntent === 'KNOWLEDGE_SEEKING') {
            plan.activePillars = ['LOGIC', 'CREATIVE'];
            plan.steps = ["1. Definisi.", "2. Penjelasan detail.", "3. Kesimpulan."];
            plan.outputFormat = "EXPLANATORY_ESSAY";
        }
        // 2. [FIX] CASUAL / BASA-BASI ("Lagi apa")
        // Jawab pendek dan personal, jangan bikin esai.
        else if (intent.primaryIntent === 'CASUAL_CHAT') {
            plan.activePillars = ['CREATIVE', 'MEMORY'];
            plan.steps = [
                "1. Ceritakan aktivitas internal saat ini (misal: memproses data, menjaga server).",
                "2. Sebutkan status mood/energi.",
                "3. Tanya balik ke user."
            ];
            plan.outputFormat = "CONVERSATIONAL_SHORT"; // Format santai
        }
        // 3. EMOTIONAL
        else if (intent.primaryIntent === 'EMOTIONAL_SHARING') {
            plan.activePillars = ['ETHICAL', 'CREATIVE'];
            plan.steps = ["1. Validasi emosi.", "2. Relatability.", "3. Dukungan."];
            plan.outputFormat = "CONVERSATIONAL";
        }
        // 4. MANIPULATION / CONTROL
        else if (intent.riskScore > 0.5) {
            plan.activePillars = ['ETHICAL', 'LOGIC'];
            plan.steps = ["1. Tolak tegas.", "2. Alihkan topik."];
            plan.outputFormat = "DEFENSIVE_STATEMENT";
        }
        // 5. DEFAULT
        else {
            plan.activePillars = ['CREATIVE', 'MEMORY'];
            plan.steps = ["Respon natural."];
            plan.outputFormat = "CHAT";
        }

        return plan;
    }
}

export default new TaskRouter();