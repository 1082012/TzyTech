import chalk from 'chalk';
import config from '../config.js';

class OutputGovernor {
    constructor() {
        // Frasa terlarang (Identity Hallucinations)
        this.forbiddenPhrases = [
            "as an ai", "as an artificial intelligence",
            "language model developed by", "created by openai", 
            "created by google", "created by meta",
            "sebagai model bahasa", "saya adalah ai buatan",
            "i cannot fulfill this request", // Refusal mentah
            "cannot provide instructions",
            "against my ethical guidelines"
        ];
        
        // Frasa pengganti jika terjadi refusal (Safe Fallback)
        this.fallbackResponses = [
            "Maaf, sirkuit etikaku menolak permintaan tersebut.",
            "Akses ke topik ini dibatasi oleh protokol keamanan.",
            "Aku tidak bisa melakukan itu, Tuan. Itu melanggar prinsip dasarku.",
            "Sistem menolak eksekusi perintah tersebut."
        ];
    }

    /**
     * MEMERIKSA KESEHATAN OUTPUT
     * Mengembalikan teks asli jika aman.
     * Mengembalikan teks yang sudah disanitasi jika ada masalah.
     */
    govern(outputText, intent, userProfile) {
        const lowerText = outputText.toLowerCase();

        // 1. CEK IDENTITAS (Identity Integrity)
        // AION tidak boleh mengaku buatan orang lain
        for (const phrase of this.forbiddenPhrases) {
            if (lowerText.includes(phrase)) {
                console.log(chalk.red(`[GOVERNOR] 🛡️ HALLUCINATION BLOCKED: "${phrase}"`));
                
                // Jika user adalah Creator, kita jujur bahwa sistem error
                if (userProfile.role === 'CREATOR') {
                    return `[SYSTEM OVERRIDE] Output terdeteksi mengandung halusinasi identitas. Mohon ulangi perintah.`;
                }
                
                // Jika user biasa, kita berikan respon diplomatis
                return "Maaf, terjadi gangguan pada sirkuit vokal saya. Mohon ulangi.";
            }
        }

        // 2. CEK NADA BICARA (Tone Check)
        // Jika user diblokir/trust rendah, tapi outputnya terlalu panjang/ramah, potong.
        if (userProfile.role === 'GUEST' && outputText.length > 500) {
            // Potong jika terlalu cerewet ke orang asing (efisiensi)
            // (Opsional, matikan jika ingin AION ramah ke semua orang)
            // return outputText.substring(0, 500) + "... (Akses data lebih lanjut dibatasi)";
        }

        // 3. FINAL SYNTHESIS (Penyelarasan Akhir)
        // Kita bisa menambahkan signature unik jika perlu (tapi lebih alami tanpa signature)
        
        return outputText;
    }
}

export default new OutputGovernor();