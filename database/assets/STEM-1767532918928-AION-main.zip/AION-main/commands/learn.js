import ConceptVault from '../core/ConceptVault.js';
import chalk from 'chalk';
import config from '../config.js';

export default {
    name: 'learn',
    // DAFTAR ALIAS (Shortcut)
    aliases: ['teach', 'latih', 'ask', 'tanya', 'graph', 'otak'],
    description: 'Teach AION structural concepts (Graph Injection)',
    
    // Tambahkan parameter 'command' untuk mendeteksi alias mana yang dipakai
    async execute({ nexus, args, userId, text, command }) {
        // 🔒 SECURITY: Hanya Owner yang boleh mengacak-acak otak
        const isOwner = userId.includes(config.system.ownerNumber.replace('@s.whatsapp.net', ''));
        
        // Exception: '.ask' atau '.tanya' boleh untuk user biasa (Read-Only)
        // Tapi '.teach' wajib Owner.
        const cmdName = command ? command.toLowerCase() : 'learn';
        const isReadMode = ['ask', 'tanya', 'graph', 'otak'].includes(cmdName) || (args[0] === 'ask');
        
        if (!isOwner && !isReadMode) {
            return "⛔ Mode Pengajaran terkunci. Hanya Arsitek yang boleh menanam konsep.";
        }

        // --- LOGIKA DETEKSI ALIAS ---
        let mode = 'help';
        let payload = '';

        // Skenario 1: User ketik ".learn teach ..."
        if (cmdName === 'learn') {
            mode = args[0] ? args[0].toLowerCase() : 'help';
            payload = args.slice(1).join(' ');
        } 
        // Skenario 2: User ketik ".teach ..." (Direct Alias)
        else {
            // Mapping Alias ke Mode Internal
            if (['teach', 'latih'].includes(cmdName)) mode = 'teach';
            if (['ask', 'tanya'].includes(cmdName)) mode = 'ask';
            if (['graph', 'otak'].includes(cmdName)) mode = 'stats';
            
            // Payload adalah seluruh teks setelah command
            payload = args.join(' ');
        }

        // --- MODE 1: TEACH (Assimilation) ---
        if (mode === 'teach') {
            if (!payload) return "⚠️ Masukkan pengetahuan.\nContoh: *.teach Kucing adalah hewan mamalia*";
            
            nexus.terminal.log(chalk.yellow(`[LEARN] Assimilating: "${payload}"`));
            
            try {
                const stats = await ConceptVault.assimilate(payload);
                return `✅ *STRUCTURAL LEARNING COMPLETE*
                
📥 Input: "${payload}"
🔗 Triples: ${stats.triples}
🧠 Neurons Updated: ${stats.nodes}`;
            } catch (e) {
                return `❌ Error: ${e.message}`;
            }
        }

        // --- MODE 2: REASON (Traversal) ---
        if (mode === 'ask') {
            if (!payload) return "⚠️ Masukkan konsep untuk dinalar.\nContoh: *.ask kucing*";
            
            const start = Date.now();
            const result = await ConceptVault.reason(payload);
            const time = Date.now() - start;

            if (result) {
                // Format visualisasi graph yang rapi
                const graphView = result.logicPath.map(p => 
                    `🔹 [${p.source}] —*${p.relation}*→ [${p.target}]`
                ).join('\n');

                return `🧠 *COGNITIVE REASONING* (${time}ms)
                
🔍 *Jalur Logika:*
${graphView}

🗣️ *Kesimpulan:*
"${result.response}"`;
            } else {
                return `💨 *VOID* (${time}ms)
Tidak ada jalur konsep yang ditemukan untuk "${payload}".
(Coba ajarkan dulu dengan: *.teach ${payload} adalah ...*)`;
            }
        }

        // --- MODE 3: STATS ---
        if (mode === 'stats') {
            const stats = await ConceptVault.getStats();
            return `📊 *GRAPH TELEMETRY*
            
• Nodes (Konsep) : ${stats.nodes}
• Edges (Relasi) : ${stats.edges}
• Engine         : RocksDB (Graph Mode)
• Status         : ONLINE`;
        }

        // --- MODE: HELP ---
        return `📚 *AION CONCEPT GRAPH*
Shortcut Commands:

1️⃣ *.teach <kalimat>*
   Menanam fakta baru.
   Ex: _.teach Matahari adalah bintang_

2️⃣ *.ask <konsep>*
   Menelusuri logika graph.
   Ex: _.ask matahari_

3️⃣ *.graph*
   Cek jumlah neuron tersimpan.`;
    }
};