import chalk from 'chalk';

export default {
    name: 'nextpost',
    aliases: ['jadwal', 'schedule', 'kapanupload', 'timer'],
    description: 'Check the next scheduled content upload time',

    execute: async ({ nexus }) => {
        const now = new Date();
        const currentHour = now.getHours();
        const currentMinute = now.getMinutes();
        const currentTimeVal = currentHour * 60 + currentMinute;

        // 1. AMBIL JADWAL FOTO (Dari InstagramManager)
        // Kita akses via nexus.instagram yang sudah di-init di index.js
        const photoSlots = nexus.instagram.timeSlots.map(slot => ({
            type: '📸 FOTO',
            label: slot.label.replace(/_/g, ' '), // Rapikan label
            hour: slot.start,
            minute: 0, // Awal jam
            timeValue: slot.start * 60
        }));

        // 2. AMBIL JADWAL VIDEO (Dari VideoManager)
        const videoSlot = {
            type: '🎬 VIDEO',
            label: 'EPISODIC STORY',
            hour: nexus.video.targetHour,
            minute: nexus.video.targetMinute,
            timeValue: nexus.video.targetHour * 60 + nexus.video.targetMinute
        };

        // 3. GABUNG & URUTKAN JADWAL
        const allSlots = [...photoSlots, videoSlot].sort((a, b) => a.timeValue - b.timeValue);

        // 4. CARI JADWAL BERIKUTNYA
        // Cari yang waktunya lebih besar dari sekarang (Hari Ini)
        let nextEvent = allSlots.find(s => s.timeValue > currentTimeVal);
        let isTomorrow = false;

        // Jika tidak ada jadwal tersisa hari ini, ambil yang paling pagi besok
        if (!nextEvent) {
            nextEvent = allSlots[0]; 
            isTomorrow = true;
        }

        // 5. HITUNG MUNDUR (COUNTDOWN)
        let targetDate = new Date();
        if (isTomorrow) targetDate.setDate(targetDate.getDate() + 1); // Besok
        targetDate.setHours(nextEvent.hour, nextEvent.minute, 0, 0);

        const diffMs = targetDate - now;
        const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

        // Format Tampilan Waktu (HH:MM)
        const pad = (n) => n.toString().padStart(2, '0');
        const timeStr = `${pad(nextEvent.hour)}:${pad(nextEvent.minute)}`;
        const dayStr = isTomorrow ? "Besok" : "Hari Ini";

        // Log Terminal untuk debug
        nexus.terminal.log(chalk.cyan(`[SCHEDULE] Checking next post: ${nextEvent.type} at ${timeStr}`));

        return `
📅 *JADWAL TAYANG BERIKUTNYA*
━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 *Tipe* : ${nextEvent.type}
📝 *Topik* : ${nextEvent.label}
⏰ *Waktu* : ${timeStr} WIB (${dayStr})
⏳ *Countdown* : ${diffHrs} jam ${diffMins} menit lagi.

_Pastikan server tetap menyala agar jadwal tereksekusi._
        `.trim();
    }
};