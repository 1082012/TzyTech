import BioCore from '../core/BioCore.js';

export default {
    name: 'profile',
    aliases: ['level', 'xp', 'evo'],
    description: 'Check Evolution Status & Trajectory',
    
    execute: async () => {
        const evo = BioCore.state.evolution;
        
        // Visualisasi XP Bar
        const barLength = 20;
        const filled = Math.floor((evo.xp / 100) * barLength);
        const bar = '▓'.repeat(filled) + '░'.repeat(barLength - filled);

        return `
📈 *EVOLUTIONARY METRICS*
━━━━━━━━━━━━━━━━━━
🧬 *Level ${evo.level}*
Progress : [${bar}] ${evo.xp.toFixed(1)}%

🔰 *Trajectory Vector*
Status   : ${evo.trajectory}
Learning : +${BioCore.state.neuro.learningDelta} / cycle

🧠 *Capabilities*
Context  : Dynamic (Autoscaling)
Memory   : Persistent
Reflex   : ${BioCore.state.cognition.decisionLag} ms

_Keep interacting to crystallize new neural pathways._
        `;
    }
};