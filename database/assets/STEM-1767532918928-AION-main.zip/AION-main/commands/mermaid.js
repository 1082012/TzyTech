import axios from 'axios';
import chalk from 'chalk';

export default {
    name: 'mermaid',
    aliases: ['graph', 'diagram', 'flowchart', 'mmd'],
    description: 'Render Mermaid.js diagram to Image',
    
    execute: async ({ nexus, args, text }) => {
        // 1. Ambil input Mermaid
        let code = args.join(' ');
        
        if (!code) {
            return `⚠️ *Gunakan sintaks Mermaid JS:*\n\nContoh:\n\`.mermaid graph TD; A[Ide] --> B{Validasi}; B -- Yes --> C[Riset]; B -- No --> D[Arsip];\`\n\n_Lihat dokumentasi mermaid.js untuk sintaks lengkap._`;
        }

        nexus.terminal.log(chalk.cyan(`[MERMAID] Rendering Graph...`));

        try {
            // 2. Encode Code ke Base64 (Syarat API Mermaid.ink)
            // Kita bungkus dalam objek { code: "..." } lalu encode
            const graphDefinition = {
                code: code,
                mermaid: {
                    theme: 'dark', // Tema gelap agar estetik di Terminal/WA
                    themeVariables: {
                        primaryColor: '#00f3ff', // Cyan AION
                        lineColor: '#ffffff'
                    }
                }
            };
            
            // Encode ke Base64 URL Safe
            const jsonString = JSON.stringify(graphDefinition);
            const bufferObj = Buffer.from(jsonString);
            const base64Code = bufferObj.toString('base64');

            // 3. Panggil API Render
            const apiUrl = `https://mermaid.ink/img/${base64Code}?type=png&bgColor=000000`;

            // 4. Download Gambar
            const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(response.data, 'binary');

            // 5. Kirim Gambar
            return {
                image: buffer,
                caption: `📊 *VISUAL STRUKTUR RISET*\nCode: \`${code.substring(0, 50)}...\``,
                mimetype: 'image/png'
            };

        } catch (error) {
            console.error(chalk.red(`[MERMAID FAIL] ${error.message}`));
            return "❌ Gagal merender diagram. Pastikan sintaks Mermaid valid.";
        }
    }
};