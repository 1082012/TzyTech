import ConceptVault from '../core/ConceptVault.js';
import chalk from 'chalk';
import config from '../config.js';

export default {
    name: 'db',
    description: 'Advanced LDB Database Inspector & Debugger',
    aliases: ['database', 'ldb', 'memori'],
    ownerOnly: true, // WAJIB: Hanya Developer

    async execute({ nexus, args, userId }) {
        // Ambil instance DB yang sedang aktif
        const db = ConceptVault.db; 
        
        if (ConceptVault.status !== 'ONLINE') {
            return "⚠️ Database sedang OFFLINE atau Corrupt.";
        }

        const subCmd = args[0] ? args[0].toLowerCase() : 'help';
        const param1 = args[1];
        const param2 = args[2];

        // --- 1. HELP MENU ---
        if (subCmd === 'help') {
            return `🗄️ *AION NEURAL DATABASE TOOLS*
Engine: RocksDB (ClassicLevel)

1️⃣ *.db stats*
   Lihat total nodes & edges.

2️⃣ *.db scan [limit]*
   Lihat 10 data teratas (Raw Data).
   _Ex: .db scan 20_

3️⃣ *.db find <keyword>*
   Cari Node/Edge berdasarkan nama.
   _Ex: .db find kucing_

4️⃣ *.db inspect <konsep>*
   [X-RAY] Lihat detail Konsep & Hubungannya.
   _Ex: .db inspect matahari_
   
5️⃣ *.db raw <key>*
   Lihat value JSON asli dari Key tertentu.`;
        }

        // --- 2. STATS (Telemetri) ---
        if (subCmd === 'stats') {
            let nodes = 0, edges = 0, indexes = 0;
            // Kita scan manual (karena RocksDB tidak punya .count() instan)
            // Limit 5000 biar gak lama hitungnya
            for await (const [key] of db.iterator({ limit: 5000 })) {
                if (key.startsWith('NODE:')) nodes++;
                else if (key.startsWith('EDGE:')) edges++;
                else if (key.startsWith('IDX:')) indexes++;
            }
            
            return `📊 *DATABASE TELEMETRY (Sample 5k)*
            
🔹 Nodes (Konsep) : ${nodes}
🔸 Edges (Relasi) : ${edges}
🔍 Indexes        : ${indexes}
            
_Note: Angka di atas adalah sampel dari 5000 entri pertama untuk kecepatan._`;
        }

        // --- 3. SCAN (Lihat isi database berurutan) ---
        if (subCmd === 'scan') {
            const limit = parseInt(param1) || 10;
            const startKey = param2 || undefined; // Bisa resume dari key tertentu (pagination)
            
            let output = `🗂️ *SCANNING MEMORY (Limit: ${limit})*\n`;
            let count = 0;
            let lastKey = "";

            const options = { limit: limit };
            if (startKey) options.gt = startKey; // Resume scan

            for await (const [key, value] of db.iterator(options)) {
                // Formatting biar enak dibaca
                let typeIcon = "📦";
                if (key.startsWith('NODE:')) typeIcon = "🔹";
                if (key.startsWith('EDGE:')) typeIcon = "🔸";
                
                // Ringkas value jika terlalu panjang
                const valStr = JSON.stringify(value).substring(0, 50) + (JSON.stringify(value).length > 50 ? "..." : "");
                
                output += `\n${typeIcon} *${key}*\n   └ ${valStr}`;
                lastKey = key;
                count++;
            }

            if (count === 0) return "📭 Database kosong atau akhir data tercapai.";

            output += `\n\n_Next Page: .db scan ${limit} ${lastKey}_`;
            return output;
        }

        // --- 4. FIND (Filter by Keyword) ---
        if (subCmd === 'find') {
            const keyword = param1;
            if (!keyword) return "⚠️ Masukkan keyword. Contoh: .db find kucing";

            let output = `🔍 *SEARCH RESULT: "${keyword}"*\n`;
            let count = 0;

            // Scan database (Max scan 1000 items prevent lag)
            for await (const [key, value] of db.iterator({ limit: 2000 })) {
                if (key.toLowerCase().includes(keyword.toLowerCase())) {
                    const type = key.split(':')[0];
                    output += `\n• *${key}* (${type})`;
                    count++;
                    if (count >= 15) { // Max tampilkan 15 hasil
                        output += `\n\n_...dan hasil lainnya disembunyikan._`;
                        break; 
                    }
                }
            }

            if (count === 0) return "❌ Tidak ditemukan data dengan keyword tersebut.";
            return output;
        }

        // --- 5. INSPECT (X-RAY VIEW - PALING PENTING) ---
        // Ini fitur tercanggih: merekonstruksi Node + Edges-nya
        if (subCmd === 'inspect') {
            const concept = param1;
            if (!concept) return "⚠️ Masukkan konsep. Contoh: .db inspect matahari";

            const nodeKey = `NODE:${concept.toLowerCase()}`;
            let nodeData = null;

            try {
                nodeData = await db.get(nodeKey);
            } catch (e) {
                return `❌ Node *${concept}* tidak ditemukan di memori LDB.`;
            }

            let output = `🧠 *NEURAL NODE INSPECTION*\n`;
            output += `🆔 *CONCEPT:* ${nodeData.label}\n`;
            output += `⏱️ *Last Seen:* ${new Date(nodeData.last_seen).toLocaleString()}\n`;
            output += `⚖️ *Weight:* 1.0\n`; // Placeholder weight
            
            output += `\n🔗 *CONNECTIONS (Synapses):*\n`;

            // Cari semua EDGE yang berhubungan dengan node ini
            // Kita scan range EDGE:concept: ... sampai EDGE:concept:~
            let edgeCount = 0;
            const startRange = `EDGE:${concept.toLowerCase()}:`;
            const endRange = `EDGE:${concept.toLowerCase()}:\xff`;

            for await (const [key, val] of db.iterator({ gt: startRange, lt: endRange })) {
                // Key format: EDGE:source:target
                const target = key.split(':')[2];
                output += `   ├─( *${val.type}* )─> ${target}\n`;
                edgeCount++;
            }

            if (edgeCount === 0) output += `   (Tidak ada hubungan yang tercatat)`;

            return output;
        }

        // --- 6. RAW (Get JSON Value) ---
        if (subCmd === 'raw') {
            const key = args.slice(1).join(' '); // Support spasi di key
            if (!key) return "⚠️ Masukkan Key lengkap. Gunakan .db scan untuk melihat key.";

            try {
                const data = await db.get(key);
                return `📦 *RAW DATA DUMP*\nKey: ${key}\n\n\`\`\`json\n${JSON.stringify(data, null, 2)}\n\`\`\``;
            } catch (e) {
                return "❌ Key tidak ditemukan.";
            }
        }

        return "⚠️ Perintah tidak dikenal. Ketik *.db help*";
    }
};