import axios from 'axios';
import chalk from 'chalk';

export default {
    name: 'math',
    aliases: ['rumus', 'latex', 'eq', 'formula'],
    description: 'Render LaTeX math equation to Image',
    
    execute: async ({ nexus, args, text }) => {
        // 1. Ambil input LaTeX
        // Hapus nama command (.math) dari teks
        let latex = args.join(' ');
        
        if (!latex) {
            return `⚠️ *Gunakan format LaTeX:*\nContoh: \`.math \\int_{0}^{\\infty} x^2 dx\`\n\nAtau: \`.math \\frac{dE}{dt} = E_{in} - E_{out}\``;
        }

        nexus.terminal.log(chalk.cyan(`[MATH] Rendering Equation: ${latex}`));

        try {
            // 2. Gunakan API Render Engine (CodeCogs)
            // Kita setting DPI 300 (High Res) dan Background Putih (biar terbaca di Dark Mode WA)
            const apiUrl = `https://latex.codecogs.com/png.latex?\\dpi{300}\\bg_white ${encodeURIComponent(latex)}`;

            // 3. Download Gambar ke Buffer (Memory)
            const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(response.data, 'binary');

            // 4. Kirim sebagai Gambar
            return {
                image: buffer,
                caption: `🧮 *MATH EQUATION*\nSource: \`$ ${latex} \``,
                mimetype: 'image/png'
            };

        } catch (error) {
            console.error(chalk.red(`[MATH FAIL] ${error.message}`));
            return "❌ Gagal merender rumus. Pastikan sintaks LaTeX benar.";
        }
    }
};