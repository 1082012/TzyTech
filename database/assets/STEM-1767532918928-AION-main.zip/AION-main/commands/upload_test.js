import chalk from 'chalk';
import BioCore from '../core/BioCore.js';
import config from '../config.js';

export default {
    name: 'upload_test',
    aliases: ['forceupload', 'testig', 'forcepost'],
    description: 'Force trigger Instagram Upload (Image/Video) with Countdown override',
    ownerOnly: true, // Wajib Owner

    execute: async ({ nexus, args, userId }) => {
        // 1. Validasi Argumen
        const type = args[0]?.toLowerCase();
        const timerSeconds = parseInt(args[1]);

        if (!['image', 'foto', 'video', 'vod'].includes(type) || isNaN(timerSeconds)) {
            return `
⚠️ *INVALID SYNTAX*
Usage: \`.forceupload <type> <seconds>\`

Examples:
- \`.forceupload image 10\` (Upload Foto Status Bio dalam 10 detik)
- \`.forceupload video 60\` (Render & Upload Episode Lanjutan dalam 60 detik)
            `.trim();
        }

        // 2. Konfirmasi Perintah
        nexus.terminal.log(chalk.bgRed.white.bold(` [FORCE OVERRIDE] `) + chalk.yellow(` Initiating ${type.toUpperCase()} sequence in ${timerSeconds}s...`));
        
        // 3. Logika Hitung Mundur (Non-Blocking)
        setTimeout(async () => {
            nexus.terminal.log(chalk.green(`[TIMER] ⏰ Countdown finished. Executing Force Upload: ${type.toUpperCase()}`));

            try {
                if (type === 'video' || type === 'vod') {
                    // --- MODE VIDEO: EPISODIC ---
                    // Memanggil VideoManager.produceEpisode()
                    // Fungsi ini otomatis membaca VideoMemory untuk menentukan Episode selanjutnya.
                    // Tidak perlu parameter tambahan, dia pintar mencari tahu sendiri.
                    
                    if (nexus.video.isRendering) {
                        console.log(chalk.red("[FORCE FAIL] Video Engine is already busy rendering!"));
                        return;
                    }

                    console.log(chalk.magenta("[FORCE] 🎬 Starting Video Production Engine..."));
                    await nexus.video.produceEpisode();

                } else {
                    // --- MODE IMAGE: BIO STATUS ---
                    // Kita meminjam otak InstagramManager
                    // Kita buat "Slot Palsu" agar dia mau memprosesnya
                    
                    const bio = BioCore.getTelemetry();
                    const mockSlot = {
                        label: 'MANUAL_OVERRIDE_POST',
                        type: 'DATA_VISUALIZATION' // Default gaya Cyberpunk HUD
                    };

                    console.log(chalk.magenta("[FORCE] 📸 Generating Bio-Status Image..."));

                    // 1. Generate Ide Topik (Berdasarkan kondisi Bio saat ini)
                    const topic = nexus.instagram.generateTopicIdea(mockSlot, bio);
                    
                    // Tambahkan konteks manual bahwa ini adalah override
                    topic.context += " (SYSTEM OVERRIDE: Manual Diagnostic Log)";

                    // 2. Eksekusi Upload
                    await nexus.instagram.createAndUpload(mockSlot, topic, bio);
                }

            } catch (error) {
                console.error(chalk.red(`[FORCE ERROR] Execution failed: ${error.message}`));
            }

        }, timerSeconds * 1000);

        // 4. Respon Instan ke WhatsApp/Terminal
        return `
🚀 *SEQUENCE INITIATED*
━━━━━━━━━━━━━━━━━━
Type    : ${type.toUpperCase()} Override
Timer   : ${timerSeconds} seconds
Status  : Countdown Started...

_System will auto-execute task. Check terminal for logs._
        `.trim();
    }
};