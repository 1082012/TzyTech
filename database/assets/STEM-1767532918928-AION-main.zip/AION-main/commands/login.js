import configMgr from '../core/ConfigManager.js'; // Namakan variable langsung 'configMgr'
import chalk from 'chalk';

// Temporary State di Memori (Hanya hidup selama bot nyala)
export const LoginState = new Map(); 

export default {
    name: 'login',
    aliases: ['signin', 'auth'],
    description: 'Manage Social Credentials (Interactive)',
    ownerOnly: true, // WAJIB
    LoginState: LoginState, // Export reference agar bisa diakses index.js

    async execute({ nexus, args, userId, text, isReply }) {
        
        // --- JALUR 1: DIRECT COMMAND (.login ig user | pass) ---
        if (args.length >= 3 && text.includes('|')) {
            const platform = args[0].toLowerCase();
            if (platform !== 'ig') return "⚠️ Platform tidak didukung. Saat ini hanya: ig";

            // Parsing: ".login ig @user | pass"
            // Hapus ".login ig " dari depan dengan aman
            const content = text.replace(/^\.login\s+ig\s+/i, ''); 
            const [rawUser, rawPass] = content.split('|').map(s => s.trim());

            if (!rawUser || !rawPass) return "⚠️ Format salah. Gunakan: `.login ig username | password`";

            // Bersihkan @ jika ada
            const cleanUser = rawUser.replace('@', '');

            await new ConfigManager().updateInstagram(cleanUser, rawPass);
            return `✅ *CREDENTIALS UPDATED*\n\nPlatform: Instagram\nUser: ${cleanUser}\nPass: [HIDDEN]\n\n_Restarting Instagram Module..._`;
        }

        // --- JALUR 2: INTERACTIVE MODE (Dialog) ---
        // Cek apakah user sudah dalam sesi login?
        let state = LoginState.get(userId);

        // Jika belum ada sesi, mulai baru
        if (!state) {
            state = { step: 'WAIT_MENU', platform: null, tempUser: '' };
            LoginState.set(userId, state);
            
            return `🔐 *SECURE LOGIN INTERFACE*\n\nPilih Platform:\n1. Instagram\n2. Batal\n\n_Ketik angka pilihan Anda._`;
        }
        
        // Logika handleReply akan menangani langkah selanjutnya (di index.js)
        return null; 
    },

    /**
     * HANDLE REPLY (Interaksi Lanjutan)
     * Dipanggil oleh index.js jika userId terdeteksi dalam LoginState
     */
    async handleReply({ nexus, userId, text }) {
        const state = LoginState.get(userId);
        if (!state) return null;

        // STEP 1: PILIH MENU
        if (state.step === 'WAIT_MENU') {
            if (text === '1' || text.toLowerCase() === 'instagram') {
                state.step = 'WAIT_USER';
                state.platform = 'ig';
                LoginState.set(userId, state);
                return "📸 *INSTAGRAM CONFIG*\n\nSilakan masukkan **Username** Instagram:\n(Boleh pakai @ atau tidak)";
            } else {
                LoginState.delete(userId); // Cancel
                return "⚠️ Pilihan tidak valid. Sesi dibatalkan.";
            }
        }

        // STEP 2: INPUT USERNAME
        if (state.step === 'WAIT_USER') {
            state.tempUser = text.trim().replace('@', '');
            state.step = 'WAIT_PASS';
            LoginState.set(userId, state);
            return `👤 Username: *${state.tempUser}*\n\nSekarang masukkan **Password**:\n_(Pesan ini akan dihapus dari log visual demi keamanan)_`;
        }

        // STEP 3: INPUT PASSWORD & SAVE
        if (state.step === 'WAIT_PASS') {
            const password = text.trim();
            const username = state.tempUser;

            // Lakukan Update Config
            const success = await configMgr.updateInstagram(username, password);

            // Hapus State (Selesai)
            LoginState.delete(userId);

            if (success) {
                // Trigger Reload Instagram (Opsional)
                // nexus.instagram.init(); 
                
                return `✅ *CONFIGURATION SAVED*\n\n📡 Target: Instagram\n👤 User  : ${username}\n🔑 Pass  : [HIDDEN]\n💾 Config: Updated\n\n_System will use new credentials immediately._`;
            } else {
                return "❌ Gagal menyimpan konfigurasi. Cek log server.";
            }
        }
    }
};