import MemoryStore from '../core/MemoryStore.js';
import BioCore from '../core/BioCore.js';

export default {
    name: 'reset',
    aliases: ['clear', 'lupa', 'wipe'],
    description: 'Wipe Short-Term Memory (Episodic)',
    
    execute: async ({ nexus }) => {
        // 1. Hapus Memori
        await MemoryStore.clearEpisodic();
        
        // 2. Reset Emosi ke Netral
        BioCore.reset();
        
        return `[SYSTEM OPTIMIZED] Hippocampus flushed. Short-term memory wiped. Affect state reset to NEUTRAL.`;
    }
};