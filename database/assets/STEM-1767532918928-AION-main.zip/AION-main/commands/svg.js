import sharp from 'sharp';
import chalk from 'chalk';

export default {
    name: 'svg',
    aliases: ['vector', 'draw', 'render'],
    description: 'Render SVG code to Image (using Sharp engine)',
    
    execute: async ({ nexus, args, text }) => {
        // 1. Ambil input SVG
        let code = args.join(' ');
        
        if (!code) {
            return `⚠️ *Gunakan sintaks SVG:*\n\nContoh Full:\n\`.svg <svg width="100" height="100"><circle cx="50" cy="50" r="40" fill="red" /></svg>\`\n\nAtau Shortcut (Auto-wrap 512px):\n\`.svg <rect x="10" y="10" width="100" height="100" fill="#00f3ff" />\``;
        }

        nexus.terminal.log(chalk.cyan(`[SVG] Rendering Vector Graphics...`));

        try {
            // 2. SMART WRAPPER (Auto-Correction)
            // Jika user malas nulis tag <svg> pembuka/penutup, kita buatkan kanvas default 512x512
            if (!code.trim().startsWith('<svg')) {
                code = `<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
                    <rect width="100%" height="100%" fill="#000000" fill-opacity="0.5"/>
                    ${code}
                </svg>`;
            }

            // 3. Render ke PNG menggunakan Sharp
            // Sharp mengubah Buffer String SVG -> Buffer Binary PNG
            const inputBuffer = Buffer.from(code);
            const outputBuffer = await sharp(inputBuffer)
                .png() // Konversi ke PNG
                .toBuffer();

            // 4. Kirim Gambar
            return {
                image: outputBuffer,
                caption: `🎨 *VECTOR RENDER*\nSize: ${code.length} bytes`,
                mimetype: 'image/png'
            };

        } catch (error) {
            console.error(chalk.red(`[SVG FAIL] ${error.message}`));
            return `❌ Gagal merender SVG. Pastikan sintaks XML valid.\n\nError: _${error.message}_`;
        }
    }
};