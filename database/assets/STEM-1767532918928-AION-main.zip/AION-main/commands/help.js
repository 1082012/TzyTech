export default {
    name: 'help',
    aliases: ['menu', 'guide', '?'],
    description: 'List all available neural capabilities',
    
    execute: async ({ nexus }) => {
        const commands = nexus.aether.commands; // Ambil daftar command dari loader
        let text = "📜 *NEURAL CAPABILITIES*\n━━━━━━━━━━━━━━━━━━\n";
        
        // Loop semua command yang terdaftar
        commands.forEach(cmd => {
            text += `🔹 *${cmd.name}*`;
            if (cmd.aliases && cmd.aliases.length > 0) {
                text += ` [${cmd.aliases.join(', ')}]`;
            }
            text += `\n   └ ${cmd.description}\n`;
        });

        text += "\n_Type command name to execute._";
        return text;
    }
};