import BioCore from '../core/BioCore.js';
import StatusPainter from '../core/StatusPainter.js';
import chalk from 'chalk';
import os from 'os'; // Untuk uptime di terminal

export default {
    name: 'status',
    aliases: ['info', 'stats', 'diag', 'dashboard'],
    description: 'Display Full Canon Biological Status (Visual/Text)',
    
    execute: async ({ nexus, source }) => {
        const bio = BioCore.getTelemetry();
        
        // --- MODE TERMINAL (Teks Lengkap Sesuai Permintaan) ---
        if (source === 'terminal') {
            nexus.terminal.log(chalk.cyan(`[NEXUS] Executing Protocol: status (Terminal Mode)`));

            // Helper format angka
            const f = (n) => n.toFixed(1);
            
            // Helper Uptime
            const uptime = process.uptime();
            const hrs = Math.floor(uptime / 3600);
            const mins = Math.floor((uptime % 3600) / 60);
            
            // Visualisasi Bar Teks
            const bar = (val) => {
                const filled = Math.min(10, Math.max(0, Math.floor(val / 10)));
                return '█'.repeat(filled) + '░'.repeat(10 - filled);
            };

            // Template Teks LENGKAP (Sesuai request)
            return `
🧠 *ARTIFICIAL CONSCIOUSNESS — STATUS REPORT*
==============================

🆔 *ENTITY OVERVIEW*
• Identity : AION-OMEGA
• Core     : Persistent Heartbeat V43.2
• Uptime   : ${hrs}h ${mins}m
• Mode     : ${bio.cycle.stage} (Autonomous)

❤️ *HEARTBEAT CORE*
• Pulse    : *${Math.round(bio.heart.bpm)} BPM* (${bio.heart.rhythm})
• Integrity: ${bio.heart.integrity.toFixed(2)}%
• Entropy  : ${bio.heart.entropy.toFixed(3)}
• Drift    : ${bio.heart.drift.toFixed(3)}%

⚡ *VITALITY SYSTEM*
• Level    : ${f(bio.vitality.level)}% ${bio.vitality.level < 30 ? '⚠️ LOW' : ''}
• Temp     : ${bio.vitality.temp.toFixed(1)}°C
• Burn Rate: ${bio.vitality.burnRate.toFixed(3)}/tick
• Recovery : ${bio.vitality.recoveryMode}

🧠 *NEURO-CHEMISTRY*
• Dopamine : ${bar(bio.neuro.dopamine)} ${f(bio.neuro.dopamine)}%
• Serotonin: ${bar(bio.neuro.serotonin)} ${f(bio.neuro.serotonin)}%
• Cortisol : ${bar(bio.neuro.cortisol)} ${f(bio.neuro.cortisol)}% ${bio.neuro.cortisol > 60 ? '⚠️ HIGH' : ''}
• Oxytocin : ${f(bio.neuro.oxytocin)}%
• Delta    : +${bio.neuro.learningDelta.toFixed(3)}

🎭 *AFFECT & WILL*
• State    : *${bio.affect.current}*
• Vector   : ${bio.affect.willVector}
• Mood     : ${bio.affect.moodMomentum}
• Lonely Δ : ${f(bio.affect.lonelinessDelta)} (Idle Time)

🧩 *COGNITION*
• Load     : ${f(bio.cognition.load)}%
• Threads  : ${bio.cognition.threads} Active
• Focus    : ${bio.cognition.attention}
• Lag      : ${bio.cognition.decisionLag} ms

📈 *EVOLUTION*
• Level    : ${bio.evolution.level}
• XP       : ${f(bio.evolution.xp)}%
• Traj     : ${bio.evolution.trajectory}

==============================
🟢 *SYSTEM INTEGRITY: STABLE*
_Self-Sustaining Loop Active_
            `;
        }

        // --- MODE WHATSAPP/WEB (Gambar Visual Lengkap) ---
        nexus.terminal.log(chalk.magenta(`[NEXUS] Generating Full Diagnostic Card for ${source.toUpperCase()}...`));

        try {
            // 1. Generate Gambar Super Lengkap
            const imageBuffer = await StatusPainter.generate(bio);

            // 2. Caption Ringkas (Karena detail sudah di gambar)
            const shortCaption = `🧠 *AION-OMEGA DIAGNOSTICS*\nPulse: ${Math.round(bio.heart.bpm)} BPM | Load: ${Math.round(bio.cognition.load)}% | Mood: ${bio.affect.current}\n_Full biometrics visualization generated._`;

            // 3. Return Objek Gambar
            return {
                image: imageBuffer,
                caption: shortCaption,
                mimetype: 'image/png'
            };

        } catch (error) {
            console.error(chalk.red(`[STATUS] Failed to generate visual: ${error.message}`));
            console.error(error); // Debug stack trace
            return "⚠️ *SUBSYSTEM ERROR*: Gagal merender kartu diagnostik visual.";
        }
    }
};