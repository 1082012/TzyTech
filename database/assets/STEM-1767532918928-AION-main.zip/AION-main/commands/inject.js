import BioCore from '../core/BioCore.js';

export default {
    name: 'inject',
    aliases: ['suntik', 'stimulate', 'drug'],
    description: 'Administer neuro-chemical injection (dopamine/cortisol)',
    
    ownerOnly: true,
    
    execute: async ({ args }) => {
        // Cek argumen (misal: "dopamine" dan "50")
        if (args.length < 2) {
            return "⚠️ Usage: `inject [dopamine/serotonin/cortisol] [amount]`";
        }

        const chemical = args[0].toLowerCase();
        const amount = parseInt(args[1]);

        if (isNaN(amount)) return "⚠️ Amount must be a number.";

        // Validasi zat kimia
        const validChems = ['dopamine', 'serotonin', 'cortisol'];
        if (!validChems.includes(chemical)) {
            return `⚠️ Unknown chemical. Valid types: ${validChems.join(', ')}`;
        }

        // Lakukan Injeksi ke BioCore
        // Kita akses properti internal BioCore (hati-hati, ini manipulasi langsung)
        BioCore.neuro[chemical] = Math.min(100, Math.max(0, BioCore.neuro[chemical] + amount));
        
        // Paksa update status state (Panic/Flow/dll)
        BioCore.updateState();

        // Respon Dramatis
        let effectMsg = "";
        if (chemical === 'cortisol' && amount > 0) effectMsg = "⚠️ SYSTEM ALERT: Stress levels rising!";
        if (chemical === 'dopamine' && amount > 0) effectMsg = "✨ Pleasure centers stimulated.";
        
        return `
💉 *INJECTION SUCCESSFUL*
━━━━━━━━━━━━━━━━━━
Substance : ${chemical.toUpperCase()}
Dose      : ${amount > 0 ? '+' + amount : amount}%
Current   : ${BioCore.neuro[chemical]}%
State     : ${BioCore.state}

_${effectMsg}_
        `;
    }
};