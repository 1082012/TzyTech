import Settings from '../core/Settings.js'; // Import Manager Baru

export default {
    name: 'setprefix',
    aliases: ['prefix', 'p'],
    description: 'Change command prefix configuration (Persistent)',
    ownerOnly: true,

    execute: async ({ args }) => {
        if (!args.length) {
            const currentMode = Settings.get('prefixMode');
            const currentPrefixes = Settings.get('prefixes').join(', ');
            
            return `
⚙️ *PREFIX CONFIGURATION (LIVE)*
━━━━━━━━━━━━━━━━━━
Mode    : ${currentMode.toUpperCase()}
Symbols : [ ${currentPrefixes} ]
Status  : Saved to Database 💾

*Usage:*
- \`setprefix single !\`
- \`setprefix multi . # /\`
- \`setprefix no\`
            `;
        }

        const mode = args[0].toLowerCase();

        // 1. Mode NO PREFIX
        if (mode === 'no' || mode === 'off') {
            Settings.set('prefixMode', 'no_prefix');
            return "✅ *PREFIX DISABLED.* Disimpan ke memori permanen.";
        }

        // 2. Mode SINGLE
        if (mode === 'single') {
            const newSymbol = args[1];
            if (!newSymbol) return "⚠️ Harap masukkan simbol.";

            Settings.set('prefixMode', 'single');
            Settings.set('prefixes', [newSymbol]);
            
            return `✅ *SINGLE PREFIX SET:* [ ${newSymbol} ]\n_Config updated & saved._`;
        }

        // 3. Mode MULTI
        if (mode === 'multi') {
            const newSymbols = args.slice(1);
            if (newSymbols.length === 0) return "⚠️ Harap masukkan simbol.";

            Settings.set('prefixMode', 'multi');
            Settings.set('prefixes', newSymbols);
            
            return `✅ *MULTI PREFIX SET:* [ ${newSymbols.join(', ')} ]\n_Config updated & saved._`;
        }

        return "❌ Mode tidak valid.";
    }
};