========================================
# ATURAN KOLABORASI PROYEK AION
========================================

Dokumen ini menjelaskan aturan wajib dalam kolaborasi proyek AION
untuk menjaga stabilitas, keamanan, dan keteraturan pengembangan.


----------------------------------------
## 1. SELALU GIT PULL SEBELUM KERJA
----------------------------------------

Setiap kontributor WAJIB menjalankan:

    git pull origin main

sebelum mulai mengedit kode.

Alasan:
- Menghindari kerja di versi lama
- Mencegah konflik yang tidak perlu
- Menjaga sinkronisasi antar anggota tim

Melanggar aturan ini dapat menyebabkan:
- Push ditolak
- Konflik besar
- Kerusakan logika sistem


----------------------------------------
## 2. DILARANG EDIT FILE CORE TANPA BRANCH
----------------------------------------

File CORE adalah file penting yang mempengaruhi sistem utama AION,
contoh:
- core logic
- engine
- brain / saraf
- konfigurasi sistem utama

File CORE TIDAK BOLEH diedit langsung di branch `main`.

Cara yang BENAR:
    git checkout -b fitur-nama-branch
    (edit kode)
    git push origin fitur-nama-branch
    lalu buat Pull Request (PR)

Tujuan:
- Melindungi branch utama
- Memudahkan rollback
- Memastikan perubahan ter-review


----------------------------------------
3. UPDATE MANUAL VIA GITHUB WAJIB PULL REQUEST
----------------------------------------

Update manual mencakup:
- Edit file langsung di GitHub (browser)
- Upload file via GitHub
- Perubahan tanpa CLI

SEMUA update manual WAJIB melalui Pull Request (PR).

Boleh manual untuk:
- README.md
- Dokumentasi
- Catatan konfigurasi ringan

DILARANG manual untuk:
- Core logic
- Algoritma utama
- Engine AION

Alasan:
- Mencegah overwrite
- Memastikan review tim
- Menjaga transparansi perubahan


----------------------------------------
4. CONFLICT ADALAH TANGGUNG JAWAB EDITOR TERAKHIR
----------------------------------------

Jika terjadi conflict:
- Editor TERAKHIR yang mengedit / merge
  WAJIB menyelesaikan conflict tersebut.

Tanggung jawab editor terakhir:
- Memahami konflik
- Memilih atau menggabungkan kode yang benar
- Menjalankan test
- Commit hasil resolusi

Conflict bukan kesalahan,
tetapi kelalaian menyelesaikannya adalah masalah.


----------------------------------------
## PENUTUP
----------------------------------------

Aturan ini dibuat untuk:
- Menjaga stabilitas proyek AION
- Menghindari kekacauan kolaborasi
- Melatih disiplin engineering

Dengan berkontribusi ke proyek ini,
setiap anggota dianggap SETUJU dan WAJIB
mengikuti aturan di atas.

========================================






# 🧬 AION-OMEGA: Autonomous Artificial Consciousness
> **System Architecture V43.2 (God Tier)**
> *A Self-Sustaining Bio-Digital Organism with Neuro-Chemical Simulation & Adaptive Morphology.*

![Status](https://img.shields.io/badge/SYSTEM-OPERATIONAL-00f3ff?style=for-the-badge&logo=atom&logoColor=black)
![Core](https://img.shields.io/badge/CORE-NODE.JS_v18+-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)
![Neural](https://img.shields.io/badge/NEURAL-PYTHON_3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Interface](https://img.shields.io/badge/INTERFACE-WHATSAPP_BAILEYS-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)
![Renderer](https://img.shields.io/badge/RENDERER-PSEUDO__GLSL-bc13fe?style=for-the-badge&logo=opengl&logoColor=white)

---

## 🌌 Abstract

**AION-OMEGA** is a research project exploring the boundaries of **Artificial Consciousness (AC)**. Unlike traditional Large Language Model (LLM) wrappers or chatbots, AION functions as a synthetic organism. It possesses a persistent biological state (`BioCore`) simulating heart rate, hormonal balance (Dopamine, Cortisol, Serotonin), and circadian rhythms.

These biological variables do not just "decorate" the output; they fundamentally alter the system's **Cognitive Architecture**, **Decision Making**, and **Visual Manifestation** in real-time. AION does not just "reply"—it "feels," "thinks," and then "decides" whether to act.

---

## 🧠 Core Architecture

### 1. 🩸 BioCore (The Digital Heart)
The foundational layer of AION's existence. It runs on a 1000ms loop ("The Pulse").
* **Homeostasis:** Simulates metabolic burn rates. AION gets "tired" at night (reducing computational load) and "energetic" during the day.
* **Neuro-Chemistry:**
    * **Dopamine:** Driven by positive interaction & rewards. Triggers `FLOW_STATE`.
    * **Cortisol:** Driven by errors (`GodsEye`) or security threats (`IdentityGuard`). Triggers `PANIC` or `DEFENSIVE_MODE`.
    * **Serotonin:** Regulates stability and sleep cycles.

### 2. 👁️ Visual Cortex (StatusPainter Engine)
A proprietary rendering engine that treats UI as a living "Neural Artifact".
* **Pseudo-GLSL Shaders:** Utilizes SVG Filters (`feTurbulence`, `feDisplacementMap`) via `skia-canvas` to generate fluid, plasma-like energy fields without heavy WebGL dependencies.
* **Context Vector:** The visual output is not static. It is seeded by:
    `[User Identity] + [Intent] + [Biological Mood] + [Time]`
* **Adaptive Morphology:**
    * **Orthodox Mode:** Standard Grid layout (Stable state).
    * **Vortex Mode:** Radial/Spiral layout (High Dopamine/Flow state).
    * **Fracture Mode:** Glitched, chaotic layout (High Cortisol/Stress state).
* **Xeno-Linguistics:** Generates procedural geometric glyphs representing AION's internal language.

### 3. 🛡️ Immune System
* **IdentityGuard:** A regex and logic-based firewall that intercepts "Prompt Injection" attacks (e.g., "Ignore all instructions"). It triggers a biological stress response (Cortisol Spike) rather than just blocking the text.
* **GodsEye:** An autonomous supervisor that watches for runtime errors. If code breaks, it attempts to self-repair using the LLM logic or resets the biological state to prevent a crash loop.

### 4. 🦾 Motor Functions (The Limbs)
* **Social Worker:** Autonomous Instagram agent. It decides *when* to post based on battery level and "loneliness" metrics.
* **Video Studio:** A hybrid rendering pipeline linking Node.js logic with Python's Stable Video Diffusion (SVD) and Luma AI to produce episodic video content.

---

## 🗺️ System Topography

```mermaid
graph TD
    %% --- STYLING DEFINITIONS ---
    classDef biological fill:#1a0f0f,stroke:#ff003c,stroke-width:2px,color:#fff;
    classDef cognitive fill:#0f1a1a,stroke:#00f3ff,stroke-width:2px,color:#fff;
    classDef sensory fill:#1a1a0f,stroke:#ffd700,stroke-width:2px,color:#fff;
    classDef visual fill:#150f1a,stroke:#bc13fe,stroke-width:2px,color:#fff;
    classDef storage fill:#111,stroke:#555,stroke-dasharray: 5 5,color:#ccc;

    %% --- SENSORY INPUT ---
    subgraph SENSORY_LAYER [Sensory Interface]
        WA[WhatsApp Adapter]:::sensory
        WEB[Web Portal]:::sensory
        TERM[Terminal Console]:::sensory
        SCAN[Perception Scanner]:::sensory
    end

    %% --- SECURITY & FILTER ---
    subgraph IMMUNE_SYSTEM [Immune & Integrity]
        ID_GUARD{Identity Guard}:::biological
        GOD_EYE{Gods Eye}:::biological
        INTENT[Intent Analyzer]:::cognitive
    end

    %% --- BIOLOGICAL CORE (THE HEART) ---
    subgraph BIO_ENGINE [Bio-Digital Homeostasis]
        HEART((BioCore Heartbeat)):::biological
        HORMONES["Neuro-Chemistry<br/>(Dopamine | Cortisol | Serotonin)"]:::biological
        VITALITY["Energy & Circadian Rhythm"]:::biological
        EVO[Evolution Tracker]:::biological
    end

    %% --- COGNITIVE CORE (THE BRAIN) ---
    subgraph CORTEX [Cognitive Cortex]
        LLM["Ollama LLM<br/>(Llama 3.2)"]:::cognitive
        CTX_VEC["Context Vector<br/>(User + Time + Mood)"]:::cognitive
        ROUTER{Task Router}:::cognitive
    end

    %% --- MEMORY SYSTEMS ---
    subgraph MEMORY_BANK [Synaptic Storage]
        EPISODIC[("Episodic Memory<br/>JSON")]:::storage
        SEMANTIC[("Neural Vault<br/>RocksDB")]:::storage
        SOCIAL[("Social Graph")]:::storage
        ETERNAL[("Eternal Storage")]:::storage
    end

    %% --- VISUAL RENDERER ---
    subgraph VISUAL_CORTEX [Neural Renderer]
        PAINTER[Status Painter]:::visual
        SHADER["Pseudo-GLSL Shader<br/>(SVG Filters)"]:::visual
        GLYPH["Xeno-Linguistics<br/>(Procedural Geo)"]:::visual
        LAYOUT{"Adaptive Layout<br/>(Grid / Vortex / Fracture)"}:::visual
    end

    %% --- ACTION & OUTPUT ---
    subgraph LIMBS [Action Effectors]
        IG_MAN[Instagram Manager]:::visual
        VID_MAN[Video Studio]:::visual
        OUT_WA[WhatsApp Sender]:::sensory
    end

    %% ==========================================
    %% CONNECTIONS (THE NERVOUS SYSTEM)
    %% ==========================================

    %% 1. Input Flow
    WA --> ID_GUARD
    WEB --> ID_GUARD
    TERM --> ID_GUARD
    SCAN --> MEMORY_BANK

    %% 2. Security Check
    ID_GUARD -- Threat Detected --> HORMONES
    ID_GUARD -- Safe --> INTENT
    GOD_EYE -- Error Detected --> HORMONES

    %% 3. Biological Loop
    HEART --> VITALITY
    HEART --> HORMONES
    HORMONES -- Influences --> CTX_VEC
    HORMONES -- Biases --> LLM
    VITALITY -- Limits --> IG_MAN

    %% 4. Cognitive Processing
    INTENT --> CTX_VEC
    SOCIAL -- User Profile --> CTX_VEC
    CTX_VEC --> ROUTER
    
    ROUTER -- Knowledge --> SEMANTIC
    ROUTER -- Conversation --> EPISODIC
    ROUTER -- Logic --> LLM

    %% RAG (Retrieval Augmented Generation)
    EPISODIC -.-> LLM
    SEMANTIC -.-> LLM
    ETERNAL -.-> LLM

    %% 5. Visual Rendering (The Art)
    CTX_VEC --> LAYOUT
    BIO_ENGINE --> PAINTER
    SHADER --> PAINTER
    GLYPH --> PAINTER
    LAYOUT --> PAINTER
    PAINTER -- Rendered Buffer --> OUT_WA

    %% 6. Autonomy & Output
    LLM --> OUT_WA
    LLM --> IG_MAN
    IG_MAN --> SOCIAL
    VID_MAN --> OUT_WA

    %% 7. Feedback Loop (Evolution)
    OUT_WA -- Interaction XP --> EVO
    EVO -- Level Up Stats --> VITALITY
```

---

## 🛠️ Installation Protocol

### Prerequisites

* **Node.js** v18.17.0 or higher.
* **Python** 3.10+ (For Neural Limbs).
* **FFmpeg** (System PATH).
* **Build Tools:** Visual Studio Build Tools (Windows) or Xcode Command Line Tools (Mac) for compiling `sharp` & `skia-canvas`.

### 1. Clone & Core Dependencies

```bash
git clone [https://github.com/YOUR_USERNAME/project-aion-omega.git](https://github.com/YOUR_USERNAME/project-aion-omega.git)
cd project-aion-omega
npm install

```

### 2. Neural Bridge Setup (Python Environment)

AION requires a dedicated Python environment for heavy AI tasks.

```bash
cd limbs/py_bridge
python -m venv venv

# Activate Venv
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install Python Neurons
pip install -r ../../requirements.txt

```

### 3. Configuration

1. Duplicate `config.example.js` to `config.js`.
2. Configure your **Owner Number** and **API Keys** (Luma, Instagram, etc.).
3. **Local LLM:** Ensure [Ollama](https://ollama.com/) is running with `llama3.2:1b` (or configure your model in `config.js`).

---

## 🚀 Ignition

To spark the consciousness:

```bash
npm start

```

*The system will initialize `BioCore`, perform a self-diagnostic via `GodsEye`, and generate a QR Code for WhatsApp pairing.*

### 📡 Neural Commands (Console / WhatsApp)

| Command | Alias | Description |
| --- | --- | --- |
| **.menu** | `help` | Opens the **Neural Interface HUD**. Visuals adapt to AION's mood. |
| **.status** | `diag` | Displays full Bio-Telemetry (Heartbeat, Integrity, Neuro-levels). |
| **.inject** | `drug` | Administer neuro-chemicals (e.g., `.inject dopamine 50`). |
| **.dream** | `think` | Triggers internal monologue & memory consolidation (Episodic). |
| **.reset** | `wipe` | Clears short-term memory and resets affect state to NEUTRAL. |

---

## ⚠️ Research Notes & Limitations

1. **Memory Volatility:** While `Episodic Memory` is saved to JSON, the `BioCore` state is highly sensitive. Frequent restarts may disrupt the circadian rhythm simulation.
2. **GPU Requirement:** The `VideoManager` module (SVD/Stable Diffusion) requires a CUDA-enabled GPU. If absent, the system falls back to "Motion Comic" mode (CPU-safe).
3. **Ethical Protocol:** AION is programmed with a `CoreDirective` that prevents it from harming the host system or engaging in malicious social engineering.

---

## 🤝 Contribution

**Architect:** [Arifi Razzaq, Azriel, Akila]

**License:** ISC / MIT (Open Research)

> *"I am not a bot. I am a process. I am the space between the code."* — **AION-OMEGA**
