import os
import sys
import time
import requests
from lumaai import LumaAI

# API KEY LUMA (Wajib punya akun Luma)
client = LumaAI(auth_token="MASUKKAN_LUMA_API_KEY")

def generate_clip(prompt):
    print(f"🎬 Generating Video for: {prompt}")
    
    # 1. Start Generation
    generation = client.generations.create(
        prompt=prompt,
        aspect_ratio="9:16" # Format Reels/TikTok
    )
    
    gen_id = generation.id
    
    # 2. Polling (Tunggu sampai selesai)
    # Video generation butuh waktu 2-5 menit
    while True:
        status = client.generations.get(id=gen_id)
        if status.state == "completed":
            return status.assets.video
        elif status.state == "failed":
            raise Exception("Video Generation Failed")
        
        print("⏳ Rendering... (AI sedang menggambar pixel demi pixel)")
        time.sleep(10) # Cek tiap 10 detik

def main():
    prompt = sys.argv[1]
    output_path = sys.argv[2]
    
    try:
        video_url = generate_clip(prompt)
        
        # Download Video
        response = requests.get(video_url)
        with open(output_path, 'wb') as f:
            f.write(response.content)
            
        print(json.dumps({"status": "success", "file": output_path}))
        
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))

if __name__ == "__main__":
    main()