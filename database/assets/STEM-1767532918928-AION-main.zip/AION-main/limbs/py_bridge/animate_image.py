import sys
import argparse
import time
import requests
from lumaai import LumaAI

# SETUP
parser = argparse.ArgumentParser()
parser.add_argument("--image", required=True)
parser.add_argument("--prompt", required=True)
parser.add_argument("--output", required=True)
args = parser.parse_args()

client = LumaAI(auth_token="API_KEY_KAMU")

def main():
    print(f"🚀 Sending Image to Luma for Animation: {args.prompt}")
    
    # 1. Start Generation with IMAGE REFERENCE (Key Feature)
    # Ini kuncinya: kita kirim URL/File gambar sebagai referensi awal
    # Luma SDK memerlukan URL public untuk gambar, atau upload via SDK (tergantung versi)
    # Disini asumsi kita upload file dulu atau pakai fitur image input SDK terbaru
    
    generation = client.generations.create(
        prompt=args.prompt,
        image_paths=[args.image], # INPUT GAMBAR DI SINI
        aspect_ratio="9:16"
    )
    
    gen_id = generation.id
    
    # 2. Polling Loop
    while True:
        status = client.generations.get(id=gen_id)
        if status.state == "completed":
            video_url = status.assets.video
            # Download
            r = requests.get(video_url)
            with open(args.output, 'wb') as f:
                f.write(r.content)
            print("✅ Animation Complete")
            break
        elif status.state == "failed":
            print("❌ Animation Failed")
            sys.exit(1)
        
        time.sleep(10)

if __name__ == "__main__":
    main()