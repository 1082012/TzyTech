import os
import sys
import json
import argparse
import time
import warnings

# 1. BUNGKAM LOG SAMPAH (Agar JSON bersih)
os.environ["PYTHONWARNINGS"] = "ignore"
warnings.simplefilter("ignore")

try:
    from duckduckgo_search import DDGS
except ImportError:
    try:
        from ddgs import DDGS
    except:
        # Emergency JSON output jika library hilang
        print(json.dumps({"status": "error", "message": "Module 'ddgs' missing"}))
        sys.exit(0)

# SETUP ARGUMEN
parser = argparse.ArgumentParser()
parser.add_argument("--query", required=True)
parser.add_argument("--max", type=int, default=5)
args = parser.parse_args()

def main():
    results = []
    max_retries = 3
    
    # Paksa encoding UTF-8 untuk output terminal
    if sys.stdout.encoding != 'utf-8':
        sys.stdout.reconfigure(encoding='utf-8')

    for attempt in range(max_retries):
        try:
            # Timeout 45 detik
            with DDGS(timeout=45) as ddgs:
                
                # METODE 1: Coba Cari Berita (.news)
                # Gunakan positional argument (args.query) agar aman dari perubahan nama parameter
                try:
                    # Mencoba berbagai kemungkinan nama parameter dengan memberikan argumen posisi pertama
                    ddg_gen = ddgs.news(args.query, max_results=args.max)
                except Exception:
                    ddg_gen = None

                # METODE 2: Fallback ke Teks Biasa (.text) jika berita gagal/kosong
                if not ddg_gen:
                    try:
                        # [FIX DISINI] Langsung masukkan args.query sebagai parameter pertama
                        # Jangan pakai keywords=... agar tidak error 'missing query'
                        ddg_gen = ddgs.text(args.query, max_results=args.max)
                    except Exception as e:
                        # Jika masih gagal, lempar error agar ditangkap loop retry
                        raise e

                # Proses Hasil
                if ddg_gen:
                    for r in ddg_gen:
                        results.append({
                            "title": r.get('title', 'No Title'),
                            "body": r.get('body', r.get('snippet', '')), 
                            "source": r.get('source', 'Internet'),
                            "date": r.get('date', 'Today'),
                            "url": r.get('url', r.get('href', ''))
                        })
            
            # Jika dapat hasil, keluar loop
            if len(results) > 0:
                break
            
        except Exception as e:
            # Jika gagal, tunggu sebentar lalu coba lagi
            if attempt < max_retries - 1:
                time.sleep(2)
                continue
            else:
                # Gagal Total (Return JSON Error, Exit Code 0 agar Node.js tidak crash)
                print(json.dumps({
                    "status": "error", 
                    "message": f"Search Engine Error: {str(e)}"
                }))
                sys.exit(0)

    # OUTPUT FINAL (JSON)
    final_output = {
        "status": "success",
        "data": results
    }
    print(json.dumps(final_output, ensure_ascii=False))

if __name__ == "__main__":
    main()