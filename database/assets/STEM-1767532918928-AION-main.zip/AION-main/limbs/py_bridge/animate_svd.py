import sys
import argparse
import torch
import os
from diffusers import StableVideoDiffusionPipeline
from diffusers.utils import load_image, export_to_video
from PIL import Image

# SETUP ARGUMENTS
parser = argparse.ArgumentParser()
parser.add_argument("--image", required=True, help="Path to input image")
parser.add_argument("--output", required=True, help="Path to output mp4")
parser.add_argument("--seed", type=int, default=42, help="Random seed")
args = parser.parse_args()

def main():
    print(f"🚀 [SVD] Initializing Stable Video Diffusion XT...")
    print(f"    Input: {args.image}")

    try:
        # 1. LOAD MODEL PIPELINE
        # Kita pakai variant fp16 agar hemat VRAM (tetap butuh GPU bagus)
        pipe = StableVideoDiffusionPipeline.from_pretrained(
            "stabilityai/stable-video-diffusion-img2vid-xt", 
            torch_dtype=torch.float16, 
            variant="fp16"
        )
        
        # 2. GPU OPTIMIZATION (PENTING)
        # enable_model_cpu_offload() memindahkan layer yg tidak dipakai ke RAM
        # Ini penyelamat jika VRAM pas-pasan.
        pipe.enable_model_cpu_offload() 
        
        # Opsi tambahan jika VRAM < 10GB (Uncomment jika crash)
        # pipe.enable_vae_slicing()

        # 3. PREPARE IMAGE
        # SVD butuh resolusi spesifik (1024x576 adalah standar SVD-XT)
        image = load_image(args.image)
        image = image.resize((1024, 576))

        # 4. GENERATE FRAMES
        print("⚡ [SVD] Dreaming pixels (Rendering)... This may take time.")
        
        generator = torch.manual_seed(args.seed)
        
        frames = pipe(
            image, 
            decode_chunk_size=8,
            generator=generator,
            motion_bucket_id=127,  # 127 = gerakan standar, makin tinggi makin liar
            noise_aug_strength=0.1 # Semakin tinggi semakin sedikit mirip gambar asli
        ).frames[0]

        # 5. EXPORT TO MP4
        print(f"💾 [SVD] Saving to {args.output}...")
        export_to_video(frames, args.output, fps=7)
        
        print("✅ [SVD] Animation Complete.")

    except Exception as e:
        print(f"❌ [SVD ERROR] {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()