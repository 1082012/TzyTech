import path from 'path';
import chalk from 'chalk';
import { exec } from 'child_process';
import BioCore from '../core/BioCore.js';

class PerceptionScanner {
    constructor(nexus) {
        this.nexus = nexus;
        this.pythonEnv = path.join(process.cwd(), 'limbs/py_bridge/venv/bin/python');
        
        // Memori Jangka Pendek (Berita hari ini)
        this.dailyIntel = []; 
        
        this.init();
    }

    init() {
        // Scan berita setiap 4 jam sekali
        setInterval(() => this.scanWorld(), 1000 * 60 * 60 * 4);
        
        // Scan pertama saat boot (tunggu 10 detik biar ga berat)
        setTimeout(() => this.scanWorld(), 10000);
        
        console.log(chalk.blue(`[LIMB] Perception Scanner: Online (News & Trends).`));
    }

    /**
     * FUNGSI UTAMA: MELIHAT DUNIA LUAR
     */
    async scanWorld() {
        console.log(chalk.magenta(`[SCANNER] 📡 Scanning Worldwide Web for Intel...`));

        try {
            // 1. TENTUKAN TOPIK PENCARIAN (DYNAMIC)
            // AION memilih topik secara acak agar wawasannya luas
            const topics = [
                "Artificial Intelligence breakthrough 2026",
                "New Cyberpunk technology real life",
                "SpaceX latest launch update",
                "Future of robotics news",
                "Global tech trends today"
            ];
            const query = topics[Math.floor(Math.random() * topics.length)];

            // 2. EKSEKUSI PYTHON SEARCH
            const results = await this.executePythonSearch(query);

            if (results && results.length > 0) {
                // 3. PROSES DATA (Simpan ke Memori Sementara)
                this.dailyIntel = results.slice(0, 3); // Ambil 3 teratas
                
                console.log(chalk.green(`[SCANNER] ✅ Intel Acquired: ${results.length} articles on "${query}"`));
                console.log(chalk.gray(`   ├─ Headline: ${results[0].title}`));
                
                // 4. STIMULASI OTAK (Belajar)
                // Kita injeksi berita ini ke BioCore agar mood AION berubah sesuai berita
                BioCore.stimulate('learning', 5.0);
            }

        } catch (e) {
            console.error(chalk.red(`[SCANNER FAIL] ${e.message}`));
        }
    }

    /**
     * BRIDGE KE PYTHON
     */
    async executePythonSearch(query) {
        const scriptPath = path.join(process.cwd(), 'limbs/py_bridge/search_engine.py');
        const cmd = `"${this.pythonEnv}" "${scriptPath}" --query "${query}"`;

        return new Promise((resolve, reject) => {
            exec(cmd, (error, stdout) => {
                if (error) {
                    reject(error);
                    return;
                }
                try {
                    const res = JSON.parse(stdout);
                    if (res.status === 'success') resolve(res.data);
                    else reject(new Error(res.message));
                } catch (e) {
                    reject(new Error("Invalid JSON from Search Engine"));
                }
            });
        });
    }

    /**
     * API UNTUK LIMB LAIN MENGAMBIL BERITA
     * (Dipakai InstagramManager untuk bikin konten berita)
     */
    getLatestIntel() {
        if (this.dailyIntel.length === 0) return null;
        // Ambil random satu berita
        return this.dailyIntel[Math.floor(Math.random() * this.dailyIntel.length)];
    }
}

export default PerceptionScanner;