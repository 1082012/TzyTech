import sys
import argparse
import json
import os
import time
from instagrapi import Client
from instagrapi.exceptions import LoginRequired

# ==========================================
# SETUP ARGUMEN DARI NODE.JS
# ==========================================
parser = argparse.ArgumentParser()
parser.add_argument("--username", required=True)
parser.add_argument("--password", required=True)
parser.add_argument("--caption", required=True)
parser.add_argument("--image", required=False, help="Path to image file (.jpg/.png)")
parser.add_argument("--video", required=False, help="Path to video file (.mp4)")

args = parser.parse_args()

# File untuk menyimpan Cookies/Session agar tidak login terus menerus
SESSION_FILE = os.path.join(os.path.dirname(__file__), "session.json")

def main():
    cl = Client()
    
    # ---------------------------------------------------------
    # 1. PROSES LOGIN (SESSION HANDLING)
    # ---------------------------------------------------------
    session_loaded = False
    
    # A. Coba Load Session Lama
    if os.path.exists(SESSION_FILE):
        try:
            cl.load_settings(SESSION_FILE)
            cl.login(args.username, args.password)
            session_loaded = True
        except Exception as e:
            # Jika session kadaluarsa/rusak, abaikan dan login ulang
            pass

    # B. Login Baru (Jika session lama gagal/tidak ada)
    if not session_loaded:
        try:
            cl.login(args.username, args.password)
            cl.dump_settings(SESSION_FILE) # Simpan session baru
        except Exception as e:
            # Fatal Error: Login Gagal (Password salah / Kena Challenge)
            print(json.dumps({
                "status": "error", 
                "message": f"Login Failed: {str(e)}"
            }))
            sys.exit(1)

    # ---------------------------------------------------------
    # 2. PROSES UPLOAD (HYBRID: FOTO / VIDEO)
    # ---------------------------------------------------------
    try:
        media = None
        
        # JALUR A: UPLOAD VIDEO
        if args.video:
            if not os.path.exists(args.video):
                raise Exception(f"Video file not found: {args.video}")
            
            # Upload Video (Reels/Feed)
            media = cl.video_upload(
                path=args.video,
                caption=args.caption
            )

        # JALUR B: UPLOAD FOTO
        elif args.image:
            if not os.path.exists(args.image):
                raise Exception(f"Image file not found: {args.image}")
            
            # Upload Foto
            media = cl.photo_upload(
                path=args.image,
                caption=args.caption
            )
            
        else:
            raise Exception("No media provided! Use --image or --video.")

        # ---------------------------------------------------------
        # 3. OUTPUT SUKSES
        # ---------------------------------------------------------
        # Kembalikan data JSON ke Node.js
        result = {
            "status": "success",
            "pk": media.pk,
            "code": media.code,
            "url": f"https://instagram.com/p/{media.code}",
            "media_type": "video" if args.video else "image"
        }
        print(json.dumps(result))

    except Exception as e:
        # ---------------------------------------------------------
        # 4. OUTPUT ERROR
        # ---------------------------------------------------------
        print(json.dumps({
            "status": "error", 
            "message": str(e)
        }))
        sys.exit(1)

if __name__ == "__main__":
    main()