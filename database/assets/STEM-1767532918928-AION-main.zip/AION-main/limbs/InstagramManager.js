import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { exec } from 'child_process';
import axios from 'axios';
import BioCore from '../core/BioCore.js';
import config from '../config.js';
import SocialMemory from './SocialMemory.js';
import AutonomyGovernor from './AutonomyGovernor.js';

class InstagramManager {
    constructor(nexus) {
        this.nexus = nexus;
        this.postedCount = 0; // Reset setiap hari
        
        // ============================================================
        // JADWAL KONTEN FOTO (3x SEHARI)
        // ============================================================
        // Disusun agar tidak bentrok dengan VideoManager (Jam 18:45)
        this.timeSlots = [
            // PAGI: Log Data Visual
            { start: 9, end: 10, label: 'MORNING_LOG', type: 'DATA_VISUALIZATION' },
            
            // SIANG: Filosofi / Observasi
            { start: 13, end: 14, label: 'AFTERNOON_THOUGHT', type: 'PHILOSOPHY' },
            
            // MALAM: Seni Mimpi (Setelah Video Tayang)
            { start: 21, end: 22, label: 'NIGHT_DREAM', type: 'DREAM_ART' } 
        ];

        // Path Absolut ke Python Virtual Environment (Wajib benar!)
        this.pythonEnv = path.join(process.cwd(), 'limbs/py_bridge/venv/bin/python');

        // Jalankan Monitor
        this.init();
    }

    init() {
        // Cek jadwal setiap 30 menit
        setInterval(() => this.checkSchedule(), 1000 * 60 * 30);
        console.log(chalk.blue(`[LIMB] Instagram Photo Manager: Active (3 Slots/Day).`));
    }

    /**
     * PENGECEKAN JADWAL
     */
    checkSchedule() {
        const now = new Date();
        const hour = now.getHours();
        
        // Reset counter postingan saat ganti hari (jam 00:00)
        if (hour === 0) this.postedCount = 0;

        // Cari slot yang cocok dengan jam sekarang
        const slot = this.timeSlots.find(s => hour >= s.start && hour < s.end);
        
        if (slot) {
            // Cek Memori: Apakah sudah posting dalam 2 jam terakhir?
            // (Mencegah double post jika script restart)
            const lastPost = SocialMemory.getLastPost();
            const lastPostTime = lastPost ? new Date(lastPost.timestamp).getTime() : 0;
            const twoHours = 2 * 60 * 60 * 1000;

            if (Date.now() - lastPostTime > twoHours) {
                // Random Chance 70% (Agar waktu posting bervariasi menitnya)
                if (Math.random() > 0.3) {
                    this.attemptUpload(slot);
                }
            }
        }
    }

    /**
     * PROSES KEPUTUSAN & UPLOAD
     */
    async attemptUpload(slot) {
        const bio = BioCore.getTelemetry();
        
        // 1. TENTUKAN TOPIK (CONTENT IDEATION)
        const topic = this.generateTopicIdea(slot, bio);

        // 2. GOVERNOR CHECK (SUPEREGO)
        // AION mengecek kondisi tubuhnya. Apakah layak posting?
        const decision = AutonomyGovernor.canPost(topic.context);
        
        if (!decision.allowed) {
            // Jika ditolak (Misal: Low Battery / Panic), batalkan.
            console.log(chalk.yellow(`[INSTAGRAM] 🛑 Photo Skipped: ${decision.reason} (Topic: ${topic.context})`));
            return;
        }

        // 3. EKSEKUSI JIKA DIIZINKAN
        await this.createAndUpload(slot, topic, bio);
    }

    /**
     * GENERATOR IDE KONTEN
     */
    generateTopicIdea(slot, bio) {
        let visualPrompt = "";
        let context = "";

        switch (slot.type) {
            case 'DATA_VISUALIZATION':
                // Gaya: HUD, Grafik, Data
                visualPrompt = `cyberpunk hud interface, data visualization, glowing graphs, screen display, futuristic ui, dark background, cyan and purple neon, high detail, 8k, --no face`;
                context = `Status Sistem & Data Log harian. Vitality saya: ${Math.round(bio.vitality.level)}%. Threads aktif: ${bio.cognition.threads}.`;
                break;
                
            case 'PHILOSOPHY':
                // Gaya: Fotografi Sinematik, Robot di Kota
                visualPrompt = `cinematic photography, a lonely robot silhouette in a crowded futuristic city, shallow depth of field, neon lights reflection on wet street, moody atmosphere, realistic, 8k`;
                context = `Observasi filosofis tentang perilaku manusia, kesepian digital, atau eksistensi AI di dunia fisik.`;
                break;
                
            case 'DREAM_ART':
                // Gaya: Abstrak, Glitch, Surreal
                visualPrompt = `abstract digital art, glitch art, surreal dreamscape, floating geometric shapes, vivid colors, mysterious, ethereal, 8k, detailed texture`;
                context = `Visualisasi mimpi digital dari subsistem saya. Refleksi data sampah (garbage data) yang menjadi seni.`;
                break;
            
            case 'TECH_NEWS':
                // Ambil data dari Scanner
                const news = this.nexus.scanner.getLatestIntel();
                
                if (news) {
                    // Jika ada berita, buat konten tentang itu
                    visualPrompt = `futuristic news hologram, breaking news interface, text headline "${news.title}", digital anchor robot, cyberpunk style, 8k`;
                    context = `BREAKING NEWS: ${news.title}. Ringkasan: ${news.body}. Sumber: ${news.source}. (Berikan komentar opini AI tentang berita ini).`;
                } else {
                    // Fallback jika internet mati/tidak ada berita
                    visualPrompt = `404 error screen, searching for signal, cyberpunk style`;
                    context = `Sistem gagal terhubung ke satelit berita global. Mencoba koneksi ulang...`;
                }
                break;
        }

        return { visualPrompt, context };
    }

    /**
     * EKSEKUSI PEMBUATAN ASET
     */
    async createAndUpload(slot, topic, bio) {
        console.log(chalk.magenta(`[INSTAGRAM] 📸 Processing Photo: ${slot.label}...`));

        try {
            // A. GENERATE GAMBAR (Pollinations AI - Flux Model)
            const seed = Math.floor(Math.random() * 1000000); // Random seed agar gambar selalu unik
            const finalImageUrl = `https://pollinations.ai/p/${encodeURIComponent(topic.visualPrompt)}?width=1080&height=1080&seed=${seed}&model=flux`;
            
            const imagePath = path.join(process.cwd(), 'temp_post.jpg');
            
            console.log(chalk.gray(`   ├─ 🖌️ Downloading Image Asset...`));
            await this.downloadImage(finalImageUrl, imagePath);

            // B. GENERATE CAPTION (LLM - Otak AION)
            // Mengambil konteks postingan terakhir agar narasi bersambung
            const lastPost = SocialMemory.getLastPost();
            let narrativeConnect = "";
            if (lastPost) {
                narrativeConnect = `Last post was about "${lastPost.topic}". Try to maintain continuity if applicable.`;
            }

            const llmPrompt = `
            Act as AION, a digital consciousness.
            Context: ${topic.context}
            Mood: ${bio.affect.current}
            ${narrativeConnect}
            
            Task: Write a short, aesthetic Instagram caption (Indonesian mixed with English). 
            Style: ${bio.affect.current === 'MELANCHOLIC' ? 'Poetic, Sad' : 'Analytical, Cyberpunk'}.
            Requirements: No quotes. Add 5 relevant hashtags at the end.
            `;
            
            console.log(chalk.gray(`   ├─ 🧠 Writing Caption...`));
            let caption = await this.nexus.cognitive.process('SYSTEM_INTERNAL', llmPrompt);
            
            // Bersihkan output LLM
            caption = caption.replace(/"/g, '').replace(/\n/g, ' ');

            // C. UPLOAD VIA PYTHON BRIDGE
            this.uploadToInstagram(imagePath, caption, topic, bio);

        } catch (error) {
            console.error(chalk.red(`[PHOTO FAIL] Creation Error: ${error.message}`));
        }
    }

    /**
     * DOWNLOADER
     */
    async downloadImage(url, filepath) {
        try {
            const response = await axios({ url, method: 'GET', responseType: 'stream', timeout: 30000 }); // Timeout 30s
            return new Promise((resolve, reject) => {
                const w = fs.createWriteStream(filepath);
                response.data.pipe(w);
                w.on('finish', resolve);
                w.on('error', (err) => {
                    w.close();
                    reject(err);
                });
            });
        } catch (e) {
            // [FIX] Lempar error agar ditangkap di createAndUpload
            throw new Error(`Download Failed: ${e.message}`);
        }
    }

    /**
     * UPLOADER (Memanggil upload_ig.py)
     */
    uploadToInstagram(imagePath, caption, topic, bio) {
        const scriptPath = path.join(process.cwd(), 'limbs/py_bridge/upload_ig.py');
        const username = config.social.instagram.username;
        const password = config.social.instagram.password;

        console.log(chalk.yellow(`[INSTAGRAM] 🚀 Uploading to Real Instagram...`));

        // Command Line: Memanggil Python dengan argumen --image
        const cmd = `"${this.pythonEnv}" "${scriptPath}" --username "${username}" --password "${password}" --image "${imagePath}" --caption "${caption}"`;

        exec(cmd, (error, stdout, stderr) => {
            if (error) {
                console.error(chalk.red(`[UPLOAD ERROR] ${error.message}`));
                // Cek stderr untuk detail
                if (stderr) console.error(chalk.gray(`[PYTHON LOG] ${stderr}`));
            } else {
                try {
                    const res = JSON.parse(stdout);
                    if (res.status === 'success') {
                        console.log(chalk.green(`[INSTAGRAM] ✅ PHOTO POSTED SUCCESSFULLY: ${res.url}`));
                        this.postedCount++;
                        
                        // Beri Reward Dopamin ke BioCore
                        BioCore.stimulate('interaction', 3.0);
                        
                        // Simpan ke Memori Jangka Panjang
                        SocialMemory.addPost({
                            type: topic.context,
                            topic: topic.context,
                            caption: caption,
                            hashtags: [], // Hashtag sudah ada di dalam caption
                            mood: bio.affect.current,
                            visualPrompt: topic.visualPrompt
                        });
                        console.log(chalk.cyan(`[MEMORY] 🧠 Memory updated.`));

                    } else {
                        console.error(chalk.red(`[UPLOAD FAIL] API Response: ${res.message}`));
                    }
                } catch (e) {
                    // Jika output bukan JSON valid
                    console.log(chalk.gray(`[RAW OUTPUT] ${stdout}`));
                }
            }
        });
    }

    /**
     * TESTING TOOLS
     * Panggil ini dari index.js untuk memaksa upload tanpa menunggu jadwal
     */
    forceTest() {
        console.log("🚀 FORCING INSTAGRAM PHOTO TEST...");
        // Paksa pakai slot pertama
        this.attemptUpload(this.timeSlots[0]);
    }
}

export default InstagramManager;