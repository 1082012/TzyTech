import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'database', 'social', 'instagram_memory.json');

class SocialMemory {
    constructor() {
        this.memory = [];
        this.load();
    }

    load() {
        if (fs.existsSync(DB_PATH)) {
            try {
                this.memory = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
            } catch (e) { this.memory = []; }
        } else {
            // Pastikan folder ada
            const dir = path.dirname(DB_PATH);
            if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
            this.save();
        }
    }

    save() {
        fs.writeFileSync(DB_PATH, JSON.stringify(this.memory, null, 2));
    }

    /**
     * MENCATAT POSTINGAN BARU
     */
    addPost(postData) {
        const entry = {
            id: Date.now().toString(36),
            timestamp: new Date().toISOString(),
            type: postData.type,     // DREAM_ART, PHILOSOPHY
            topic: postData.topic,   // "Digital Loneliness"
            caption: postData.caption,
            hashtags: postData.hashtags,
            mood: postData.mood,     // Mood saat upload
            image_prompt: postData.visualPrompt
        };
        this.memory.push(entry);
        this.save();
    }

    /**
     * MENGECEK APAKAH TOPIK SUDAH PERNAH DIBAHAS BARU-BARU INI
     * (Agar tidak repetitif)
     */
    isRedundant(topic, hours = 24) {
        const cutoff = Date.now() - (hours * 60 * 60 * 1000);
        return this.memory.some(m => 
            new Date(m.timestamp).getTime() > cutoff && 
            m.topic.toLowerCase().includes(topic.toLowerCase())
        );
    }

    /**
     * MENDAPATKAN KONTEKS TERAKHIR (Untuk Narrative Arc)
     */
    getLastPost() {
        if (this.memory.length === 0) return null;
        return this.memory[this.memory.length - 1];
    }
}

export default new SocialMemory();