import path from 'path';
import chalk from 'chalk';
import { exec } from 'child_process';
import BioCore from '../core/BioCore.js';

class PerceptionScanner {
    constructor(nexus) {
        this.nexus = nexus;
        
        // Path Absolut ke Python Virtual Environment
        // Pastikan path ini sesuai dengan struktur folder Anda
        this.pythonEnv = path.join(process.cwd(), 'limbs/py_bridge/venv/bin/python');
        
        // Memori Jangka Pendek (Menyimpan berita hari ini untuk konten IG)
        this.dailyIntel = []; 
        
        this.init();
    }

    init() {
        // 1. SCAN OTOMATIS BERKALA
        // AION akan mencari berita setiap 4 jam sekali untuk update wawasan
        setInterval(() => this.scanWorld(), 1000 * 60 * 60 * 4);
        
        // Scan pertama saat boot (tunggu 10 detik agar sistem stabil dulu)
        setTimeout(() => this.scanWorld(), 10000);
        
        console.log(chalk.blue(`[LIMB] Perception Scanner: Online (News & Trends).`));
    }

    /**
     * FUNGSI UTAMA: MELIHAT DUNIA LUAR (AUTONOMOUS)
     * Digunakan untuk mencari ide konten Instagram atau sekadar belajar.
     */
    async scanWorld() {
        console.log(chalk.magenta(`[SCANNER] 📡 Scanning Worldwide Web for Intel...`));

        try {
            // 1. TENTUKAN TOPIK PENCARIAN (DYNAMIC)
            // AION memilih topik secara acak agar wawasannya luas
            const topics = [
                "Artificial Intelligence breakthrough 2026",
                "New Cyberpunk technology real life",
                "SpaceX latest launch update",
                "Future of robotics news",
                "Global tech trends today",
                "Latest scientific discovery 2025"
            ];
            const query = topics[Math.floor(Math.random() * topics.length)];

            // 2. EKSEKUSI PYTHON SEARCH
            const results = await this.executePythonSearch(query);

            if (results && results.length > 0) {
                // 3. PROSES DATA (Simpan ke Memori Sementara)
                this.dailyIntel = results.slice(0, 3); // Ambil 3 artikel teratas
                
                console.log(chalk.green(`[SCANNER] ✅ Intel Acquired: ${results.length} articles on "${query}"`));
                console.log(chalk.gray(`   ├─ Headline: ${results[0].title}`));
                
                // 4. STIMULASI OTAK (Belajar)
                // Kita injeksi berita ini ke BioCore agar mood AION berubah (Merasa pintar/excited)
                BioCore.stimulate('learning', 5.0);
            }

        } catch (e) {
            console.error(chalk.red(`[SCANNER FAIL] ${e.message}`));
        }
    }

    /**
     * PUBLIC API: PENCARIAN ON-DEMAND (RAG)
     * Dipanggil oleh CognitiveCortex saat user bertanya hal terkini (misal: Harga Saham, Cuaca).
     */
    async searchOnDemand(query) {
        // Bersihkan query agar aman dari karakter aneh
        const cleanQuery = query.replace(/["']/g, "");
        console.log(chalk.magenta(`[AGI AGENT] 🔎 Searching Realtime Data: "${cleanQuery}"...`));
        
        try {
            const results = await this.executePythonSearch(cleanQuery);
            
            if (!results || results.length === 0) {
                return "Tidak ada data relevan ditemukan di internet.";
            }
            
            // Format hasil menjadi teks ringkas yang bisa dibaca LLM
            // Format: [Tanggal] Judul: Ringkasan (Sumber)
            const summary = results.slice(0, 3).map(r => 
                `- [${r.date || 'Today'}] ${r.title}: ${r.body} (Source: ${r.source})`
            ).join("\n");
            
            return summary;

        } catch (e) {
            console.error(chalk.red(`[SEARCH ERROR] ${e.message}`));
            return "Gagal mengakses internet. Terjadi kesalahan pada modul scanner.";
        }
    }

    /**
     * BRIDGE KE PYTHON (REVISI ANTI-CRASH)
     */
    async executePythonSearch(query) {
        const scriptPath = path.join(process.cwd(), 'limbs/py_bridge/search_engine.py');
        const cmd = `"${this.pythonEnv}" "${scriptPath}" --query "${query}"`;

        return new Promise((resolve, reject) => {
            exec(cmd, (error, stdout, stderr) => {
                // Walaupun error (exit code 1), kita coba baca stdout dulu
                // Siapa tahu Python sempat print JSON error
                
                try {
                    // Bersihkan stdout dari log sampah (warnings) yang mungkin lolos
                    const jsonString = stdout.trim().split('\n').pop(); // Ambil baris terakhir
                    const res = JSON.parse(jsonString);
                    
                    if (res.status === 'success') {
                        resolve(res.data);
                    } else {
                        // Jika status error dari Python, log tapi jangan crashkan AION
                        console.log(chalk.yellow(`[SCANNER WARNING] ${res.message}`));
                        resolve([]); // Return array kosong agar sistem tetap jalan
                    }
                } catch (e) {
                    // Jika benar-benar parah (bukan JSON)
                    if (error) {
                        console.error(chalk.red(`[SCANNER FATAL] ${stderr || error.message}`));
                    }
                    resolve([]); // Tetap resolve kosong (Fail Safe)
                }
            });
        });
    }

    /**
     * API UNTUK LIMB LAIN (InstagramManager)
     * Mengambil berita yang sudah di-cache agar tidak perlu searching ulang saat mau posting IG.
     */
    getLatestIntel() {
        if (this.dailyIntel.length === 0) return null;
        // Ambil random satu berita dari cache hari ini
        return this.dailyIntel[Math.floor(Math.random() * this.dailyIntel.length)];
    }
}

export default PerceptionScanner;