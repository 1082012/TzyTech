import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'database', 'social', 'video_memory.json');

class VideoMemory {
    constructor() {
        this.memory = [];
        this.load();
    }

    load() {
        try { this.memory = JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); } 
        catch (e) { this.memory = []; }
    }

    save() { fs.writeFileSync(DB_PATH, JSON.stringify(this.memory, null, 2)); }

    getLastEpisode() {
        return this.memory[this.memory.length - 1] || { episode: 0, plot: "AION baru saja terbangun.", cliffhanger: "Apa yang ada di luar sana?" };
    }

    addEpisode(data) {
        // data: { episode: 1, title: "...", plot: "...", cliffhanger: "..." }
        this.memory.push(data);
        this.save();
    }
}
export default new VideoMemory();