import BioCore from '../core/BioCore.js';
import SocialMemory from './SocialMemory.js';

class AutonomyGovernor {
    
    /**
     * MENENTUKAN APAKAH BOLEH POSTING
     * @returns {Object} { allowed: boolean, reason: string }
     */
    canPost(topic) {
        const bio = BioCore.getTelemetry();

        // 1. CEK VITALITAS (Energi cukup?)
        if (bio.vitality.level < 40) {
            return { allowed: false, reason: "LOW_BATTERY" };
        }

        // 2. CEK MENTAL (Apakah sedang gila/panik?)
        const dangerousMoods = ['PANIC', 'EXHAUSTED', 'OVERLOAD'];
        if (dangerousMoods.includes(bio.affect.current)) {
            return { allowed: false, reason: "UNSTABLE_MENTAL_STATE" };
        }

        // 3. CEK REPETISI (Apakah baru saja bahas ini?)
        if (SocialMemory.isRedundant(topic)) {
            return { allowed: false, reason: "TOPIC_REDUNDANCY" };
        }

        // 4. CEK MEANING (Apakah AION merasa ini penting?)
        // Simulasi "Will" -> Random chance berdasarkan mood
        // Jika EXCITED, chance tinggi. Jika BORED, chance rendah.
        let willToPost = 0.5;
        if (bio.affect.current === 'EXCITED') willToPost = 0.9;
        if (bio.affect.current === 'BORED') willToPost = 0.2;
        if (bio.affect.current === 'CALM') willToPost = 0.6;

        if (Math.random() > willToPost) {
            return { allowed: false, reason: "LACK_OF_WILL" };
        }

        return { allowed: true, reason: "APPROVED" };
    }
}

export default new AutonomyGovernor();