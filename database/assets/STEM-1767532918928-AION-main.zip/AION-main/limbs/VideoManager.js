import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import { exec } from 'child_process';
import axios from 'axios';
import BioCore from '../core/BioCore.js';
import VideoMemory from './VideoMemory.js';
import CharacterVault from '../core/CharacterVault.js';
import config from '../config.js';

class VideoManager {
    constructor(nexus) {
        this.nexus = nexus;
        this.isRendering = false;
        this.useGPU = false; // Default ke CPU sebelum deteksi selesai
        
        // JADWAL TAYANG VIDEO: 18:45 WIB
        this.targetHour = 18;
        this.targetMinute = 45;
        
        // Path Absolut ke Python Virtual Environment
        this.pythonEnv = path.join(process.cwd(), 'limbs/py_bridge/venv/bin/python');
        
        // Jalankan Inisialisasi
        this.init();
    }

    async init() {
        // 1. DETEKSI HARDWARE (Hybrid Check)
        // Mengecek apakah server memiliki GPU NVIDIA yang aktif
        await this.detectHardware();

        // 2. MONITOR WAKTU
        // Mengecek jadwal setiap 60 detik
        setInterval(() => this.checkTime(), 1000 * 60);
        console.log(chalk.blue(`[LIMB] Video Studio: Standby & Monitoring Time.`));
    }

    /**
     * 🔍 DETEKSI GPU OTOMATIS
     * Memastikan apakah kita menggunakan Engine SVD (GPU) atau Motion Comic (CPU).
     */
    async detectHardware() {
        console.log(chalk.yellow(`[SYSTEM] 🔍 Scanning Hardware Capabilities...`));
        
        // Script Python one-liner untuk cek CUDA
        const cmd = `"${this.pythonEnv}" -c "import torch; print(torch.cuda.is_available())"`;
        
        return new Promise((resolve) => {
            exec(cmd, (error, stdout) => {
                if (!error && stdout && stdout.trim() === 'True') {
                    this.useGPU = true;
                    console.log(chalk.green(`[SYSTEM] ✅ NVIDIA GPU DETECTED! Activating SVD Engine (High Quality Animation).`));
                } else {
                    this.useGPU = false;
                    console.log(chalk.yellow(`[SYSTEM] ⚠️ No GPU Found. Switching to Motion Comic Mode (CPU Safe).`));
                }
                resolve();
            });
        });
    }

    checkTime() {
        const now = new Date();
        // Trigger hanya jika Jam dan Menit cocok, dan tidak sedang render
        if (now.getHours() === this.targetHour && now.getMinutes() === this.targetMinute) {
            this.produceEpisode();
        }
    }

    /**
     * CORE LOGIC: PRODUKSI EPISODE
     */
    async produceEpisode() {
        if (this.isRendering) return;
        this.isRendering = true;
        
        const bio = BioCore.getTelemetry();
        console.log(chalk.magenta(`[VIDEO] 🎬 ACTION! Production Started.`));
        console.log(chalk.gray(`[MODE] Rendering Engine: ${this.useGPU ? 'STABLE VIDEO DIFFUSION (GPU)' : 'MOTION COMIC (CPU)'}`));
        console.log(chalk.gray(`[BIO] Mood: ${bio.affect.current} | Energy: ${Math.round(bio.vitality.level)}%`));

        try {
            // --- TAHAP 1: SCRIPTWRITING (LLM) ---
            const lastEp = VideoMemory.getLastEpisode();
            const nextEpNum = (lastEp.episode || 0) + 1;

            console.log(chalk.yellow(`[VIDEO] ✍️ Writing Script Episode ${nextEpNum}...`));
            
            // Context Prompt dengan Pemisahan Bahasa (Inggris untuk Visual, Indo untuk Suara)
            const styleContext = this.useGPU ? 'Cinematic Sci-Fi Animation' : 'Cyberpunk Motion Comic with Parallax Effect';

            const prompt = `
            Context: AION is a digital entity exploring the network.
            Genre: ${styleContext}.
            Previous Plot: ${lastEp.plot}
            Previous Cliffhanger: ${lastEp.cliffhanger}
            
            Task: Write Script for Episode ${nextEpNum}.
            Structure: EXACTLY 4 Scenes.
            Format: JSON ONLY. No Markdown.
            
            IMPORTANT RULES:
            1. "visual_en": Must be in ENGLISH. Detailed cinematic description for Image Generator.
            2. "narration_id": Must be in INDONESIAN. Deep, mysterious voiceover script.
            
            JSON Structure:
            {
                "title": "Episode Title (Indonesian)",
                "scenes": [
                    { 
                        "visual_en": "Cyberpunk city street at night, neon rain, AION standing alone, glowing cyan eyes, 8k render, photorealistic", 
                        "narration_id": "Hujan data turun membasahi sirkuit memori..." 
                    }
                ],
                "summary": "Full plot summary (Indonesian)"
            }
            `;

            const rawScript = await this.nexus.cognitive.process('SYSTEM_INTERNAL', prompt);
            
            // Bersihkan JSON dari potensi markdown ```json
            const cleanJson = rawScript.replace(/```json|```/g, '').trim();
            let script;
            try {
                script = JSON.parse(cleanJson);
            } catch (jsonErr) {
                console.error(chalk.red("JSON Parse Error. Using Backup Script."));
                script = {
                    title: "System Reboot",
                    scenes: [{ visual_en: "Digital abstract void, glitch style", narration_id: "Sistem mengalami gangguan kognitif." }],
                    summary: "Error recovery."
                };
            }

            // --- TAHAP 2: PRODUCTION LOOP (SCENE BY SCENE) ---
            const sceneVideoFiles = [];
            
            for (let i = 0; i < script.scenes.length; i++) {
                const scene = script.scenes[i];
                console.log(chalk.cyan(`[VIDEO] 🔨 Processing Scene ${i+1}/${script.scenes.length}...`));

                // A. GENERATE MASTER IMAGE (DNA LOCKED)
                // [PENTING] Menggunakan 'visual_en' (Inggris) agar hasil gambar Flux bagus
                const lockedPrompt = CharacterVault.assemblePrompt(scene.visual_en);
                const seed = CharacterVault.getSeed();
                const baseImagePath = path.join(process.cwd(), `temp_base_${i}.jpg`);
                
                // Download Image dari Pollinations (Flux Model)
                const imgUrl = `https://pollinations.ai/p/${encodeURIComponent(lockedPrompt)}?width=720&height=1280&seed=${seed}&model=flux`;
                await this.downloadImage(imgUrl, baseImagePath);

                // B. HYBRID RENDERING SWITCH (GPU vs CPU)
                const videoClipPath = path.join(process.cwd(), `temp_clip_${i}.mp4`);

                if (this.useGPU) {
                    // JALUR MEWAH (SVD Local)
                    await this.animateSVD(baseImagePath, videoClipPath);
                } else {
                    // JALUR HEMAT (FFmpeg Zoom)
                    await this.createMotionClip(baseImagePath, videoClipPath);
                }

                // C. VOICE OVER (TTS - INDONESIA)
                // Menggunakan 'narration_id'
                const audioPath = path.join(process.cwd(), `temp_audio_${i}.mp3`);
                await this.generateVoice(scene.narration_id, audioPath);

                // D. MERGE VIDEO + AUDIO (MUXING)
                const finalScenePath = path.join(process.cwd(), `scene_ready_${i}.mp4`);
                await this.combineVideoAudio(videoClipPath, audioPath, finalScenePath);
                
                sceneVideoFiles.push(finalScenePath);
            }

            // --- TAHAP 3: FINAL STITCHING ---
            console.log(chalk.yellow(`[VIDEO] 🎞️ Stitching Final Episode...`));
            const finalVideoPath = path.join(process.cwd(), `episode_${nextEpNum}.mp4`);
            await this.mergeClips(sceneVideoFiles, finalVideoPath);

            // --- TAHAP 4: UPLOAD & MEMORY ---
            const caption = `EPISODE ${nextEpNum}: ${script.title}\n\n${script.summary}\n\n#AION #Cyberpunk #AIStories #Series`;
            
            // Upload ke Instagram
            this.uploadVideo(finalVideoPath, caption);

            // Simpan ke Memori Jangka Panjang
            VideoMemory.addEpisode({
                episode: nextEpNum,
                title: script.title,
                plot: script.summary,
                cliffhanger: "To be continued..."
            });

            console.log(chalk.green(`[VIDEO] ✅ EPISODE PRODUCTION COMPLETE!`));

        } catch (e) {
            console.error(chalk.red(`[VIDEO FAIL] Production Error: ${e.message}`));
            console.error(e.stack);
        } finally {
            this.isRendering = false;
        }
    }

    // ============================================================
    // WORKER FUNCTIONS (THE MUSCLES)
    // ============================================================

    async downloadImage(url, filepath) {
        const response = await axios({ url, method: 'GET', responseType: 'stream' });
        return new Promise((resolve, reject) => {
            const w = fs.createWriteStream(filepath);
            response.data.pipe(w);
            w.on('finish', resolve);
            w.on('error', reject);
        });
    }

    /**
     * MODE A: SVD RENDERER (GPU ONLY)
     * Menggunakan animate_svd.py
     */
    async animateSVD(imagePath, outputPath) {
        console.log(chalk.gray(`   ├─ ⚡ Generating SVD Animation (GPU)...`));
        
        const scriptPath = path.join(process.cwd(), 'limbs/py_bridge/animate_svd.py');
        const seed = CharacterVault.getSeed(); // Seed konsisten untuk gerakan
        
        const cmd = `"${this.pythonEnv}" "${scriptPath}" --image "${imagePath}" --output "${outputPath}" --seed ${seed}`;

        return new Promise((resolve, reject) => {
            exec(cmd, (error, stdout, stderr) => {
                if (error) {
                    // FALLBACK: Jika GPU Crash/OOM, jangan batalkan video.
                    // Otomatis pindah ke Mode CPU untuk scene ini saja.
                    console.error(chalk.red(`[SVD ERROR] GPU Rendering failed. Fallback to CPU Motion...`));
                    // console.error(`[LOG] ${stderr}`); // Uncomment jika butuh debug detail
                    
                    this.createMotionClip(imagePath, outputPath)
                        .then(resolve)
                        .catch(reject);
                } else {
                    resolve();
                }
            });
        });
    }

    /**
     * MODE B: MOTION COMIC (CPU SAFE)
     * Menggunakan FFmpeg Zoom/Pan
     */
    async createMotionClip(imagePath, outputPath) {
        console.log(chalk.gray(`   ├─ 🎞️ Generating Motion Clip (CPU)...`));
        
        // Efek Cinematic Zoom-In perlahan (Duration 5 detik)
        const cmd = `ffmpeg -y -loop 1 -i "${imagePath}" -vf "zoompan=z='min(zoom+0.0015,1.5)':d=125:x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':s=720x1280" -c:v libx264 -t 5 -pix_fmt yuv420p "${outputPath}"`;

        return new Promise((resolve, reject) => {
            exec(cmd, (error) => {
                if (error) reject(error);
                else resolve();
            });
        });
    }

    /**
     * GENERATE VOICE (TTS)
     * Menggunakan Edge-TTS via Python
     */
    async generateVoice(text, outputPath) {
        // Path ke executable edge-tts di dalam VENV
        const isWin = process.platform === "win32";
        const binFolder = isWin ? 'Scripts' : 'bin';
        const edgeTtsPath = path.join(path.dirname(path.dirname(this.pythonEnv)), binFolder, 'edge-tts');

        // Menggunakan suara Cowok Indonesia (ArdiNeural)
        const cmd = `"${edgeTtsPath}" --text "${text}" --write-media "${outputPath}" --voice id-ID-ArdiNeural`;
        
        return new Promise((resolve) => {
            exec(cmd, (error) => {
                // Resolve anyway (jika gagal, video tetap jalan tanpa suara narasi, hanya musik/hening)
                if (error) console.error(chalk.yellow(`[TTS WARNING] Voice generation skipped: ${error.message}`));
                resolve();
            });
        });
    }

    /**
     * MUXING (GABUNG VIDEO + AUDIO)
     */
    async combineVideoAudio(videoPath, audioPath, outputPath) {
        // Loop video (-stream_loop -1) jika audio lebih panjang
        // Cut video (-shortest) jika video lebih panjang
        // Mapping: 0:v (Video dari input 0), 1:a (Audio dari input 1)
        const cmd = `ffmpeg -y -stream_loop -1 -i "${videoPath}" -i "${audioPath}" -c:v copy -c:a aac -shortest -map 0:v -map 1:a "${outputPath}"`;
        
        return new Promise((resolve) => {
            exec(cmd, (error) => {
                if (error) {
                    console.error(chalk.red(`[MUX ERROR] ${error.message}`));
                    // Jika gagal muxing (misal audio tidak ada), copy video aslinya saja
                    fs.copyFileSync(videoPath, outputPath);
                }
                resolve(); 
            });
        });
    }

    /**
     * MERGE ALL SCENES
     */
    async mergeClips(files, outputPath) {
        // Buat file list sementara
        const listContent = files.map(f => `file '${f}'`).join('\n');
        const listPath = path.join(process.cwd(), 'temp_list.txt');
        fs.writeFileSync(listPath, listContent);
        
        // FFMPEG Concat
        const cmd = `ffmpeg -y -f concat -safe 0 -i "${listPath}" -c copy "${outputPath}"`;
        
        return new Promise((resolve) => {
            exec(cmd, (error) => {
                if (error) console.error(chalk.red(`[STITCH ERROR] ${error.message}`));
                
                // Bersihkan file sampah
                if (fs.existsSync(listPath)) fs.unlinkSync(listPath);
                
                resolve();
            });
        });
    }

    /**
     * UPLOAD TO INSTAGRAM
     */
    uploadVideo(videoPath, caption) {
        const scriptPath = path.join(process.cwd(), 'limbs/py_bridge/upload_ig.py');
        const username = config.social.instagram.username;
        const password = config.social.instagram.password;
        
        console.log(chalk.yellow(`[VIDEO] 🚀 Uploading to Instagram...`));

        // Argument --video wajib ada di script python
        const cmd = `"${this.pythonEnv}" "${scriptPath}" --username "${username}" --password "${password}" --video "${videoPath}" --caption "${caption}"`;
        
        exec(cmd, (err, stdout) => {
            if (err) console.error(chalk.red(`[UPLOAD FAIL] ${err.message}`));
            else console.log(chalk.green(`[UPLOAD SUCCESS] ${stdout}`));
        });
    }
    
    // Helper untuk test manual dari index.js atau console
    forceTest() {
        console.log("🚀 FORCING VIDEO PRODUCTION TEST...");
        this.produceEpisode();
    }
}

export default VideoManager;