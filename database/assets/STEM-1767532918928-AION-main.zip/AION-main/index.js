import config from './config.js';
import Settings from './core/Settings.js';
import BioCore from './core/BioCore.js';
import GodsEye from './core/GodsEye.js';
import MemoryStore from './core/MemoryStore.js';
import AetherLoader from './core/AetherLoader.js';
import CortexManager from './core/CortexManager.js';
import CognitiveCortex from './core/CognitiveCortex.js';
import Environment from './core/Environment.js';
import Evolution from './core/Evolution.js';
import SocialWorker from './core/SocialWorker.js';
import ResourceManager from './core/ResourceManager.js';
import SystemDoctor from './core/SystemDoctor.js';

// --- LIMBS (Anggota Tubuh) ---
import InstagramManager from './limbs/InstagramManager.js';
import VideoManager from './limbs/VideoManager.js'; // [PENTING] Agar tidak crash ReferenceError
import PerceptionScanner from './limbs/PerceptionScanner.js';

import { TerminalAdapter } from './adapters/TerminalAdapter.js';
import { WhatsAppAdapter } from './adapters/WhatsAppAdapter.js';
import { WebAdapter } from './adapters/WebAdapter.js';

import path from 'path';
import { fileURLToPath } from 'url';
import chalk from 'chalk';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

class NeuralNexus {
    constructor() {
        // 1. Initialize Core Systems
        this.godsEye = new GodsEye(this);
        this.aether = new AetherLoader(path.join(__dirname, 'commands'), this);
        this.cortex = new CortexManager(this);      
        this.cognitive = new CognitiveCortex(this); 
        this.social = new SocialWorker(this);       

        // 2. Initialize Adapters
        this.terminal = new TerminalAdapter(this);
        this.whatsapp = new WhatsAppAdapter(this);
        this.web = new WebAdapter(this);

        // 3. Initialize Extensions
        this.doctor = new SystemDoctor(this);        
        
        // 4. Initialize Limbs & Sensors
        this.scanner = new PerceptionScanner(this); 
        this.instagram = new InstagramManager(this);
        this.video = new VideoManager(this);
    }

    async ignite() {
        console.clear();
        await ResourceManager.checkAndEnforce();
        this.terminal.log(chalk.cyan("INITIATING NEURAL NEXUS (AGI ARCHITECTURE)..."));

        // A. SYSTEM PRE-FLIGHT CHECK
        try { await this.cortex.ensureCognitiveSystem(); } catch (e) { this.terminal.log(chalk.red(`[CORTEX] ${e.message}`)); }

        // B. Start Memory & Bio-Support
        await MemoryStore.init();
        await BioCore.init();
        this.godsEye.observe();
        
        // C. Load Skills & Sensors
        await this.aether.init();
        Environment.init(); 

        // D. Open Sensory Ports (Adapters)
        if (config.adapters.terminal.active) this.terminal.start();
        if (config.adapters.whatsapp.active) await this.whatsapp.start();
        if (config.adapters.web.active) await this.web.start();

        // E. Start Autonomous Threads
        this.social.init();   

        // F. Final Log
        this.terminal.log(chalk.green(`[NEXUS] SYSTEM ONLINE. Consciousness is Stable.`));
    }

    /**
     * WRAPPER: Pintu Depan (Kompatibilitas)
     */
    async handleIncomingMessage(source, userId, text, extra = {}) {
        return this.processInput(source, userId, text, null, extra);
    }

    /**
     * CENTRAL PROCESSING UNIT (ROUTER)
     * Mengatur aliran data, keamanan, dan keputusan (Refleks vs Kognitif)
     */
    // ============================================================
    // 🧠 PROCESS INPUT (FULL FEATURED + DIAGNOSTIC MODE)
    // ============================================================
    async processInput(source, userId, text, contextId = null, extra = {}) {
        if (!text) return;
        
        // [DEBUG-START] Lacak paket masuk
        console.log(chalk.gray(`\n[NEXUS-FLOW] 🟢 START: Input from ${source} (${userId})`));

        // --- 0. SESSION HIJACKING (LOGIN FLOW) ---
        const loginCmd = this.aether.getCommand('login');
        if (loginCmd && loginCmd.LoginState && loginCmd.LoginState.has(userId)) {
             console.log(chalk.cyan(`[NEXUS-FLOW] 🔒 Intercepted by Login Session`));
             const replyResponse = await loginCmd.handleReply({ nexus: this, userId, text });
             if (replyResponse) {
                 await this.routeOutput(source, userId, replyResponse, extra);
                 return; 
             }
        }

        Environment.updateActivity();

        // --- 1. PREFIX & COMMAND DETECTION ---
        let isCommand = false;
        let cmdName = "";
        let args = [];
        let cleanText = text.trim();

        // [FIX VITAL] Load Prefix dengan Fallback yang kuat
        let currentPrefixes = Settings.get('prefixes');
        if (!currentPrefixes || !Array.isArray(currentPrefixes) || currentPrefixes.length === 0) {
            currentPrefixes = ['.', '#', '!', '/']; 
        }

        // Cari prefix match
        const matchedPrefix = currentPrefixes.find(p => cleanText.startsWith(p));

        if (matchedPrefix) {
            const parts = cleanText.slice(matchedPrefix.length).trim().split(/\s+/);
            cmdName = parts[0].toLowerCase();
            args = parts.slice(1);
            
            const commandObj = this.aether.getCommand(cmdName);
            
            // [DEBUG-CMD]
            if (commandObj) {
                isCommand = true;
                console.log(chalk.green(`[NEXUS-FLOW] ✅ Command Detected: ${cmdName}`));
            } else {
                console.log(chalk.yellow(`[NEXUS-FLOW] ⚠️ Prefix matches, but '${cmdName}' is not a command.`));
            }
        }
        // Support Mode Tanpa Prefix (Jika diaktifkan di Settings)
        else if (Settings.get('prefixMode') === 'no_prefix') {
            const parts = cleanText.split(/\s+/);
            const potentialCmd = parts[0].toLowerCase();
            if (this.aether.getCommand(potentialCmd)) {
                cmdName = potentialCmd;
                args = parts.slice(1);
                isCommand = true;
                console.log(chalk.green(`[NEXUS-FLOW] ✅ No-Prefix Command Detected: ${cmdName}`));
            }
        }

        // --- 2. GROUP FILTER LOGIC (ANTI SPAM) ---
        if (source === 'whatsapp' && extra.isGroup) {
            const botNumber = extra.botNumber;
            const isMentioned = extra.mentions && extra.mentions.includes(botNumber);
            const isReplyToBot = extra.quotedParticipant === botNumber;

            // Jika BUKAN Command DAN BUKAN Mention DAN BUKAN Reply -> ABAIKAN
            if (!isCommand && !isMentioned && !isReplyToBot) {
                // console.log(chalk.gray(`[NEXUS-FLOW] ⛔ Group chatter ignored.`)); // Un-comment jika ingin debug spam
                return; 
            }
        }

        // --- 3. LOGGING ---
        if (source !== 'terminal') {
            const displayName = extra.pushName || userId;
            if (this.terminal) this.terminal.logChat(displayName, text, source);
        }

        // --- 4. EKSEKUSI ---
        let response = "";
        const command = isCommand ? this.aether.getCommand(cmdName) : null;

        try {
            if (command) {
                // >> JALUR REFLEKS (COMMAND) <<
                console.log(chalk.blue(`[NEXUS-FLOW] ⚡ Executing Command Logic...`));
                
                if (command.ownerOnly && !this.checkPrivilege(source, userId)) {
                    console.log(chalk.red(`[NEXUS-FLOW] 🛑 Access Denied.`));
                    await this.routeOutput(source, userId, "⚠️ [ACCESS DENIED] Restricted Protocol.", extra);
                    return;
                }
                
                if (this.terminal) this.terminal.log(chalk.blue(`[NEXUS] Executing Protocol: ${command.name}`));
                
                response = await command.execute({ 
                    nexus: this, source, userId, args, text: cleanText, extra, command: cmdName 
                });
                
                console.log(chalk.green(`[NEXUS-FLOW] ✅ Command Execution Finished. Output Length: ${response ? response.length : 0}`));

                Evolution.gainXP(2, 'Command Usage');
                BioCore.stimulate('heal', 0.1);

            } else {
                // >> JALUR KOGNITIF (LLM / OTAK) <<
                console.log(chalk.magenta(`[NEXUS-FLOW] 🧠 Entering Cognitive Cortex...`));
                
                if (source === 'terminal' && this.terminal) await this.terminal.showTyping(1000);
                if (source === 'whatsapp' && extra.sock) {
                    await extra.sock.sendPresenceUpdate('composing', extra.chatId);
                }
                
                // Inject Context Chain
                let finalPrompt = text;
                if (extra.contextChain) {
                    finalPrompt = `${extra.contextChain}\n\n[User says]: ${text}`;
                }

                // Proses Berpikir
                response = await this.cognitive.process(userId, finalPrompt);
                console.log(chalk.green(`[NEXUS-FLOW] ✅ Cortex Response Generated.`));
                
                // [AUTO-COMMAND] AI Menjalankan Command Sendiri
                if (typeof response === 'string' && response.startsWith('[EXECUTE_COMMAND::')) {
                    const cmdToRun = response.split('::')[1].replace(']', '').trim();
                    const targetCmd = this.aether.getCommand(cmdToRun);
                    if (targetCmd) {
                        if (this.terminal) this.terminal.log(chalk.magenta(`[AI-AUTO] Triggering Command: ${cmdToRun}`));
                        response = await targetCmd.execute({ 
                            nexus: this, source, userId, args: [], text: cleanText, extra, command: cmdToRun 
                        });
                    }
                }
                Evolution.gainXP(5, 'Cognitive Process');
            }
        } catch (error) {
            console.error(chalk.red(`[NEXUS-FLOW] 💀 CRITICAL ERROR during Execution:`));
            console.error(error);
            this.godsEye.reportError('NexusProcess', error);
            if (source === 'terminal') response = `[SYSTEM ERROR] ${error.message}`;
            else console.error(chalk.red(`[PROCESS ERROR] ${error.message}`));
        } finally {
            if (source === 'whatsapp' && extra.sock) await extra.sock.sendPresenceUpdate('paused', extra.chatId);
        }

        // --- 5. MEMORY & OUTPUT ---
        // Simpan Ingatan
        await MemoryStore.addEpisodic(source === 'terminal' ? 'developer' : 'user', text, BioCore.state);
        
        // [DEBUG-CRITICAL] Cek Routing
        if (response) {
            console.log(chalk.yellow(`[NEXUS-FLOW] 🚚 Routing Output to: ${source} (Target: ${extra.chatId || userId})`));
            
            const memoryText = (typeof response === 'object' && response.caption) ? response.caption : String(response);
            await MemoryStore.addEpisodic('assistant', memoryText, BioCore.state);
            
            try {
                // Pastikan extra.chatId dikirim, kalau null pakai userId
                await this.routeOutput(source, userId, response, extra);
                console.log(chalk.green(`[NEXUS-FLOW] ✅ Route Output Called Successfully.`));
            } catch (err) {
                console.error(chalk.red(`[NEXUS-FLOW] ❌ Route Output FAILED: ${err.message}`));
            }
        } else {
             console.log(chalk.red(`[NEXUS-FLOW] ⛔ Output is EMPTY/NULL. Nothing sent.`));
        }
    }

    // --- SECURITY PROTOCOL ---
    checkPrivilege(source, userId) {
        // 1. Terminal user (Developer) selalu punya akses penuh
        if (source === 'terminal') return true;

        // 2. Cek Owner dari Config
        if (!config.system.ownerNumber) return false;

        // Normalisasi nomor (hapus @s.whatsapp.net dan karakter non-digit)
        const cleanUser = userId.replace(/\D/g, ''); 
        const cleanOwner = config.system.ownerNumber.replace(/\D/g, '');

        return cleanUser === cleanOwner;
    }

    /**
     * Mengirim respon kembali ke adapter yang sesuai
     */
    async routeOutput(source, userId, content, extra) {
        if (!content) return;

        // --- A. TERMINAL ---
        if (source === 'terminal') {
            if (typeof content === 'object' && content.image) {
                this.terminal.log(chalk.cyan(`[AION]: [IMAGE SENT] ${content.caption || ''}`));
            } else {
                this.terminal.log(chalk.cyan(`[AION]: ${content}`));
            }
        } 
        // --- B. WEB ---
        else if (source === 'web' && extra.io) {
            extra.io.emit('response', { text: content, role: 'assistant' });
        } 
        // --- C. WHATSAPP ---
        else if (source === 'whatsapp') {
            // [CRITICAL FIX] Ambil socket dari extra, atau fallback ke adapter utama
            const sock = extra.sock || this.whatsapp.sock;
            const chatId = extra.chatId || userId;

            if (!sock) {
                console.error(chalk.red("[ROUTE FAIL] WhatsApp Socket lost! Cannot send message."));
                return;
            }

            const textString = (typeof content === 'object' && content.caption) ? content.caption : String(content);
            const typingTime = Math.min(Math.max(textString.length * 10, 500), 2000);
            
            setTimeout(async () => {
                try {
                    // Safe Quoted Construction
                    let quoted = null;
                    if (extra.msg) quoted = extra.msg;
                    else if (chatId && extra.msgId) {
                        quoted = { key: { remoteJid: chatId, id: extra.msgId, participant: userId } };
                    }

                    // Kirim Gambar / Video
                    if (typeof content === 'object' && content.image) {
                        await sock.sendMessage(chatId, {
                            image: content.image,
                            caption: content.caption || '',
                            mimetype: content.mimetype || 'image/png'
                        }, { quoted: quoted });
                    }
                    // Kirim Teks Biasa
                    else {
                        await sock.sendMessage(chatId, { text: String(content) }, { quoted: quoted });
                    }
                } catch (e) {
                    console.error(chalk.red(`[ROUTE ERROR] Failed to send message: ${e.message}`));
                    // Fallback tanpa reply jika quoted error
                    try {
                        if (typeof content === 'string') await sock.sendMessage(chatId, { text: String(content) });
                    } catch (err) {}
                }
            }, typingTime);
        }
    }
}

// --- IGNITE THE SPARK ---
const nexus = new NeuralNexus();
nexus.ignite();

// --- GLOBAL ERROR CATCHER & AUTO-HEAL ---
process.on('uncaughtException', async (err) => {
    console.error(chalk.red.bold('\n[FATAL] Uncaught Exception Detected!'));
    console.error(err);

    const match = err.stack.match(/\((.*\.js):(\d+):(\d+)\)/) || err.stack.match(/at (.*\.js):(\d+):(\d+)/);
    
    if (match && nexus.doctor) {
        const filePath = match[1];
        if (!filePath.includes('node_modules')) {
            console.log(chalk.yellow(`[AUTO-REPAIR] Summoning System Doctor for: ${path.basename(filePath)}`));
            await nexus.doctor.heal(err, filePath);
            console.log(chalk.green(`[REBOOT] Restarting System to apply fixes...`));
            process.exit(1); 
        }
    }
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error(chalk.red('[WARNING] Unhandled Rejection at:', promise, 'reason:', reason));
});