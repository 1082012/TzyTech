import readline from 'readline';
import chalk from 'chalk';
import BioCore from '../core/BioCore.js';
import config from '../config.js';

export class TerminalAdapter {
    constructor(nexus) {
        this.nexus = nexus;
        
        // Inisialisasi Readline Interface (Satu-satunya pintu IO terminal)
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout,
            prompt: '' 
        });
        
        this.mode = config.adapters.terminal.visualMode || 'simple';
        this.isTyping = false;
        
        // --- LOGIC INTERUPSI & BUFFERING ---
        // isInterrogating: Jika true, berarti sistem sedang bertanya (misal: Login WA).
        // Saat true, semua log masuk akan ditahan (buffer) agar tidak merusak ketikan user.
        this.isInterrogating = false; 
        this.logBuffer = [];          
    }

    start() {
        this.renderPrompt();

        // Listener Utama untuk Chat Developer -> AI
        this.rl.on('line', async (line) => {
            // PENTING: Jika sedang mode tanya jawab (Interrogating), 
            // abaikan listener ini karena rl.question yang akan menangani inputnya.
            if (this.isInterrogating) return;

            const input = line.trim();
            if (!input) {
                this.renderPrompt();
                return;
            }

            // Hapus baris input user (agar log terlihat rapi seperti chat history)
            // Kita move cursor naik 1 baris, lalu clear baris tersebut.
            readline.moveCursor(process.stdout, 0, -1);
            readline.clearLine(process.stdout, 0);
            
            // Tampilkan ulang input user dengan format 'Dev'
            console.log(`${chalk.green('➜')} ${chalk.bold.white('Dev')}: ${input}`);

            this.isTyping = true;
            
            // Kirim input ke Otak Utama (Nexus)
            await this.nexus.processInput('terminal', 'developer', input);
            
            this.isTyping = false;
            this.renderPrompt();
        });

        // Di mode Simple, kita tidak perlu update visual realtime dari BioCore
        // karena hanya akan memenuh-menuhi log.
        BioCore.on('pulse', () => {});

        this.log(chalk.green(`[TERMINAL] Neural Link Established. Mode: ${this.mode.toUpperCase()}`));
    }

    logChat(sender, message, source) {
        const time = new Date().toLocaleTimeString('en-GB', { hour12: false });
        let tag = chalk.gray(`[${source.toUpperCase()}]`);
        
        if (source === 'whatsapp') tag = chalk.green(`[WA]`);
        if (source === 'web') tag = chalk.blue(`[WEB]`);

        // Log Rapi: [WA] Arifi: .menu
        console.log(`${chalk.gray(time)} ${tag} ${chalk.bold(sender)}: ${message}`);
        this.renderPrompt(); // Render ulang prompt agar tidak tertimpa
    }

    /**
     * Fungsi Log Cerdas
     * Menangani timestamp dan buffering saat user mengetik.
     */
    log(msg) {
        // 1. CEK STATUS: Apakah user sedang mengetik jawaban untuk sistem?
        if (this.isInterrogating) {
            // Tahan log di memori (Buffer), jangan cetak dulu
            // agar tampilan pertanyaan user tidak tertimpa/rusak.
            this.logBuffer.push(msg); 
            return; 
        }

        // 2. Jika Aman: Hapus baris prompt "> " yang aktif saat ini
        readline.clearLine(process.stdout, 0);
        readline.cursorTo(process.stdout, 0);

        // 3. Cetak Log dengan Timestamp
        const time = new Date().toLocaleTimeString('en-US', { hour12: false });
        console.log(`${chalk.gray(`[${time}]`)} ${msg}`);

        // 4. Gambar ulang prompt "> " di bawah log baru
        this.renderPrompt();
    }

    renderPrompt() {
        // Menampilkan kursor input standar
        process.stdout.write(chalk.cyan.bold('\n> '));
    }

    /**
     * Fungsi Tanya Jawab Sistem (Native)
     * Digunakan oleh modul lain (WA) untuk meminta input user.
     * Menggunakan rl.question bawaan agar Backspace berfungsi normal.
     */
    askQuestion(query) {
        return new Promise((resolve) => {
            // Aktifkan Mode Interogasi (Mute Log)
            this.isInterrogating = true; 

            // Bersihkan baris prompt saat ini agar pertanyaan muncul rapi
            readline.clearLine(process.stdout, 0);
            readline.cursorTo(process.stdout, 0);

            // Gunakan rl.question standard Node.js
            // Ini menangani raw mode tty, sehingga backspace, arrow key, dll aman.
            this.rl.question(query, (answer) => {
                // Matikan Mode Interogasi (Unmute Log)
                this.isInterrogating = false; 
                
                // Cetak log yang tadi tertahan (Missed Logs) jika ada
                if (this.logBuffer.length > 0) {
                    console.log(chalk.gray('--- 📨 Incoming Logs (Buffered) ---'));
                    this.logBuffer.forEach(l => {
                         const time = new Date().toLocaleTimeString('en-US', { hour12: false });
                         console.log(`${chalk.gray(`[${time}]`)} ${l}`);
                    });
                    this.logBuffer = []; // Kosongkan buffer
                    console.log(chalk.gray('-----------------------------------'));
                }
                
                resolve(answer.trim());
            });
        });
    }

    // Animasi Typing sederhana (opsional untuk visual feedback)
    async showTyping(duration = 1000) {
        if (this.mode === 'simple') {
            // Di mode simple, cukup indikator teks statis atau diam saja
            // process.stdout.write(chalk.yellow("AION Thinking...\n"));
            return new Promise(r => setTimeout(r, duration));
        }
        return new Promise(r => setTimeout(r, duration));
    }
}
