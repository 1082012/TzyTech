import { 
    makeWASocket, 
    useMultiFileAuthState, 
    DisconnectReason, 
    jidNormalizedUser, 
    Browsers, 
    fetchLatestBaileysVersion, 
    delay,
    getContentType 
} from '@whiskeysockets/baileys';
import path from 'path';
import pino from 'pino';
import fs from 'fs';
import qrcode from 'qrcode-terminal';
import BioCore from '../core/BioCore.js';
import config from '../config.js';
import chalk from 'chalk';

export class WhatsAppAdapter {
    constructor(nexus) {
        this.nexus = nexus;
        this.sock = null;
        this.authDir = config.adapters.whatsapp.authPath || 'auth_info_baileys';
        this.botNumber = null;
        this.retryCount = 0;
    }

    async start() {
        // 1. Pastikan folder auth ada
        if (!fs.existsSync(this.authDir)) {
            fs.mkdirSync(this.authDir, { recursive: true });
        }
        
        const { state, saveCreds } = await useMultiFileAuthState(this.authDir);
        const { version } = await fetchLatestBaileysVersion();
        
        // --- LOGIC INTERAKTIF INIT (PAIRING CODE / QR) ---
        const isNewSession = !state.creds.me && !state.creds.registered;
        let usePairingCode = false;
        let phoneNumber = '';

        if (isNewSession) {
             const q1 = chalk.yellow(`\n[WA-INIT] Pilih metode login:\n1. Scan QR Code\n2. Pairing Code\nPilihan (1/2): `);
             
             // Gunakan terminal adapter jika ada untuk input interaktif
             let ans = '1';
             if (this.nexus.terminal && this.nexus.terminal.askQuestion) {
                 ans = await this.nexus.terminal.askQuestion(q1);
             } else {
                 // Fallback simple jika terminal belum siap
                 console.log(chalk.gray("Terminal input not ready, defaulting to QR Code."));
             }

             if (ans.trim() === '2') {
                 usePairingCode = true;
                 if (this.nexus.terminal && this.nexus.terminal.askQuestion) {
                     phoneNumber = await this.nexus.terminal.askQuestion(chalk.yellow(`\nNomor HP (Contoh: 62812xxx): `));
                 }
             }
        }
        // -------------------------------------------------------
        
        if (this.validateAuthDir(this.authDir)) {
            usePairingCode = false;
        };

        // 2. Buat Socket
        this.sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: usePairingCode,
            auth: state,
            browser: Browsers.ubuntu('Chrome'), // Browser Linux agar support pairing
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,      
            markOnlineOnConnect: false,
            connectTimeoutMs: 60000,
            retryRequestDelayMs: 2000,
            emitOwnEvents: false 
        });

        // Simpan nomor bot jika sudah login
        if (state.creds.me) {
            this.botNumber = jidNormalizedUser(state.creds.me.id);
        }

        // --- HANDLER PAIRING CODE ---
        if (usePairingCode && !this.sock.authState.creds.registered) {
            console.log(chalk.cyan("Requesting Pairing Code..."));
            setTimeout(async () => {
                try {
                    const code = await this.sock.requestPairingCode(phoneNumber.replace(/[^0-9]/g, ''));
                    console.log(chalk.bgGreen.black(`\n KODE PAIRING ANDA: ${code?.match(/.{1,4}/g)?.join('-')} \n`));
                } catch(e) {
                    console.log(chalk.red("Gagal request pairing code. Restart dan coba lagi."));
                }
            }, 3000);
        }

        // --- HANDLER KONEKSI ---
        this.sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;

            // Tampilkan QR hanya jika TIDAK pakai pairing code
            if (qr && !usePairingCode) {
                console.log(chalk.cyan("\nScan QR Code dibawah ini:"));
                qrcode.generate(qr, { small: true });
            }
            
            if (connection === 'open') {
                this.botNumber = jidNormalizedUser(this.sock.user.id);
                this.nexus.terminal.log(chalk.green(`[WA] TERHUBUNG SEBAGAI: ${this.botNumber}`));
                BioCore.stimulate('heal', 0.5); 
                this.retryCount = 0;
                
                let text = "🤖 AION Berhasil tersambung di Saraf Protocol WhatsApp!";
                const whenOnline = config.adapters.whatsapp.notifyOwnerOnConnect;

                if (whenOnline === 'single') {
                    try {
                        const rawOwner = config.adapters.whatsapp.ownerNumber; // Array dari config
                        
                        // [FIX] Await dulu datanya
                        const remoteOwners = await this.fetchOwners(); 
                        const primeOwner = remoteOwners[0]; // Ambil owner pertama dari GitHub

                        // Cari kecocokan
                        const SquirrelOwner = rawOwner.find(v => v.includes(primeOwner) || primeOwner.includes(v));
                        
                        // Jika tidak ketemu, pakai fallback (ambil index 0 dari config)
                        const finalOwner = SquirrelOwner || rawOwner[0];

                        if (finalOwner) {
                            const jid = this.toWhatsAppJid(finalOwner);
                            if (jid) await this.sock.sendMessage(jid, { text });
                        }
                    } catch (err) {
                        console.log(chalk.red(`[WA-INIT-FAIL] Gagal notif owner: ${err.message}`));
                    }
                } else if (whenOnline === 'all') {
                    // Gunakan rawOwner dari config karena itu Array
                    await this.notifyOwnerAIONAlive(this.sock, config.adapters.whatsapp.ownerNumber, text);
                }
            }

            if (connection === 'close') {
                const reason = lastDisconnect?.error?.output?.statusCode;
                if (reason !== DisconnectReason.loggedOut) {
                    this.nexus.terminal.log(chalk.yellow(`[WA] Terputus. Menghubungkan ulang...`));
                    setTimeout(() => this.start(), 3000);
                } else {
                    this.nexus.terminal.log(chalk.red(`[WA] Logged Out. Hapus folder auth dan scan ulang.`));
                }
            }
        });

        this.sock.ev.on('creds.update', saveCreds);

        // --- MESSAGE HANDLER UTAMA ---
        this.sock.ev.on('messages.upsert', async (m) => {
            try {
                const msg = m.messages[0];
                if (!msg.message || msg.key.fromMe) return;

                console.log(msg.key)
                const remoteJid = msg.key.remoteJidPn ? msg.key.remoteJidPn : msg.key.remoteJidAlt
            
                const isGroup = remoteJid.endsWith('@g.us');
            
                // [FIX VITAL] Normalisasi Sender juga
                const sender = isGroup ? (msg.key.participantPn ? msg.key.participantPn : msg.key.participantAlt || msg.participant) : remoteJid;

                // [FIX UTAMA: KUPAS KULIT PESAN]
                // Wajib ada agar pesan Disappearing/ViewOnce terbaca
                let messageContent = msg.message;
                if (messageContent.ephemeralMessage) {
                    messageContent = messageContent.ephemeralMessage.message;
                }
                if (messageContent.viewOnceMessageV2) {
                    messageContent = messageContent.viewOnceMessageV2.message;
                }
                if (messageContent.viewOnceMessage) {
                    messageContent = messageContent.viewOnceMessage.message;
                }

                // 1. Ekstrak Isi Pesan
                const msgType = getContentType(messageContent);
                let body = "";

                if (msgType === 'conversation') {
                    body = messageContent.conversation;
                } else if (msgType === 'extendedTextMessage') {
                    body = messageContent.extendedTextMessage.text;
                } else if (msgType === 'imageMessage') {
                    body = messageContent.imageMessage.caption;
                } else if (msgType === 'videoMessage') {
                    body = messageContent.videoMessage.caption;
                }
                
                if (!body) return; // Skip pesan kosong
                console.log(chalk.magenta(`\n[WA-ADAPTER] 📦 PREPARING PACKET:`));
                console.log(chalk.magenta(` > Sender (User) : ${sender}`));
                console.log(chalk.magenta(` > Chat ID (Jid) : ${remoteJid}`));
                console.log(chalk.magenta(` > Body Content  : "${body}"`));
                console.log(chalk.magenta(` > Is Group?     : ${isGroup}`));
                // ---------------------------------------------------------

                // 2. Ekstrak Metadata untuk Filter Grup
                const contextInfo = messageContent.extendedTextMessage?.contextInfo || 
                                    messageContent.imageMessage?.contextInfo || 
                                    messageContent.videoMessage?.contextInfo || {};
                                    
                const mentions = contextInfo.mentionedJid || [];
                const quotedParticipant = contextInfo.participant ? jidNormalizedUser(contextInfo.participant) : null;
                const msgId = msg.key.id;

                // 3. CHAINED REPLY EXTRACTOR
                // Mengambil teks dari pesan yang di-reply untuk konteks AI
                let contextChain = "";
                if ((msgType === 'extendedTextMessage' || msgType === 'imageMessage') && contextInfo.quotedMessage) {
                    contextChain = this.extractReplyChain(msg, messageContent);
                }

                // Kirim Paket Data ke Nexus
                await this.nexus.processInput('whatsapp', sender, body, null, {
                    sock: this.sock,
                    chatId: remoteJid,
                    msgId: msgId,
                    isGroup: isGroup,
                    senderName: msg.pushName || "User",
                    
                    // Data penting untuk Filter di index.js
                    botNumber: this.botNumber,
                    mentions: mentions,
                    quotedParticipant: quotedParticipant,
                    contextChain: contextChain,
                    msg: msg // Raw message
                });

                // Auto Read
                if (config.adapters.whatsapp.markRead) {
                    await this.sock.readMessages([msg.key]);
                }

            } catch (error) {
                // Silent fail agar tidak crash loop
            }
        });
    }

    // --- FITUR: DEEP CHAIN EXTRACTOR ---
    extractReplyChain(msg, unwrappedMessageContent = null) {
        let chain = [];
        let content = unwrappedMessageContent || msg.message;
        
        // Handle ephemeral di dalam fungsi ini juga untuk safety
        if (content.ephemeralMessage) content = content.ephemeralMessage.message;

        let contextInfo = content.extendedTextMessage?.contextInfo || 
                          content.imageMessage?.contextInfo || 
                          content.videoMessage?.contextInfo;
        
        if (contextInfo && contextInfo.quotedMessage) {
            const qMsg = contextInfo.quotedMessage;
            const qBody = qMsg.conversation || 
                          qMsg.extendedTextMessage?.text || 
                          qMsg.imageMessage?.caption || 
                          "";
            
            if (qBody) {
                chain.push(`[Previous Context]: "${qBody.substring(0, 300)}..."`);
            }
        }
        
        return chain.join('\n');
    }

    async reply(to, text, quoted = null) {
        if (!this.sock) return;
        try {
            await this.sock.sendMessage(to, { text: text }, { quoted: quoted });
        } catch (e) {
            this.nexus.terminal.log(chalk.red(`[WA-REPLY-FAIL] ${e.message}`));
        }
    }

    // --- FUNGSI UPDATE BIO/STATUS (Untuk SocialWorker) ---
    async updateBio(text) {
        if (!this.sock) return;
        try {
            await this.sock.updateProfileStatus(text);
            this.nexus.terminal.log(chalk.blue(`[WA] Bio Updated: "${text}"`));
        } catch (e) {
            // Rate limit WA kadang menolak update status terlalu sering
        }
    }

    // --- FUNGSI PROACTIVE CHAT (Untuk SocialWorker/Inisiatif) ---
    async sendProactive(to, text) {
        if (!this.sock) return;
        try {
            // Kirim pesan tanpa quoted (karena ini inisiatif bot)
            await this.sock.sendMessage(to, { text: text });
            this.nexus.terminal.log(chalk.cyan(`[WA-INITIATIVE] Sent to ${to}: "${text}"`));
        } catch (e) {
            this.nexus.terminal.log(chalk.red(`[WA-INITIATIVE-FAIL] ${e.message}`));
        }
    }
    
    async notifyOwnerAIONAlive(sock, owners, text) {
        for (const owner of owners) {
            const jid = this.toWhatsAppJid(owner);
            await sock.sendMessage(jid, { text });

            // delay 3 detik antar owner
            await delay(3000);
        }
    }
    
    toWhatsAppJid(number) {
        // [SAFETY GUARD] Jika number kosong/undefined, jangan crash.
        if (!number) { 
            console.error(chalk.red("[WA-ERROR] toWhatsAppJid received null/undefined!"));
            return ""; 
        }

        // hapus spasi, +, dan karakter aneh
        const clean = number.toString().replace(/[^0-9]/g, '');

        // kalau sudah jid, langsung return
        if (clean.endsWith('@s.whatsapp.net')) {
            return clean;
        }

        return `${clean}@s.whatsapp.net`;
    }

    validateAuthDir(authDir) {
        const credsPath = path.join(authDir, 'creds.json');

        // cek folder
        if (!fs.existsSync(authDir)) {
            return false;
        }

        // cek file creds.json
        if (!fs.existsSync(credsPath)) {
            return false;
        }

        return true;
    }
    
    
    async fetchOwners() {
        const url = "https://raw.githubusercontent.com/razzaqinspires/aion-config/main/owner.txt";

        const res = await fetch(url);
        if (!res.ok) throw new Error("Gagal fetch owner.txt");

        const text = await res.text();

        return text
            .split('\n')
            .map(v => v.trim())
            .filter(v => v.length > 0);
    }
}
