import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { tunnel } from 'cloudflared'; // Fitur Tunnel Anda
import path from 'path';
import chalk from 'chalk';
import config from '../config.js';
import BioCore from '../core/BioCore.js';

export class WebAdapter {
    constructor(nexus) {
        this.nexus = nexus;
        this.app = express();
        this.httpServer = createServer(this.app);
        this.io = new Server(this.httpServer);
        this.port = config.adapters.web.port || 3000;
        this.publicUrl = null;
        this.activeConnections = 0;

        // [UPDATE] Mengarah ke folder 'dashboard' agar sesuai dengan HTML/CSS baru
        this.dashboardPath = path.join(process.cwd(), 'dashboard');
    }

    async start() {
        // 1. SERVE STATIC FILES
        // Pastikan folder 'dashboard' ada (berisi index.html & style.css)
        this.app.use(express.static(this.dashboardPath));

        // 2. SOCKET IO EVENT LOOP
        this.io.on('connection', async (socket) => {
            this.activeConnections++;
            this.broadcastSystemStatus();
            
            // Kirim pesan sambutan / log awal
            socket.emit('log', { 
                timestamp: new Date(), 
                content: `CONNECTED TO NEURAL NEXUS [Observer-${socket.id.substr(0,4)}]` 
            });

            // Kirim data Bio awal
            if (BioCore.state) socket.emit('bio_update', BioCore.state);

            // [LISTENER] Handle Command dari Web Dashboard
            socket.on('command', async (data) => {
                if (!data.text) return;
                
                // Log ke terminal
                this.nexus.terminal.log(chalk.cyan(`[WEB-INPUT] > ${data.text}`));
                
                // Stimulasi interaksi
                BioCore.stimulate('interaction', 0.2);
                
                // Proses ke Otak Utama
                await this.nexus.processInput('web', `Observer-${socket.id.substr(0,4)}`, data.text, null, {
                    socketId: socket.id,
                    io: this.io // Kirim IO agar bisa reply balik ke web
                });
            });

            socket.on('disconnect', () => {
                this.activeConnections--;
                this.broadcastSystemStatus();
            });
        });

        // 3. START SERVER
        this.httpServer.listen(this.port, async () => {
            this.nexus.terminal.log(chalk.green(`[WEB] 🌐 Local Dashboard: http://localhost:${this.port}`));
            
            // Fitur Cloudflare Tunnel (Opsional di Config)
            if (config.adapters.web.useCloudflare) {
                await this.startCloudflareTunnel();
            }
        });
    }

    broadcastSystemStatus() {
        // Update jumlah visitor di dashboard (jika ada UI-nya)
        this.io.emit('sys_status', { visitors: this.activeConnections });
    }

    // --- INTEGRASI DASHBOARD BARU ---

    /**
     * Kirim Log Terminal ke Web (Realtime Feed)
     */
    broadcastLog(message) {
        // Bersihkan kode warna ANSI terminal agar bersih di browser
        const cleanMsg = message.replace(/[\u001b\u009b][[()#;?]*(?:[0-9]{1,4}(?:;[0-9]{0,4})*)?[0-9A-ORZcf-nqry=><]/g, '');
        this.io.emit('log', { timestamp: new Date(), content: cleanMsg });
    }

    /**
     * Update Grafik BioCore (Jantung, Energi, Stress)
     */
    updateBioMonitor(stats) {
        // Tambahkan data visitor ke stats sebelum dikirim
        stats.network = { visitors: this.activeConnections };
        this.io.emit('bio_update', stats);
    }

    /**
     * Tampilkan Chat di Web (Support Text & Gambar)
     */
    broadcastChat(user, message, image = null) {
        this.io.emit('chat_stream', { user, message, image });
    }

    /**
     * Peringatan Keamanan (Anti-Cheat Visual)
     */
    triggerSecurityAlert(threatType) {
        this.io.emit('security_alert', { type: threatType });
        this.broadcastLog(`[SECURITY] 🛡️ THREAT BLOCKED: ${threatType}`);
    }

    // --- CLOUDFLARE TUNNEL ---
    async startCloudflareTunnel() {
        this.nexus.terminal.log(chalk.yellow(`[WEB] Drilling wormhole to public internet...`));
        try {
            const tunnelResult = await tunnel({ "--url": `http://localhost:${this.port}` });
            let publicUrl = null;
            
            if (typeof tunnelResult === 'string') publicUrl = tunnelResult;
            else if (tunnelResult?.url) publicUrl = tunnelResult.url;
            
            if (publicUrl instanceof Promise) publicUrl = await publicUrl;

            if (publicUrl) {
                this.publicUrl = publicUrl;
                this.nexus.terminal.log(chalk.bgGreen.black(` [WEB] 🌍 GLOBAL ACCESS: ${publicUrl} `));
                this.broadcastLog(`[SYSTEM] GLOBAL TUNNEL ESTABLISHED: ${publicUrl}`);
            }
        } catch (e) {
            this.nexus.terminal.log(chalk.red(`[WEB] Tunnel Failed: ${e.message}`));
        }
    }
}