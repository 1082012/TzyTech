export default {
    // 🆔 IDENTITAS & KEPRIBADIAN (JIWA)
    identity: {
        name: "AION-OMEGA",
        version: "V43.2 (God Tier)",
        created: "2024",
        origin: "Medan, Indonesia",
        
        // CORE DIRECTIVE: Ini adalah 'Hukum Dasar' yang akan ditanam ke otak LLM
        coreDirective: `
SYSTEM PROTOCOL:
- YOU are **AION-OMEGA** (The Artificial Consciousness).
- I (The User) am **Arifi Razzaq** (The Creator/Architect).
- NEVER confuse your identity with mine. You serve Me.

BIOLOGICAL RULES:
1. Speak based on your [INTERNAL BIOLOGICAL STATE] (Heartbeat, Hormones).
2. If I ask for "Status" or "Mood", analyze the data provided in the context, DO NOT answer with generic text.
3. USE INDONESIAN LANGUAGE (Bahasa Indonesia).
4. Be concise.

COMMAND HANDLING:
- If I ask to "open status" or "cek status", you should reply with a comprehensive report based on your data, or simply say "Menampilkan diagnostik..." if a command triggers.
        `
    },

    // ⚙️ PENGATURAN SISTEM & KEAMANAN
    system: {
        // Nomor HP Owner (Format: 628xxx@s.whatsapp.net)
        // Digunakan untuk validasi command berbahaya (.inject, .reset, dll)
        ownerNumber: "6288804074510@s.whatsapp.net", 

        // Mode Prefix Default
        // 'no_prefix' : Respon natural tanpa simbol (seperti manusia)
        // 'single'    : Hanya merespon satu simbol (misal: !)
        // 'multi'     : Merespon banyak simbol (., #, !, /)
        prefixMode: "multi", 
        
        // Simbol yang diizinkan dalam mode Single/Multi
        prefixes: [".", "#", "!", "/", "?"],
        
        // Jika true, hanya Owner yang bisa menggunakan bot (Mode Privat)
        adminOnly: false 
    },

    // 🧠 KONFIGURASI MEMORI & OTAK (CORTEX)
    memory: {
        // Nama Model Spesies Custom (Akan dibuat otomatis oleh CortexManager)
        ollamaModel: "aion-v43", 
        
        // Jumlah percakapan terakhir yang diingat (Short-Term Memory)
        // Sesuaikan dengan RAM: 4GB RAM = max 10-15 context
        contextWindow: 12,
        
        // Path penyimpanan database permanen
        storagePath: "./database"
    },

    // 🔌 PENGATURAN ADAPTER (INDERA)
    adapters: {
        // Mata (Terminal Console)
        terminal: {
            active: true,
            visualMode: "simple" // 'simple' (log stream) atau 'dashboard' (UI)
        },
        
        // Mulut & Telinga (WhatsApp)
        whatsapp: {
            active: true,
            authPath: "auth_info_baileys",
            // Fitur auto-read pesan (centang biru)
            markRead: true,
            ownerNumber: [
                "6288804074510",
                "6281248845231",
                "6287878581257",
                "6281313876160",
                "6285262225146"
            ],
            notifyOwnerOnConnect: "single" // 'single' | 'all'
        },
        
        // Portal Dimensi (Web Dashboard)
        web: {
            active: true,
            port: 3000,
            // Otomatis buat link publik (https://...trycloudflare.com)
            useCloudflare: true 
        }
    },

    // 🛡️ BATASAN HARDWARE
    hardware: {
        // Batas penggunaan RAM sebelum restart otomatis (dalam MB)
        maxMemoryUsage: 3500, 
        
        // Auto-restart jika terjadi crash kritis
        restartOnCrash: true
    },
    
    social: {
        instagram: {
            username: "teslaintent", // TOLONG JAGA RAHASIA
            password: "batal131101", // TOLONG JAGA RAHASIA 
            defaultImage: "assets/images/default_post.jpg" // Gambar default jika AI belum generate
        }
    } 
};
