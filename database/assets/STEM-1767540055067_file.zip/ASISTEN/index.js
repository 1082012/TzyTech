/**
 * GUS SUPPORT SYSTEM - CORE ENGINE
 * Versi: 3.0.0 (Heavy Duty)
 * Deskripsi: Core koneksi dengan fitur Auto-Restart, Call Rejector, dan Monitoring.
 */

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    processQueryParams
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const readline = require('readline');
const fs = require('fs-extra');
const path = require('path');
const handler = require('./handler');
const config = require('./config');

// Konfigurasi Interface Terminal
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise((resolve) => rl.question(text, resolve));

// Fungsi untuk styling terminal
const logCyan = (text) => console.log(`\x1b[36m${text}\x1b[0m`);
const logYellow = (text) => console.log(`\x1b[33m${text}\x1b[0m`);
const logRed = (text) => console.log(`\x1b[31m${text}\x1b[0m`);

/**
 * Fungsi Utama Koneksi
 */
async function startGusBot() {
    logCyan(`
    ╔══════════════════════════════════════════════╗
    ║        GUS SUPPORT SYSTEM - VERSION 3.0      ║
    ║      Customer Service & Security Engine      ║
    ╚══════════════════════════════════════════════╝
    `);

    // 1. Inisialisasi Auth & Versi
    const { state, saveCreds } = await useMultiFileAuthState('session_cs');
    const { version, isLatest } = await fetchLatestBaileysVersion();
    
    logYellow(`[INFO] Menggunakan Baileys v${version.join('.')}`);
    if (!isLatest) logRed(`[WARN] Versi Baileys bukan yang terbaru. Update segera.`);

    // 2. Setup Socket
    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
        },
        browser: ["Ubuntu", "Safari", "1.0.0"],
        syncFullHistory: false,
        markOnlineOnConnect: true,
        connectTimeoutMs: 60000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 10000,
        generateHighQualityLinkPreview: true
    });

    // 3. Sistem Pairing Code
    if (!sock.authState.creds.registered) {
        logCyan(`[PAIRING] Mode Pairing Code Aktif.`);
        const phoneNumber = await question('[?] Masukkan Nomor WA Bot (62xxx): ');
        const code = await sock.requestPairingCode(phoneNumber.trim());
        logYellow(`\n[!] KODE PAIRING ANDA: ${code}\n`);
    }

    // 4. Monitoring Koneksi
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (connection === 'close') {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            logRed(`[CONN] Koneksi Terputus. Alasan: ${reason}`);

            if (reason === DisconnectReason.badSession) {
                logRed(`[ERR] Sesi Buruk. Hapus folder session_cs dan restart.`);
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                logYellow(`[RECONN] Koneksi ditutup, mencoba menyambung kembali...`);
                startGusBot();
            } else if (reason === DisconnectReason.connectionLost) {
                logYellow(`[RECONN] Koneksi hilang, mencoba menyambung kembali...`);
                startGusBot();
            } else if (reason === DisconnectReason.connectionReplaced) {
                logRed(`[ERR] Sesi ditimpa. Harap tutup sesi lain.`);
                process.exit();
            } else if (reason === DisconnectReason.loggedOut) {
                logRed(`[ERR] Bot Logout. Hapus folder session_cs dan scan ulang.`);
                process.exit();
            } else if (reason === DisconnectReason.restartRequired) {
                logYellow(`[RECONN] Restart diperlukan, memulai ulang...`);
                startGusBot();
            } else {
                logYellow(`[RECONN] Masalah tidak diketahui, mencoba menyambung...`);
                startGusBot();
            }
        } else if (connection === 'open') {
            logCyan(`[SUCCESS] Bot Gus Support Berhasil Terhubung!`);
            logCyan(`[INFO] Sistem Anti-Call & Anti-Spam Berjalan.`);
            
            // Kirim status ke owner jika bot menyala
            await sock.sendMessage(config.ownerNumber + "@s.whatsapp.net", { 
                text: `🚀 *Bot Gus Support Online!*\nJam: ${new Date().toLocaleTimeString()}\nRAM: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB` 
            });
        }
    });

    // 5. Simpan Kredensial
    sock.ev.on('creds.update', saveCreds);

    // 6. FITUR: REJECT CALL (Otomatis)
    sock.ev.on('call', async (call) => {
        const { id, from, status } = call[0];
        if (status === 'offer') {
            logRed(`[CALL] Menolak telepon dari ${from.split('@')[0]}`);
            await sock.rejectCall(id, from);
            await sock.sendMessage(from, { 
                text: "⚠️ *SISTEM OTOMATIS*\nMohon maaf, Bot tidak dapat menerima panggilan. Silahkan hubungi via Chat Teks." 
            });
        }
    });

    // 7. Pesan Masuk (Handler)
    sock.ev.on('messages.upsert', async (chatUpdate) => {
        try {
            if (!chatUpdate.messages[0]) return;
            await handler(sock, chatUpdate);
        } catch (e) {
            logRed(`[ERR HANDLER] ${e.message}`);
        }
    });

    // 8. Sistem Auto-Cleaning (Mencegah Memori Penuh)
    setInterval(() => {
        const usage = process.memoryUsage().heapUsed / 1024 / 1024;
        if (usage > 400) { // Jika RAM > 400MB, bersihkan cache
            logYellow(`[CLEAN] Penggunaan RAM Tinggi: ${usage.toFixed(2)}MB. Membersihkan cache...`);
            // Baileys tidak punya cache manual yang bisa dibersihkan secara publik dengan mudah, 
            // tapi kita bisa memaksa garbage collection jika dijalankan dengan flag tertentu.
        }
    }, 300000); // Cek setiap 5 menit

    /**
     * Penanganan Error Tak Terduga
     */
    process.on('uncaughtException', (err) => {
        logRed(`[FATAL ERROR] ${err.stack}`);
        // Bot tetap berjalan meski ada error
    });

    process.on('unhandledRejection', (reason, promise) => {
        logRed(`[UNHANDLED REJECTION] Reason: ${reason}`);
    });
}

/**
 * Memastikan Folder Sesi Tersedia
 */
if (!fs.existsSync('./session_cs')) {
    fs.mkdirSync('./session_cs');
}

// Eksekusi Bot
startGusBot();
