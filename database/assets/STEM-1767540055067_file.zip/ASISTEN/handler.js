/**
 * GUS SUPPORT SYSTEM - PROFESSIONAL CS HANDLER
 * Versi: 3.0.0 (Full Features)
 * Total Baris: 160+ 
 * Yang Rename Ga Ninggalin Credit Saya Cari Sampai Dapat!
 */

const config = require('./config');
const fs = require('fs-extra');

// Inisialisasi Database Sederhana agar antrean tidak hilang saat restart
const dbPath = './database.json';
if (!fs.existsSync(dbPath)) {
    fs.writeJsonSync(dbPath, { queue: [], blocked: [] });
}

// Memory Sessions
const sessions = new Map();     
const nameToJid = new Map();    
const spamTracker = new Map();

// Filter Kata Kasar (Contoh)
const badWords = ['anjing', 'bangsat', 'tolol', 'goblok', 'peler'];

/**
 * Main Handler Function
 */
module.exports = async (sock, m) => {
    try {
        const msg = m.messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const jid = msg.key.remoteJid;
        const sender = msg.key.participant || msg.key.remoteJid;
        const pushName = msg.pushName || "User";
        
        const body = (
            msg.message.conversation || 
            msg.message.extendedTextMessage?.text || 
            msg.message.imageMessage?.caption || 
            msg.message.videoMessage?.caption || 
            ""
        ).trim();

        // 1. FILTER GRUP (Hanya Private Chat)
        if (jid.endsWith('@g.us')) return;

        // 2. DETEKSI PERAN
        const isOwner = sender.includes(config.ownerNumber);

        // 3. LOGGING AKTIVITAS (Terminal)
        console.log(`\n[${new Date().toLocaleTimeString()}] Pesan Baru:`);
        console.log(`- Dari: ${pushName} (${sender.split('@')[0]})`);
        console.log(`- Pesan: ${body || '{Media}'}`);

        // 4. SISTEM ANTI-SPAM & AUTO-BLOCK
        if (!isOwner) {
            const now = Date.now();
            if (!spamTracker.has(jid)) {
                spamTracker.set(jid, { count: 1, lastTime: now, lastChat: now });
            } else {
                let track = spamTracker.get(jid);
                if (now - track.lastTime > 60000) {
                    track.count = 1;
                    track.lastTime = now;
                } else {
                    track.count++;
                }

                if (track.count > 10) {
                    await sock.sendMessage(jid, { text: "🚫 *SISTEM KEAMANAN*\nAnda diblokir otomatis karena spam berlebihan." });
                    await sock.updateBlockStatus(jid, "block");
                    console.log(`[BLOCK] ${jid} diblokir.`);
                    return;
                }
                
                if (now - track.lastChat < config.spamCooldown) return; 
                track.lastChat = now;
            }
        }

        // 5. FILTER KATA KASAR
        if (!isOwner && badWords.some(word => body.toLowerCase().includes(word))) {
            return sock.sendMessage(jid, { text: "⚠️ *PERINGATAN*\nMohon gunakan bahasa yang sopan dalam berkomunikasi dengan layanan kami." });
        }

        // --- 6. LOGIKA KHUSUS OWNER ---
        if (isOwner) {
            // Perintah: .list (Cek Antrean)
            if (body.toLowerCase() === '.list') {
                const data = fs.readJsonSync(dbPath);
                let text = `*📊 DASHBOARD ADMIN CS*\n\n`;
                text += `*Sesi Aktif:* ${sessions.size}\n`;
                text += `*User Aktif:* ${[...nameToJid.keys()].join(', ') || '-'}\n`;
                text += `*Total Antrean:* ${data.queue.length}\n\n`;
                if (data.queue.length > 0) {
                    text += `*Daftar Antrean:*\n`;
                    data.queue.forEach((q, i) => { text += `${i+1}. ${q.split('@')[0]}\n` });
                }
                return sock.sendMessage(jid, { text: text });
            }

            // Perintah: .done Nama (Selesaikan Sesi)
            if (body.startsWith('.done')) {
                const targetName = body.replace('.done', '').trim().toLowerCase();
                const targetJid = nameToJid.get(targetName);
                if (targetJid) {
                    const session = sessions.get(targetJid);
                    if (session.timer) clearTimeout(session.timer);
                    sessions.delete(targetJid);
                    nameToJid.delete(targetName);

                    await sock.sendMessage(targetJid, { text: "✅ *LAYANAN SELESAI*\nAdmin telah menutup sesi ini. Terima kasih!" });
                    await sock.sendMessage(jid, { text: `✅ Sesi *${targetName}* telah ditutup.` });

                    // Panggil Antrean Selanjutnya
                    const data = fs.readJsonSync(dbPath);
                    if (data.queue.length > 0) {
                        const nextJid = data.queue.shift();
                        fs.writeJsonSync(dbPath, data);
                        sessions.set(nextJid, { stage: 'waiting_name' });
                        await sock.sendMessage(nextJid, { text: "🌟 *GILIRAN ANDA!*\nSilahkan masukkan *Nama Anda* untuk mulai berbicara dengan Admin:" });
                    }
                    return;
                }
                return sock.sendMessage(jid, { text: "❌ Nama tersebut tidak aktif." });
            }

            // Membalas User: Nama|Pesan
            if (body.includes('|')) {
                const [targetName, ...reply] = body.split('|');
                const tJid = nameToJid.get(targetName.trim().toLowerCase());
                if (tJid) {
                    await sock.sendPresenceUpdate('composing', tJid);
                    await sock.sendMessage(tJid, { text: `*PESAN DARI ADMIN:*\n\n${reply.join('|').trim()}` });
                    return sock.sendMessage(jid, { text: `✅ Terkirim ke ${targetName}` });
                }
            }
            return;
        }

        // --- 7. LOGIKA USER ---
        const userSession = sessions.get(jid);
        const lowerBody = body.toLowerCase();

        // A. Jam Operasional
        const hour = new Date().getHours();
        if (hour < config.workHourStart || hour >= config.workHourEnd) {
            return sock.sendMessage(jid, { text: `🌙 *LAYANAN OFFLINE*\nMaaf, kami buka pukul ${config.workHourStart}:00 - ${config.workHourEnd}:00 WIB.` });
        }

        // B. Fitur FAQ Otomatis
        if (config.faq && config.faq[lowerBody]) {
            await sock.sendPresenceUpdate('composing', jid);
            return sock.sendMessage(jid, { text: config.faq[lowerBody] });
        }

        // C. Proses CS (#halogus)
        if (lowerBody === '#halogus') {
            if (userSession) return sock.sendMessage(jid, { text: "Sesi Anda sedang berjalan." });
            if (sessions.size > 0) {
                const data = fs.readJsonSync(dbPath);
                if (!data.queue.includes(jid)) {
                    data.queue.push(jid);
                    fs.writeJsonSync(dbPath, data);
                }
                return sock.sendMessage(jid, { text: `⚠️ *ANTREAN PENUH*\nMohon tunggu, Anda di urutan ke-*${data.queue.length}*.\nKami akan mengabari Anda segera.` });
            }
            sessions.set(jid, { stage: 'waiting_name' });
            return sock.sendMessage(jid, { text: "👋 *GUS SUPPORT*\nHalo! Sebelum lanjut, boleh kami tahu siapa *Nama Anda*?" });
        }

        // D. Input Nama
        if (userSession && userSession.stage === 'waiting_name') {
            const userName = body.trim();
            if (userName.length < 3) return sock.sendMessage(jid, { text: "⚠️ Nama minimal 3 karakter." });
            
            const nameKey = userName.toLowerCase();
            nameToJid.set(nameKey, jid);

            const timer = setTimeout(() => {
                sessions.delete(jid);
                nameToJid.delete(nameKey);
                sock.sendMessage(jid, { text: "⌛ *WAKTU HABIS*\nSesi ditutup karena tidak ada respon." });
            }, config.sessionTimeout);

            sessions.set(jid, { stage: 'active', name: userName, timer: timer });
            return sock.sendMessage(jid, { text: `Selamat datang *${userName}*!\nSilahkan kirim keluhan Anda (Teks/Gambar).` });
        }

        // E. Sesi Chat Aktif (Penerusan)
        if (userSession && userSession.stage === 'active') {
            clearTimeout(userSession.timer);
            userSession.timer = setTimeout(() => {
                sessions.delete(jid);
                nameToJid.delete(userSession.name.toLowerCase());
                sock.sendMessage(jid, { text: "⌛ Sesi berakhir." });
            }, config.sessionTimeout);

            const platform = msg.key.id.length > 20 ? "Android/iPhone" : "Web/PC";
            const header = `*📬 PESAN BARU DARI: ${userSession.name}*\n*Device:* ${platform}\n*ID:* ${sender.split('@')[0]}\n\n`;

            if (msg.message.imageMessage || msg.message.documentMessage) {
                await sock.sendMessage(config.ownerNumber + "@s.whatsapp.net", { forward: msg });
            }
            
            await sock.sendMessage(config.ownerNumber + "@s.whatsapp.net", { 
                text: `${header}*Pesan:* ${body || '{Media}'}\n\n_Balas: ${userSession.name}|pesan_` 
            });
            return sock.sendMessage(jid, { text: "✅ _Pesan terkirim ke Admin._" });
        }

        // F. Welcome Message Default
        let menu = `👋 Selamat datang di *${config.botName}*!\n\n`;
        menu += `*INFORMASI CEPAT:*\n`;
        Object.keys(config.faq).forEach(k => menu += `• ${k}\n`);
        menu += `\nHubungi Admin: ketik *#halogus*`;
        
        await sock.sendPresenceUpdate('composing', jid);
        return sock.sendMessage(jid, { text: menu });

    } catch (err) {
        console.error("CRITICAL ERROR:", err);
    }
};
