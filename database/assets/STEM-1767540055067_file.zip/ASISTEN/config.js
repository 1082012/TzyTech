module.exports = {
    ownerNumber: "6282117447116", 
    sessionTimeout: 30000, // Timeout sesi (1 menit)
    spamCooldown: 5000,    // Cooldown pesan (5 detik)
    botName: "Gus Support System",
    // Jam Operasional (0-23)
    workHourStart: 8,      // Mulai jam 8 pagi
    workHourEnd: 21        // Selesai jam 9 malam
};
