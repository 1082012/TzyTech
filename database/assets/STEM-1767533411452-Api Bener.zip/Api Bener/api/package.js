const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();

// Konfigurasi Express
app.enable("trust proxy");
app.set("json spaces", 2);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());

// Statis Folder (Vercel akan mencari dari root project)
app.use('/src', express.static(path.join(__dirname, '../src')));
app.use('/', express.static(path.join(__dirname, '../api-page')));

// Load Settings
const settingsPath = path.join(__dirname, '../src/settings.json');
let settings = { apiSettings: { creator: "Gustzy" } };
if (fs.existsSync(settingsPath)) {
    settings = JSON.parse(fs.readFileSync(settingsPath, 'utf-8'));
}

// Middleware: Auto-Creator JSON
app.use((req, res, next) => {
    const originalJson = res.json;
    res.json = function (data) {
        if (data && typeof data === 'object') {
            const responseData = {
                status: data.status !== undefined ? data.status : true,
                creator: settings.apiSettings.creator || "Gustzy",
                ...data
            };
            return originalJson.call(this, responseData);
        }
        return originalJson.call(this, data);
    };
    next();
});

// Auto-Load Routes dari src/api/
const apiFolder = path.join(__dirname, '../src/api');
if (fs.existsSync(apiFolder)) {
    fs.readdirSync(apiFolder).forEach((subfolder) => {
        const subfolderPath = path.join(apiFolder, subfolder);
        if (fs.statSync(subfolderPath).isDirectory()) {
            fs.readdirSync(subfolderPath).forEach((file) => {
                if (path.extname(file) === '.js') {
                    try {
                        // Memasukkan aplikasi express ke dalam plugin
                        require(path.join(subfolderPath, file))(app);
                    } catch (err) {
                        console.error(`Gagal memuat route ${file}:`, err.message);
                    }
                }
            });
        }
    });
}

// Route Halaman Utama
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../api-page/index.html'));
});

// Error Handling 404
app.use((req, res) => {
    res.status(404).json({ status: false, message: "Endpoint serverless tidak ditemukan" });
});

// EKSPOR UNTUK VERCEL (PENTING)
module.exports = app;
