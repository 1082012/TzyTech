module.exports = function(app) {
    app.get('/canvas/brat', async (req, res) => {
        try {
            const { text } = req.query;
            if (!text) return res.status(400).json({ status: false, error: 'Text required' });

            const imageUrl = `https://api.nekolabs.web.id/canvas/brat/v1?text=${encodeURIComponent(text)}`;
            
            // Mengembalikan URL gambar langsung atau metadata
            res.status(200).json({
                status: true,
                result: {
                    url: imageUrl,
                    type: "image/webp"
                }
            });
        } catch (error) {
            res.status(500).json({ status: false, error: error.message });
        }
    });
};
