const axios = require('axios');

module.exports = function(app) {
    app.get('/downloader/spotify', async (req, res) => {
        try {
            const { q } = req.query;
            if (!q) return res.status(400).json({ status: false, error: 'Query required' });

            const { data } = await axios.get(`https://api.nekolabs.web.id/downloader/spotify/play/v1?q=${encodeURIComponent(q)}`);
            res.status(200).json({
                status: true,
                result: data
            });
        } catch (error) {
            res.status(500).json({ status: false, error: error.message });
        }
    });
};
