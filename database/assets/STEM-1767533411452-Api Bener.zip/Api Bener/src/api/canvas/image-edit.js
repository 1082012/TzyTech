const axios = require('axios');
const crypto = require('crypto');

module.exports = function(app) {
    // Fungsi internal untuk memproses gambar
    async function processNanoBanana(prompt, imageBuffer) {
        const inst = axios.create({
            baseURL: 'https://image-editor.org/api',
            headers: {
                origin: 'https://image-editor.org',
                referer: 'https://image-editor.org/editor',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36'
            }
        });

        // 1. Dapatkan Presigned URL
        const { data: up } = await inst.post('/upload/presigned', {
            filename: `${Date.now()}_gustzy.jpg`,
            contentType: 'image/jpeg'
        });

        if (!up?.data?.uploadUrl) throw new Error('Gagal mendapatkan URL upload.');

        // 2. Upload Buffer Gambar ke Cloud Storage mereka
        await axios.put(up.data.uploadUrl, imageBuffer, {
            headers: { 'Content-Type': 'image/jpeg' }
        });

        // 3. Bypass Cloudflare Turnstile menggunakan API NekoLabs
        const { data: cf } = await axios.post('https://api.nekolabs.web.id/tools/bypass/cf-turnstile', {
            url: 'https://image-editor.org/editor',
            siteKey: '0x4AAAAAAB8ClzQTJhVDd_pU'
        });

        if (!cf?.result) throw new Error('Gagal melewati keamanan Cloudflare.');

        // 4. Kirim Task Edit
        const { data: task } = await inst.post('/edit', {
            prompt: prompt,
            image_urls: [up.data.fileUrl],
            image_size: 'auto',
            turnstileToken: cf.result,
            uploadIds: [up.data.uploadId],
            userUUID: crypto.randomUUID(),
            imageHash: crypto.createHash('sha256').update(imageBuffer).digest('hex')
        });

        if (!task?.data?.taskId) throw new Error('Task ID tidak ditemukan.');

        // 5. Polling hingga selesai
        let attempts = 0;
        while (attempts < 30) {
            const { data } = await inst.get(`/task/${task.data.taskId}`);
            if (data?.data?.status === 'completed') return data.data.result;
            if (data?.data?.status === 'failed') throw new Error('Proses edit gagal di server.');
            
            await new Promise(res => setTimeout(res, 2000));
            attempts++;
        }
        throw new Error('Waktu tunggu habis (Timeout).');
    }

    // Endpoint API
    app.get('/canvas/image-edit', async (req, res) => {
        try {
            const { prompt, url } = req.query;

            if (!prompt || !url) {
                return res.status(400).json({ 
                    status: false, 
                    error: 'Parameter "prompt" dan "url" (link gambar) wajib diisi.' 
                });
            }

            // Download gambar dari URL ke Buffer
            const imageResp = await axios.get(url, { responseType: 'arraybuffer' });
            const buffer = Buffer.from(imageResp.data, 'utf-8');

            const result = await processNanoBanana(prompt, buffer);

            res.status(200).json({
                status: true,
                result: {
                    prompt,
                    original_url: url,
                    edited_url: result // Biasanya berupa array URL gambar hasil
                }
            });
        } catch (error) {
            res.status(500).json({ status: false, error: error.message });
        }
    });
};
